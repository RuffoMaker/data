/*
SQLyog Community v12.3.1 (64 bit)
MySQL - 5.7.18-0ubuntu0.16.10.1 : Database - characters
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`characters` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `characters`;

/*Table structure for table `account_data` */

DROP TABLE IF EXISTS `account_data`;

CREATE TABLE `account_data` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`accountId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account_data` */

insert  into `account_data`(`accountId`,`type`,`time`,`data`) values 
(1,0,1502318100,'SET autoDismountFlying \"1\"\nSET autoLootDefault \"1\"\nSET showTargetOfTarget \"1\"\nSET flaggedTutorials \"v##]##-##?##@##<##U##:##M##%##&##$##[##A##B##+##;##)##(##K##\\##Y##6##5##Z##1##9##I##D##0##J##V##X##C##*##,##>\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameNPC \"1\"\nSET UnitNameNonCombatCreatureName \"1\"\nSET fctSpellMechanicsOther \"1\"\nSET xpBarText \"1\"\nSET playerStatusText \"1\"\nSET targetStatusText \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\n'),
(1,2,1501902395,'BINDINGMODE 0\r\nbind Q MULTIACTIONBAR2BUTTON1\r\nbind E MULTIACTIONBAR2BUTTON2\r\nbind R MULTIACTIONBAR2BUTTON3\r\nbind G MULTIACTIONBAR2BUTTON7\r\nbind F MULTIACTIONBAR2BUTTON6\r\nbind V MULTIACTIONBAR2BUTTON9\r\nbind T MULTIACTIONBAR2BUTTON4\r\nbind C MULTIACTIONBAR2BUTTON8\r\nbind B MULTIACTIONBAR2BUTTON10\r\nbind Y MULTIACTIONBAR2BUTTON5\r\nbind SHIFT-Q MULTIACTIONBAR2BUTTON11\r\nbind SHIFT-E MULTIACTIONBAR2BUTTON12\r\n'),
(1,4,1502112193,'MACRO 2 \" \" INV_Misc_QuestionMark\r\n#Showtooltip Marca del cazador\r\n/cast marca del cazador\r\n/petattack\r\nEND\r\nMACRO 1 \" \" INV_Misc_QuestionMark\r\n#showtooltip Explosión Arcana\r\n/cast venas heladas\r\n/cast poder arcano\r\n/cast presencia mental\r\n/cast Explosión Arcana\r\nEND\r\nMACRO 4 \"DEL\" Ability_Creature_Cursed_02\r\n.npc del\r\nEND\r\nMACRO 3 \"Portal\" Ability_Creature_Cursed_04\r\n.gob add 188096\r\n.gob add 177243\r\nEND\r\nMACRO 6 \"Restart\" INV_Misc_QuestionMark\r\n.saveall\r\n.server restart 1\r\nEND\r\nMACRO 5 \"Traslacion\" Ability_Druid_Cower\r\n.cast 1953 triggered\r\nEND\r\n'),
(2,0,1502156498,'SET flaggedTutorials \"v##M##%##&##$##:##[##A##B##)##\\##6##7##>##?##@##C##Z##1##9##I##D##0##J##V##+##;##,##^##K##<##(\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),
(3,0,1502214462,'SET flaggedTutorials \"v##:##M##%##&##$##A##B##Z##1##9##I##D##0##J##V##[##+##,##)##6##\\##;##7##K##5##(##S##^##]##W##X\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameNPC \"1\"\nSET UnitNameEnemyGuardianName \"1\"\nSET UnitNameEnemyTotemName \"1\"\nSET UnitNameFriendlyGuardianName \"1\"\nSET UnitNameFriendlyTotemName \"1\"\nSET UnitNameNonCombatCreatureName \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showTutorials \"0\"\n'),
(3,4,1501973033,'MACRO 3 \"GM\" Ability_Druid_Cower\r\n.modify speed 1\r\nEND\r\nMACRO 2 \"GM FLY\" Ability_Druid_FlightForm\r\n.gm fly on\r\n.modify speed 5\r\nEND\r\nMACRO 1 \"Ropa GM\" Spell_Shadow_NetherCloak\r\n.add 2586\r\n.add 12064\r\n.add 11508\r\nEND\r\n'),
(4,0,1502316060,'SET flaggedTutorials \"v##M##%##&##$##:##A##B##(##7##F##6##?##@##*##Z##[##+##)##<##\\\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameNPC \"1\"\nSET UnitNameNonCombatCreatureName \"1\"\nSET cameraDistanceMaxFactor \"1\"\n'),
(5,0,1502328346,'SET flaggedTutorials \"v##M##%##&##$##:##A##B##(##9##<##6##?##K##@\"\nSET cameraDistanceMaxFactor \"1\"\n'),
(6,0,1502213794,'SET rotateMinimap \"1\"\nSET flaggedTutorials \"v##M##%##&##$##:##7##+##(##Z##[##*##)##1##\\##E##;##8##K##-##?##@##^##]##6##9##I##D##0##X##A##B##5##N##4##.##/##,##3##J##V##Y##S##C##=##F##P##T##Q##<##_\"\nSET profanityFilter \"0\"\nSET guildShowOffline \"0\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameNPC \"1\"\nSET UnitNameNonCombatCreatureName \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\nSET ShowAllSpellRanks \"0\"\n'),
(6,2,1502207509,'BINDINGMODE 0\r\nbind BUTTON3 NONE\r\nbind UP MOVEANDSTEER\r\nbind NUMLOCK TOGGLEAUTORUN\r\nbind BUTTON4 NONE\r\nbind NUMPADDIVIDE NONE\r\nbind ALT-NUMPAD0 NONE\r\nbind � TOGGLEAUTORUN\r\nbind � TOGGLERUN\r\n'),
(6,4,1502207510,'MACRO 13 \".npc de\" Ability_BullRush\r\n.npc de\r\nEND\r\nMACRO 11 \"ali\" Ability_Creature_Poison_04\r\n.go spawn 179830 1\r\nEND\r\nMACRO 5 \"BUZON\" INV_Misc_QuestionMark\r\n.go spawn 144131 1\r\nEND\r\nMACRO 3 \"de\" Ability_Creature_Cursed_01\r\n.go de\r\nEND\r\nMACRO 12 \"horda\" Ability_Creature_Cursed_02\r\n.go spawn 190095\r\nEND\r\nMACRO 14 \"Interfaz\" Ability_Creature_Cursed_01\r\n.mod morph 28127\r\nEND\r\nMACRO 1 \"Kill\" Ability_BackStab\r\n.die\r\nEND\r\nMACRO 10 \"MANGOSTA\" Ability_Creature_Disease_01\r\n.char additem 38925\r\nEND\r\nMACRO 4 \"mesa\" INV_Misc_QuestionMark\r\n.go spawn 181075 1\r\nEND\r\nMACRO 15 \"Puas\" INV_Misc_QuestionMark\r\n/gritar TENGO PUAS!\r\nEND\r\nMACRO 7 \"RECUERDO\" Ability_CheapShot\r\n.char additem 19316\r\nEND\r\nMACRO 2 \"select\" Ability_CheapShot\r\n.go se\r\nEND\r\nMACRO 6 \"silla\" Ability_Creature_Cursed_04\r\n.go spawn 181076 1\r\nEND\r\nMACRO 8 \"tablas\" INV_Misc_QuestionMark\r\n.go spawn 185301\r\nEND\r\n'),
(7,0,1502213243,'SET showTargetOfTarget \"1\"\nSET displayFreeBagSlots \"1\"\nSET autoQuestWatch \"0\"\nSET autoQuestProgress \"0\"\nSET flaggedTutorials \"v##M##%##&##$##C##Z##1##:##9##I##D##0##J##V##[##7##Q##)##K##+##;##-##,##6##X##Y##\\##5##A##B##4##^##.##/##]##E##(##*##3##?##R##S##T##<##@\"\nSET profanityFilter \"0\"\nSET guildShowOffline \"0\"\nSET showTimestamps \"%I:%M\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameNPC \"1\"\nSET fctDodgeParryMiss \"1\"\nSET fctDamageReduction \"1\"\nSET fctRepChanges \"1\"\nSET fctPeriodicEnergyGains \"1\"\nSET fctHonorGains \"1\"\nSET fctAuras \"1\"\nSET fctSpellMechanics \"1\"\nSET fctSpellMechanicsOther \"1\"\nSET xpBarText \"1\"\nSET playerStatusText \"1\"\nSET petStatusText \"1\"\nSET partyStatusText \"1\"\nSET targetStatusText \"1\"\nSET cameraView \"7\"\nSET cameraDistanceMaxFactor \"2\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\nSET timeMgrUseLocalTime \"1\"\nSET ShowAllSpellRanks \"0\"\n'),
(7,2,1502213244,'BINDINGMODE 0\r\nbind Q MULTIACTIONBAR1BUTTON1\r\nbind E MULTIACTIONBAR1BUTTON2\r\nbind Z MULTIACTIONBAR1BUTTON8\r\nbind NUMLOCK NONE\r\nbind BUTTON4 MULTIACTIONBAR4BUTTON11\r\nbind R MULTIACTIONBAR1BUTTON5\r\nbind SHIFT-R MULTIACTIONBAR2BUTTON5\r\nbind - TOGGLESHEATH\r\nbind CTRL-2 MULTIACTIONBAR2BUTTON9\r\nbind CTRL-3 MULTIACTIONBAR1BUTTON9\r\nbind CTRL-4 MULTIACTIONBAR2BUTTON10\r\nbind CTRL-5 MULTIACTIONBAR2BUTTON11\r\nbind SHIFT-4 MULTIACTIONBAR2BUTTON2\r\nbind G MULTIACTIONBAR1BUTTON3\r\nbind F MULTIACTIONBAR1BUTTON4\r\nbind V MULTIACTIONBAR1BUTTON7\r\nbind CTRL-V NAMEPLATES\r\nbind T NONE\r\nbind SHIFT-T MULTIACTIONBAR1BUTTON6\r\nbind I MULTIACTIONBAR4BUTTON1\r\nbind MOUSEWHEELUP NONE\r\nbind MOUSEWHEELDOWN NONE\r\nbind CTRL-T MULTIACTIONBAR2BUTTON12\r\nbind . VEHICLECAMERAZOOMIN\r\nbind , VEHICLECAMERAZOOMOUT\r\nbind SHIFT-F MULTIACTIONBAR1BUTTON11\r\nbind SHIFT-Q MULTIACTIONBAR2BUTTON1\r\nbind \\ MULTIACTIONBAR2BUTTON3\r\nbind CTRL-C MULTIACTIONBAR2BUTTON4\r\nbind J MULTIACTIONBAR2BUTTON6\r\nbind ALT-F MULTIACTIONBAR3BUTTON1\r\nbind ALT-Q MULTIACTIONBAR3BUTTON2\r\nbind ALT-3 MULTIACTIONBAR3BUTTON3\r\nbind ALT-V ALLNAMEPLATES\r\nbind { NONE\r\nbind \' TOGGLEAUTORUN\r\n'),
(7,4,1502213245,'MACRO 2 \"arenas\" Ability_Druid_Cower\r\n#showtooltip señal de luz\r\n/7 Busco compañero para 2c2, pref war, cazador o dk. team 1.6k soy priest diciplina.\r\nEND\r\nMACRO 3 \"armas\" INV_Misc_QuestionMark\r\n/cast Actitud de batalla\r\n/equip Quel\r\nEND\r\nMACRO 7 \"buffos\" INV_Misc_QuestionMark\r\n/rw ogxpeke PODERIO, rovertha SALVA, tarihel SABIDURIA, Dooky grito de vida, Jose REYES\r\nEND\r\nMACRO 1 \"Culo\" Ability_Creature_Disease_02\r\n/burla\r\n/morder\r\n/mascota\r\n/mirar\r\nEND\r\nMACRO 4 \"defensa\" INV_Misc_QuestionMark\r\n/cast Actitud defensiva\r\n/equip Buenas noches\r\n/equip Escudo muro de acero de titanes\r\nEND\r\nMACRO 12 \"dps\" INV_Misc_QuestionMark\r\n/equip Agonía de sombras\r\n/equip Calavera dentuda susurrante\r\n/equip Abominación diminuta en un tarro\r\nEND\r\nMACRO 5 \"furia\" INV_Misc_QuestionMark\r\n/cast Actitud rabiosa\r\n/equip Quel\'Delar, poderío de los fieles\r\nEND\r\nMACRO 10 \"herma chamy\" Ability_Creature_Cursed_03\r\n/6 NEW GUILD \"{calavera}EVILHELL{calavera}\"Busca gente comprometida, con o sin experiencia de gs 5.6 como minimo,  para sus Raideos en los horarios 13:00 y 21:30h server, en sus bandas de ICC 10N/10H-25N/25H y SR  10N/10H-25N/25H.\r\nEND\r\nMACRO 14 \"hermandad\" Ability_Ambush\r\n/5 NEW GUILD \"{calavera}EVILHELL{calavera}\"Busca gente comprometida, con o sin experiencia de gs 5.6 como minimo,  para sus Raideos en los horarios 13:00 y 21:30h server, en sus bandas de ICC 10N/10H-25N/25H y SR  10N/10H-25N/25H.\r\nEND\r\nMACRO 9 \"hermandad\" Ability_Creature_Cursed_02\r\n/5 NEW GUILD \"{calavera}EVILHELL{calavera}\"Busca gente comprometida, con o sin experiencia  para sus  Raideos en los horarios 13:00 y 21:30h server, en sus bandas de ICC 10N/10H-25N/25H y SR  10N/10H-25N/25H requisito (RC).\r\nEND\r\nMACRO 6 \"icc\" Ability_Ambush\r\n/5 new raid icc 10h need heal dudu/chaman y dps, gs min 5.8 desde 0 wisp me\r\nEND\r\nMACRO 8 \"puas\" INV_Misc_QuestionMark\r\n/rw pueas\r\nEND\r\nMACRO 13 \"saludar\" INV_Misc_QuestionMark\r\n/Saludo\r\nEND\r\nMACRO 11 \"tank\" INV_Misc_QuestionMark\r\n/equip Mithrios, legado de Barbabronce\r\n/equip Muro glacial de la Corona de Hielo\r\n/equip Colmillo impecable de Sindragosa\r\n/equip Escama Crepuscular petrificada\r\nEND\r\n');

/*Table structure for table `account_instance_times` */

DROP TABLE IF EXISTS `account_instance_times`;

CREATE TABLE `account_instance_times` (
  `accountId` int(10) unsigned NOT NULL,
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0',
  `releaseTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`,`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account_instance_times` */

insert  into `account_instance_times`(`accountId`,`instanceId`,`releaseTime`) values 
(1,1,1502326135);

/*Table structure for table `account_tutorial` */

DROP TABLE IF EXISTS `account_tutorial`;

CREATE TABLE `account_tutorial` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `tut0` int(10) unsigned NOT NULL DEFAULT '0',
  `tut1` int(10) unsigned NOT NULL DEFAULT '0',
  `tut2` int(10) unsigned NOT NULL DEFAULT '0',
  `tut3` int(10) unsigned NOT NULL DEFAULT '0',
  `tut4` int(10) unsigned NOT NULL DEFAULT '0',
  `tut5` int(10) unsigned NOT NULL DEFAULT '0',
  `tut6` int(10) unsigned NOT NULL DEFAULT '0',
  `tut7` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account_tutorial` */

insert  into `account_tutorial`(`accountId`,`tut0`,`tut1`,`tut2`,`tut3`,`tut4`,`tut5`,`tut6`,`tut7`) values 
(1,4242977783,32768737,0,0,0,0,0,0),
(2,3789828535,96731873,0,0,0,0,0,0),
(3,1626223031,131891937,0,0,0,0,0,0),
(4,2035024119,29360644,0,0,0,0,0,0),
(5,2036596759,640,0,0,0,0,0,0),
(6,1625567927,13894369,0,0,0,0,0,0),
(7,4457095,640,0,0,0,0,0,0);

/*Table structure for table `addons` */

DROP TABLE IF EXISTS `addons`;

CREATE TABLE `addons` (
  `name` varchar(120) NOT NULL DEFAULT '',
  `crc` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Addons';

/*Data for the table `addons` */

insert  into `addons`(`name`,`crc`) values 
('Blizzard_AchievementUI',1276933997),
('Blizzard_ArenaUI',1276933997),
('Blizzard_AuctionUI',1276933997),
('Blizzard_BarbershopUI',1276933997),
('Blizzard_BattlefieldMinimap',1276933997),
('Blizzard_BindingUI',1276933997),
('Blizzard_Calendar',1276933997),
('Blizzard_CombatLog',1276933997),
('Blizzard_CombatText',1276933997),
('Blizzard_DebugTools',1276933997),
('Blizzard_GlyphUI',1276933997),
('Blizzard_GMChatUI',1276933997),
('Blizzard_GMSurveyUI',1276933997),
('Blizzard_GuildBankUI',1276933997),
('Blizzard_InspectUI',1276933997),
('Blizzard_ItemSocketingUI',1276933997),
('Blizzard_MacroUI',1276933997),
('Blizzard_RaidUI',1276933997),
('Blizzard_TalentUI',1276933997),
('Blizzard_TimeManager',1276933997),
('Blizzard_TokenUI',1276933997),
('Blizzard_TradeSkillUI',1276933997),
('Blizzard_TrainerUI',1276933997);

/*Table structure for table `arena_team` */

DROP TABLE IF EXISTS `arena_team`;

CREATE TABLE `arena_team` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `captainGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `backgroundColor` int(10) unsigned NOT NULL DEFAULT '0',
  `emblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `emblemColor` int(10) unsigned NOT NULL DEFAULT '0',
  `borderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borderColor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `arena_team` */

/*Table structure for table `arena_team_member` */

DROP TABLE IF EXISTS `arena_team_member`;

CREATE TABLE `arena_team_member` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `personalRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`,`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `arena_team_member` */

/*Table structure for table `auctionhouse` */

DROP TABLE IF EXISTS `auctionhouse`;

CREATE TABLE `auctionhouse` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `houseid` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `itemguid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemowner` int(10) unsigned NOT NULL DEFAULT '0',
  `buyoutprice` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `buyguid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastbid` int(10) unsigned NOT NULL DEFAULT '0',
  `startbid` int(10) unsigned NOT NULL DEFAULT '0',
  `deposit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `auctionhouse` */

/*Table structure for table `banned_addons` */

DROP TABLE IF EXISTS `banned_addons`;

CREATE TABLE `banned_addons` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Version` varchar(255) NOT NULL DEFAULT '',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `idx_name_ver` (`Name`,`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `banned_addons` */

/*Table structure for table `battleground_deserters` */

DROP TABLE IF EXISTS `battleground_deserters`;

CREATE TABLE `battleground_deserters` (
  `guid` int(10) unsigned NOT NULL COMMENT 'characters.guid',
  `type` tinyint(3) unsigned NOT NULL COMMENT 'type of the desertion',
  `datetime` datetime NOT NULL COMMENT 'datetime of the desertion'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `battleground_deserters` */

/*Table structure for table `bugreport` */

DROP TABLE IF EXISTS `bugreport`;

CREATE TABLE `bugreport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Debug System';

/*Data for the table `bugreport` */

/*Table structure for table `calendar_events` */

DROP TABLE IF EXISTS `calendar_events`;

CREATE TABLE `calendar_events` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creator` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '4',
  `dungeon` int(10) NOT NULL DEFAULT '-1',
  `eventtime` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `calendar_events` */

/*Table structure for table `calendar_invites` */

DROP TABLE IF EXISTS `calendar_invites`;

CREATE TABLE `calendar_invites` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `event` bigint(20) unsigned NOT NULL DEFAULT '0',
  `invitee` int(10) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `statustime` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `calendar_invites` */

/*Table structure for table `channels` */

DROP TABLE IF EXISTS `channels`;

CREATE TABLE `channels` (
  `name` varchar(128) NOT NULL,
  `team` int(10) unsigned NOT NULL,
  `announce` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ownership` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `password` varchar(32) DEFAULT NULL,
  `bannedList` text,
  `lastUsed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`,`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Channel System';

/*Data for the table `channels` */

/*Table structure for table `character_account_data` */

DROP TABLE IF EXISTS `character_account_data`;

CREATE TABLE `character_account_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`guid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_account_data` */

insert  into `character_account_data`(`guid`,`type`,`time`,`data`) values 
(1,1,1502318101,'SET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"9.996001\"\nSET cameraSavedPitch \"14.249976\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_SPELL_COMBAT\"\nSET showTokenFrame \"1\"\n'),
(1,7,1502156058,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(2,1,1502214471,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"35.400014\"\nSET nameplateShowEnemies \"1\"\nSET nameplateAllowOverlap \"0\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_SPELL_COMBAT\"\n'),
(2,5,1502214470,'MACRO 16777217 \"Isla GM\" Ability_Druid_Dash\r\n.tele gmisland\r\nEND\r\n'),
(2,7,1501902729,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(3,1,1502316061,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v#+J\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"7.272089\"\nSET cameraSavedPitch \"-0.929322\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),
(3,7,1501948149,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(4,1,1502328350,'SET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"6.549600\"\nSET cameraSavedPitch \"18.148161\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),
(4,7,1502290724,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(5,1,1502156499,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"8.002804\"\nSET cameraSavedPitch \"20.750009\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_SPELL_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),
(5,5,1502156500,'MACRO 16777228 \".unfreeze\" INV_Misc_QuestionMark\r\nEND\r\nMACRO 16777226 \"Ape\" Spell_Arcane_Blink\r\n.appear\r\nEND\r\nMACRO 16777224 \"DIE\" Ability_Hunter_RapidKilling\r\n.DIE\r\nEND\r\nMACRO 16777218 \"FLY OFF\" INV_Misc_QuestionMark\r\n.gm fly off\r\nEND\r\nMACRO 16777217 \"FLY ON\" Ability_Paladin_BeaconofLight\r\n.gm fly on\r\nEND\r\nMACRO 16777222 \"Frez\" Ability_Druid_EmpoweredTouch\r\n.FREEZE\r\nEND\r\nMACRO 16777231 \"INFO\" Spell_Nature_Invisibilty\r\n.PINFO\r\nEND\r\nMACRO 16777219 \"macro\" INV_Misc_QuestionMark\r\n/macro\r\nEND\r\nMACRO 16777230 \"RC\" Spell_Frost_Stun\r\n,recall\r\nEND\r\nMACRO 16777225 \"REVIVE\" Ability_Druid_LunarGuidance\r\n.revive\r\nEND\r\nMACRO 16777229 \"Rsp\" Spell_Holy_AuraMastery\r\n.respawn\r\nEND\r\nMACRO 16777221 \"SP 1\" INV_Misc_QuestionMark\r\n.MODIFY SPEED 1\r\nEND\r\nMACRO 16777220 \"SP 7\" Ability_Druid_Dash\r\n.modify speed 7\r\nEND\r\nMACRO 16777227 \"sum\" Spell_Arcane_FocusedPower\r\n.summon\r\nEND\r\nMACRO 16777223 \"UNAURA\" INV_Misc_QuestionMark\r\n.UNAURA ALL\r\nEND\r\n'),
(5,7,1502131395,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(6,1,1502210150,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v#+J\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"18.981373\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),
(6,7,1502210151,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),
(8,1,1502213993,'SET minimapZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"16.545601\"\nSET cameraSavedPitch \"25.350000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),
(8,7,1502213992,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n');

/*Table structure for table `character_achievement` */

DROP TABLE IF EXISTS `character_achievement`;

CREATE TABLE `character_achievement` (
  `guid` int(10) unsigned NOT NULL,
  `achievement` smallint(5) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`achievement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_achievement` */

insert  into `character_achievement`(`guid`,`achievement`,`date`) values 
(1,6,1501902471),
(1,7,1501902471),
(1,8,1501902471),
(1,9,1501902471),
(1,10,1501902471),
(1,11,1501902471),
(1,12,1501902471),
(1,13,1501902471),
(1,457,1501902471),
(1,460,1501902471),
(1,545,1501902508),
(1,964,1502322788),
(1,1408,1501902471),
(1,3838,1502302437),
(1,4516,1502303114),
(1,4517,1502302761),
(1,4518,1502303916),
(1,4784,1502302436),
(2,6,1501902537),
(2,7,1501902537),
(2,8,1501902537),
(2,9,1501902537),
(2,10,1501902537),
(2,11,1501902537),
(2,12,1501902537),
(2,13,1501902537),
(2,466,1501902537),
(2,889,1501903143),
(2,890,1501903143),
(2,891,1501903143),
(2,892,1502214255),
(2,1411,1501902537),
(6,6,1502211342),
(6,7,1502211342),
(6,8,1502211342),
(6,9,1502211342),
(6,10,1502211342),
(6,11,1502211342),
(6,12,1502211342),
(6,13,1502211342),
(6,465,1502211342),
(6,545,1502210256),
(6,695,1502211394),
(6,697,1502211293),
(6,891,1502211347),
(8,116,1502213991),
(8,121,1502213991),
(8,122,1502213991),
(8,123,1502213991),
(8,124,1502213991),
(8,125,1502213991),
(8,131,1502213991),
(8,132,1502213991),
(8,133,1502213991),
(8,134,1502213991),
(8,135,1502213991),
(8,731,1502213991),
(8,732,1502213991),
(8,733,1502213991),
(8,734,1502213991),
(8,735,1502213991);

/*Table structure for table `character_achievement_progress` */

DROP TABLE IF EXISTS `character_achievement_progress`;

CREATE TABLE `character_achievement_progress` (
  `guid` int(10) unsigned NOT NULL,
  `criteria` smallint(5) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_achievement_progress` */

insert  into `character_achievement_progress`(`guid`,`criteria`,`counter`,`date`) values 
(1,34,80,1501902471),
(1,35,80,1501902471),
(1,36,80,1501902471),
(1,37,80,1501902471),
(1,38,80,1501902471),
(1,39,80,1501902471),
(1,40,80,1501902471),
(1,41,80,1501902471),
(1,111,37,1502323012),
(1,149,1,1502321582),
(1,150,3,1502323012),
(1,162,32020194,1502303848),
(1,167,1,1501902451),
(1,169,4,1502303528),
(1,505,1,1502321946),
(1,653,1,1501903484),
(1,657,1,1501902451),
(1,753,8,1502153942),
(1,756,1,1501902451),
(1,757,1,1501902451),
(1,832,1,1501941033),
(1,1064,1,1502322527),
(1,1145,1,1502322564),
(1,1146,1,1501902461),
(1,1147,1,1501940808),
(1,1149,1,1501902479),
(1,1160,1,1502322005),
(1,1167,1,1502321983),
(1,1222,1,1502322580),
(1,1299,1,1502272976),
(1,2020,200,1501902451),
(1,2030,4000,1501902451),
(1,2031,3100,1501902451),
(1,2032,3100,1501902451),
(1,2033,3100,1501902451),
(1,2034,3000,1501902451),
(1,2072,6538,1502322788),
(1,2341,1,1501902508),
(1,2416,3000,1501902451),
(1,2425,4053,1502303848),
(1,3357,111173,1501902508),
(1,4224,10000000,1501902502),
(1,4742,3000,1501902451),
(1,4747,2023,1502303848),
(1,4748,2023,1502303848),
(1,4749,2023,1502303848),
(1,4787,1,1501904282),
(1,4944,159,1502303848),
(1,4946,1,1502153279),
(1,4948,5,1502302331),
(1,4953,29,1502303025),
(1,4955,125,1502303848),
(1,5018,255,1502272995),
(1,5212,255,1502272995),
(1,5233,255,1502272995),
(1,5290,1,1502288161),
(1,5293,1,1502153330),
(1,5301,11,1502302291),
(1,5328,3100,1501902451),
(1,5329,3100,1501902451),
(1,5330,3100,1501902451),
(1,5331,4000,1501902451),
(1,5332,3000,1501902451),
(1,5339,2023,1502303848),
(1,5340,2023,1502303848),
(1,5341,2023,1502303848),
(1,5371,399998,1502320456),
(1,5372,168940,1502325404),
(1,5373,2776230,1502302291),
(1,5512,6,1502323012),
(1,5529,208,1502323012),
(1,5530,39,1502321582),
(1,5532,3,1502153953),
(1,5576,8,1502153942),
(1,5585,1,1501903484),
(1,5586,1,1501902451),
(1,5589,1,1501902451),
(1,5591,1,1501902451),
(1,5593,37,1502323012),
(1,5859,1,1502302005),
(1,5860,1,1502302185),
(1,5865,1,1502302005),
(1,5868,1,1502302005),
(1,5871,1,1502302165),
(1,6140,9,1502303655),
(1,6142,9,1502303655),
(1,6847,4,1502303528),
(1,7550,1,1501904282),
(1,7551,1,1501904282),
(1,7552,1,1501904282),
(1,8819,500,1501902451),
(1,8820,500,1501902451),
(1,8821,500,1501902451),
(1,8822,500,1501902451),
(1,9223,1,1501904282),
(1,9598,80,1501902471),
(1,9678,3100,1501902451),
(1,9679,3000,1501902451),
(1,9680,3100,1501902451),
(1,9681,3100,1501902451),
(1,9682,4000,1501902451),
(1,11278,2023,1502303848),
(1,11552,2,1502302437),
(1,11556,14,1502303655),
(1,11601,14,1502303655),
(1,11605,14,1502303655),
(1,11609,14,1502303655),
(1,11613,14,1502303655),
(1,11617,14,1502303655),
(1,11621,14,1502303655),
(1,12421,14,1502303655),
(1,12698,140,1502322788),
(1,12738,1,1502302985),
(1,12739,1,1502303114),
(1,12740,1,1502302574),
(1,12741,1,1502302437),
(1,12742,1,1502303527),
(1,12743,1,1502303916),
(1,12744,1,1502302761),
(1,12750,1,1502303527),
(1,12990,1,1502303655),
(1,12991,1,1502303655),
(1,13166,1,1502302985),
(1,13167,1,1502302985),
(1,13168,1,1502303114),
(1,13169,1,1502303114),
(1,13170,1,1502302574),
(1,13172,1,1502302437),
(1,13173,1,1502302437),
(1,13174,1,1502302761),
(1,13175,1,1502302761),
(1,13176,1,1502303527),
(1,13177,1,1502303527),
(1,13178,1,1502303655),
(1,13179,1,1502303655),
(1,13180,1,1502303916),
(1,13182,1,1502302574),
(1,13183,7,1502303655),
(1,13315,1,1502302985),
(1,13316,1,1502303114),
(1,13317,1,1502302574),
(1,13318,1,1502302437),
(1,13319,1,1502302761),
(1,13320,1,1502303527),
(1,13321,1,1502303655),
(1,13323,1,1502303916),
(1,13382,1,1502302436),
(2,34,80,1501902537),
(2,35,80,1501902537),
(2,36,80,1501902537),
(2,37,80,1501902537),
(2,38,80,1501902537),
(2,39,80,1501902537),
(2,40,80,1501902537),
(2,41,80,1501902537),
(2,167,1,1501902462),
(2,655,1,1501902462),
(2,657,1,1501902462),
(2,756,1,1501902462),
(2,832,1,1501903192),
(2,903,1,1501902475),
(2,992,3100,1501902462),
(2,993,4000,1501902462),
(2,994,500,1501902462),
(2,995,3100,1501902462),
(2,996,400,1501902462),
(2,1870,150,1501903143),
(2,1871,225,1501903143),
(2,1872,150,1501903143),
(2,1873,300,1502214255),
(2,2020,200,1501902462),
(2,2045,2000,1501902462),
(2,2072,2611,1501903495),
(2,4224,1125304973,1502214255),
(2,5212,85,1501902655),
(2,5214,85,1501902655),
(2,5236,85,1501902655),
(2,5301,6,1501902462),
(2,5313,3100,1501902462),
(2,5314,3100,1501902462),
(2,5315,4000,1501902462),
(2,5316,500,1501902462),
(2,5317,400,1501902462),
(2,5371,2005,1501903495),
(2,5372,2005,1501903495),
(2,5580,1,1501902462),
(2,5589,1,1501902462),
(2,5591,1,1501902462),
(2,6141,1,1501903082),
(2,6142,2,1501903509),
(2,8819,500,1501902462),
(2,8820,500,1501902462),
(2,8821,500,1501902462),
(2,8822,500,1501902462),
(2,9598,80,1501902537),
(2,9683,3100,1501902462),
(2,9684,3100,1501902462),
(2,9685,400,1501902462),
(2,9686,4000,1501902462),
(2,9687,500,1501902462),
(2,12698,120,1502214255),
(3,34,3,1502316938),
(3,35,3,1502316938),
(3,36,3,1502316938),
(3,37,3,1502316938),
(3,38,3,1502316938),
(3,39,3,1502316938),
(3,40,3,1502316938),
(3,41,3,1502316938),
(3,111,2,1502318816),
(3,162,1264,1502317148),
(3,167,1,1501947072),
(3,655,1,1501947072),
(3,753,1,1501947072),
(3,755,1,1501947072),
(3,756,1,1501947072),
(3,834,11,1502316947),
(3,1146,1,1501947115),
(3,1147,1,1502317053),
(3,1149,1,1502317002),
(3,2020,200,1501947072),
(3,2030,4000,1501947072),
(3,2031,3100,1501947072),
(3,2032,3100,1501947072),
(3,2033,3100,1501947072),
(3,2034,3000,1501947072),
(3,4944,24,1502317148),
(3,4946,22,1502317148),
(3,4948,22,1502317148),
(3,4958,2,1502316873),
(3,5212,3,1502316938),
(3,5215,3,1502316938),
(3,5233,3,1502316938),
(3,5301,6,1501947072),
(3,5328,3100,1501947072),
(3,5329,3100,1501947072),
(3,5330,3100,1501947072),
(3,5331,4000,1501947072),
(3,5332,3000,1501947072),
(3,5371,12,1502318042),
(3,5372,1587,1502318815),
(3,5373,58,1502316687),
(3,5374,58,1502316854),
(3,5376,58,1502316854),
(3,5512,24,1502317148),
(3,5529,24,1502317148),
(3,5576,1,1501947072),
(3,5577,1,1501947072),
(3,5580,1,1501947072),
(3,5581,11,1502316947),
(3,5589,1,1501947072),
(3,5593,2,1502318816),
(3,5594,1,1502318816),
(3,8819,500,1501947072),
(3,8820,500,1501947072),
(3,8821,500,1501947072),
(3,8822,500,1501947072),
(3,9598,3,1502316938),
(3,9678,3100,1501947072),
(3,9679,3000,1501947072),
(3,9680,3100,1501947072),
(3,9681,3100,1501947072),
(3,9682,4000,1501947072),
(4,34,1,1501972425),
(4,35,1,1501972425),
(4,36,1,1501972425),
(4,37,1,1501972425),
(4,38,1,1501972425),
(4,39,1,1501972425),
(4,40,1,1501972425),
(4,41,1,1501972425),
(4,111,14,1502322319),
(4,167,1,1501972425),
(4,505,1,1502321865),
(4,514,1,1502301370),
(4,641,1,1501972425),
(4,653,1,1501972425),
(4,655,1,1501972425),
(4,753,1,1501972425),
(4,754,2,1502293239),
(4,755,1,1501972425),
(4,756,1,1501972425),
(4,834,1,1501972425),
(4,1160,1,1502322082),
(4,2020,200,1501972425),
(4,2030,3100,1501972425),
(4,2031,4000,1501972425),
(4,2032,3100,1501972425),
(4,2033,3100,1501972425),
(4,2034,3000,1501972425),
(4,2072,1579,1502322552),
(4,5212,1,1501972425),
(4,5220,1,1501972425),
(4,5232,1,1501972425),
(4,5293,1,1502301370),
(4,5301,6,1501972425),
(4,5328,3100,1501972425),
(4,5329,3100,1501972425),
(4,5330,4000,1501972425),
(4,5331,3100,1501972425),
(4,5332,3000,1501972425),
(4,5371,411,1502322319),
(4,5372,759,1502327532),
(4,5512,6,1502327832),
(4,5529,23,1502327832),
(4,5530,17,1502320544),
(4,5576,1,1501972425),
(4,5577,1,1501972425),
(4,5578,1,1501972425),
(4,5579,2,1502293239),
(4,5580,1,1501972425),
(4,5581,1,1501972425),
(4,5585,1,1501972425),
(4,5589,1,1501972425),
(4,5593,14,1502322319),
(4,8819,500,1501972425),
(4,8820,500,1501972425),
(4,8821,500,1501972425),
(4,8822,500,1501972425),
(4,9598,1,1501972425),
(4,9678,3100,1501972425),
(4,9679,3000,1501972425),
(4,9680,3100,1501972425),
(4,9681,4000,1501972425),
(4,9682,3100,1501972425),
(5,34,1,1502131394),
(5,35,1,1502131394),
(5,36,1,1502131394),
(5,37,1,1502131394),
(5,38,1,1502131394),
(5,39,1,1502131394),
(5,40,1,1502131394),
(5,41,1,1502131394),
(5,167,1,1502131394),
(5,655,1,1502131394),
(5,657,1,1502131394),
(5,756,1,1502131394),
(5,757,1,1502131394),
(5,992,500,1502131394),
(5,993,500,1502131394),
(5,994,3100,1502131394),
(5,995,500,1502131394),
(5,996,4000,1502131394),
(5,1508,1,1502131423),
(5,1884,3500,1502131394),
(5,2020,200,1502131394),
(5,3723,1,1502138047),
(5,4224,100000000,1502138047),
(5,4763,3500,1502131394),
(5,5212,1,1502131394),
(5,5216,1,1502131394),
(5,5230,1,1502131394),
(5,5301,6,1502131394),
(5,5313,500,1502131394),
(5,5314,500,1502131394),
(5,5315,500,1502131394),
(5,5316,3100,1502131394),
(5,5317,4000,1502131394),
(5,5529,2,1502156426),
(5,5530,2,1502156426),
(5,5580,1,1502131394),
(5,5586,1,1502131394),
(5,5589,1,1502131394),
(5,5591,1,1502131394),
(5,8819,500,1502131394),
(5,8820,500,1502131394),
(5,8821,500,1502131394),
(5,8822,500,1502131394),
(5,9598,1,1502131394),
(5,9683,500,1502131394),
(5,9684,500,1502131394),
(5,9685,4000,1502131394),
(5,9686,500,1502131394),
(5,9687,3100,1502131394),
(5,13409,3500,1502131394),
(6,34,80,1502211342),
(6,35,80,1502211342),
(6,36,80,1502211342),
(6,37,80,1502211342),
(6,38,80,1502211342),
(6,39,80,1502211342),
(6,40,80,1502211342),
(6,41,80,1502211342),
(6,162,8,1502210236),
(6,167,1,1502208758),
(6,655,1,1502208758),
(6,753,1,1502208758),
(6,755,1,1502208758),
(6,756,1,1502208758),
(6,834,1,1502208758),
(6,840,75,1502211320),
(6,841,75,1502211320),
(6,842,75,1502211320),
(6,843,75,1502211320),
(6,844,75,1502211320),
(6,1146,1,1502208771),
(6,1149,1,1502210224),
(6,1870,75,1502211347),
(6,1871,75,1502211347),
(6,1872,75,1502211347),
(6,1873,75,1502211347),
(6,2020,200,1502208758),
(6,2030,4000,1502208758),
(6,2031,3100,1502208758),
(6,2032,3100,1502208758),
(6,2033,3100,1502208758),
(6,2034,3000,1502208758),
(6,2341,1,1502210256),
(6,4019,1,1502211394),
(6,4021,1,1502211293),
(6,4224,555555555,1502210229),
(6,4633,1,1502211394),
(6,4787,1,1502211347),
(6,4804,1,1502211293),
(6,5212,80,1502211342),
(6,5215,80,1502211342),
(6,5233,80,1502211342),
(6,5249,1,1502211320),
(6,5301,6,1502208758),
(6,5328,3100,1502208758),
(6,5329,3100,1502208758),
(6,5330,3100,1502208758),
(6,5331,4000,1502208758),
(6,5332,3000,1502208758),
(6,5373,8,1502210236),
(6,5562,1,1502211320),
(6,5576,1,1502208758),
(6,5577,1,1502208758),
(6,5580,1,1502208758),
(6,5581,1,1502208758),
(6,5589,1,1502208758),
(6,5592,1,1502211320),
(6,6142,8,1502211452),
(6,6394,2,1502211320),
(6,7222,2,1502211320),
(6,7550,1,1502211347),
(6,7551,1,1502211347),
(6,7552,1,1502211347),
(6,8819,500,1502208758),
(6,8820,500,1502208758),
(6,8821,500,1502208758),
(6,8822,500,1502208758),
(6,9223,1,1502211347),
(6,9598,80,1502211342),
(6,9678,3100,1502208758),
(6,9679,3000,1502208758),
(6,9680,3100,1502208758),
(6,9681,3100,1502208758),
(6,9682,4000,1502208758),
(6,12698,120,1502211394),
(8,34,1,1502213280),
(8,35,1,1502213280),
(8,36,1,1502213280),
(8,37,1,1502213280),
(8,38,1,1502213280),
(8,39,1,1502213280),
(8,40,1,1502213280),
(8,41,1,1502213280),
(8,164,1,1502213991),
(8,167,1,1502213280),
(8,168,450,1502213991),
(8,612,450,1502213991),
(8,613,450,1502213991),
(8,614,450,1502213991),
(8,615,450,1502213991),
(8,616,450,1502213991),
(8,617,450,1502213991),
(8,618,450,1502213991),
(8,619,450,1502213991),
(8,621,450,1502213991),
(8,622,450,1502213991),
(8,623,450,1502213991),
(8,626,450,1502213991),
(8,641,1,1502213280),
(8,653,1,1502213280),
(8,655,1,1502213280),
(8,753,1,1502213280),
(8,754,1,1502213280),
(8,755,1,1502213280),
(8,756,1,1502213280),
(8,822,1,1502213286),
(8,840,450,1502213991),
(8,841,450,1502213991),
(8,842,450,1502213991),
(8,843,450,1502213991),
(8,844,450,1502213991),
(8,846,1,1502213991),
(8,847,1,1502213991),
(8,848,450,1502213991),
(8,849,450,1502213991),
(8,850,450,1502213991),
(8,851,450,1502213991),
(8,853,450,1502213991),
(8,854,450,1502213991),
(8,855,450,1502213991),
(8,858,450,1502213991),
(8,859,450,1502213991),
(8,860,450,1502213991),
(8,861,450,1502213991),
(8,862,450,1502213991),
(8,864,450,1502213991),
(8,865,450,1502213991),
(8,866,450,1502213991),
(8,869,450,1502213991),
(8,870,450,1502213991),
(8,871,450,1502213991),
(8,872,450,1502213991),
(8,873,450,1502213991),
(8,875,450,1502213991),
(8,876,450,1502213991),
(8,877,450,1502213991),
(8,880,450,1502213991),
(8,881,450,1502213991),
(8,882,450,1502213991),
(8,883,450,1502213991),
(8,884,450,1502213991),
(8,886,450,1502213991),
(8,887,450,1502213991),
(8,888,450,1502213991),
(8,891,450,1502213991),
(8,892,450,1502213991),
(8,893,450,1502213991),
(8,894,450,1502213991),
(8,895,450,1502213991),
(8,897,450,1502213991),
(8,898,450,1502213991),
(8,899,450,1502213991),
(8,902,450,1502213991),
(8,992,4000,1502213280),
(8,993,3100,1502213280),
(8,994,500,1502213280),
(8,995,3100,1502213280),
(8,996,400,1502213280),
(8,2020,200,1502213280),
(8,5212,1,1502213280),
(8,5220,1,1502213280),
(8,5235,1,1502213280),
(8,5240,1,1502213991),
(8,5241,1,1502213991),
(8,5242,1,1502213991),
(8,5243,1,1502213991),
(8,5244,1,1502213991),
(8,5249,1,1502213991),
(8,5252,1,1502213991),
(8,5253,1,1502213991),
(8,5254,1,1502213991),
(8,5257,1,1502213991),
(8,5301,6,1502213280),
(8,5313,3100,1502213280),
(8,5314,4000,1502213280),
(8,5315,3100,1502213280),
(8,5316,500,1502213280),
(8,5317,400,1502213280),
(8,5551,450,1502213991),
(8,5552,450,1502213991),
(8,5553,450,1502213991),
(8,5554,450,1502213991),
(8,5556,450,1502213991),
(8,5557,450,1502213991),
(8,5558,450,1502213991),
(8,5561,450,1502213991),
(8,5562,1,1502213991),
(8,5563,1,1502213991),
(8,5565,1,1502213991),
(8,5566,1,1502213991),
(8,5567,1,1502213991),
(8,5568,1,1502213991),
(8,5570,1,1502213991),
(8,5571,1,1502213991),
(8,5572,1,1502213991),
(8,5575,1,1502213991),
(8,5576,1,1502213280),
(8,5577,1,1502213280),
(8,5578,1,1502213280),
(8,5579,1,1502213280),
(8,5580,1,1502213280),
(8,5585,1,1502213280),
(8,5589,1,1502213280),
(8,5592,1,1502213991),
(8,5701,1,1502213991),
(8,5711,1,1502213991),
(8,5712,1,1502213991),
(8,5713,1,1502213991),
(8,5714,1,1502213991),
(8,5716,1,1502213991),
(8,5717,1,1502213991),
(8,5718,1,1502213991),
(8,5722,1,1502213991),
(8,6618,1,1502213991),
(8,8819,500,1502213280),
(8,8820,500,1502213280),
(8,8821,500,1502213280),
(8,8822,500,1502213280),
(8,9598,1,1502213280),
(8,9683,4000,1502213280),
(8,9684,3100,1502213280),
(8,9685,400,1502213280),
(8,9686,3100,1502213280),
(8,9687,500,1502213280),
(8,12698,160,1502213991);

/*Table structure for table `character_action` */

DROP TABLE IF EXISTS `character_action`;

CREATE TABLE `character_action` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `button` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `action` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spec`,`button`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_action` */

insert  into `character_action`(`guid`,`spec`,`button`,`action`,`type`) values 
(1,0,0,27261,0),
(1,0,1,18389,0),
(1,0,2,69904,0),
(1,0,9,4,64),
(1,0,10,42777,0),
(1,0,11,59752,0),
(2,0,0,2,64),
(2,0,1,3,64),
(2,0,3,1953,0),
(2,0,11,1,64),
(2,0,60,1,65),
(2,0,73,6603,0),
(2,0,76,20549,0),
(2,0,77,1953,0),
(2,0,85,6603,0),
(2,0,97,6603,0),
(2,0,109,6603,0),
(3,0,0,6603,0),
(3,0,1,21084,0),
(3,0,2,635,0),
(3,0,11,59752,0),
(4,0,0,6603,0),
(4,0,1,78,0),
(4,0,72,6603,0),
(4,0,73,78,0),
(4,0,74,20594,0),
(4,0,75,2481,0),
(4,0,76,69904,0),
(4,0,84,6603,0),
(4,0,96,6603,0),
(4,0,108,6603,0),
(5,0,0,585,0),
(5,0,1,2050,0),
(5,0,2,28730,0),
(5,0,10,47757,0),
(5,0,11,3,65),
(5,0,24,2,65),
(5,0,25,5,65),
(5,0,28,12,65),
(5,0,29,11,65),
(5,0,30,9,65),
(5,0,35,7,65),
(5,0,36,1,65),
(5,0,37,4,65),
(5,0,40,6,65),
(5,0,41,10,65),
(5,0,42,8,65),
(5,0,43,14,65),
(5,0,48,15,65),
(5,0,49,49306,0),
(5,0,60,27255,0),
(5,0,61,27261,0),
(5,0,71,13,65),
(6,0,0,6603,0),
(6,0,1,21084,0),
(6,0,2,48782,0),
(6,0,3,3273,0),
(6,0,11,59752,0),
(8,0,0,6603,0),
(8,0,72,6603,0),
(8,0,73,78,0),
(8,0,74,20572,0),
(8,0,75,45542,0),
(8,0,76,45542,0),
(8,0,77,45542,0),
(8,0,78,45542,0),
(8,0,79,45542,0),
(8,0,80,45542,0),
(8,0,81,9788,0),
(8,0,82,9787,0),
(8,0,83,17039,0),
(8,0,84,6603,0),
(8,0,96,6603,0),
(8,0,108,6603,0);

/*Table structure for table `character_arena_stats` */

DROP TABLE IF EXISTS `character_arena_stats`;

CREATE TABLE `character_arena_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `matchMakerRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_arena_stats` */

/*Table structure for table `character_aura` */

DROP TABLE IF EXISTS `character_aura`;

CREATE TABLE `character_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` int(11) NOT NULL DEFAULT '0',
  `amount1` int(11) NOT NULL DEFAULT '0',
  `amount2` int(11) NOT NULL DEFAULT '0',
  `base_amount0` int(11) NOT NULL DEFAULT '0',
  `base_amount1` int(11) NOT NULL DEFAULT '0',
  `base_amount2` int(11) NOT NULL DEFAULT '0',
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_aura` */

insert  into `character_aura`(`guid`,`casterGuid`,`spell`,`effectMask`,`recalculateMask`,`stackCount`,`amount0`,`amount1`,`amount2`,`base_amount0`,`base_amount1`,`base_amount2`,`maxDuration`,`remainTime`,`remainCharges`) values 
(3,3,8326,7,7,1,-20,50,50,-21,49,49,-1,-1,0),
(4,4,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0),
(4,4,2481,1,1,1,0,0,0,0,0,0,-1,-1,0),
(5,5,1908,1,1,1,100,0,0,99,0,0,-1,-1,0),
(5,5,6560,1,1,1,200,0,0,199,0,0,-1,-1,0),
(5,5,35912,7,7,1,54,49,10,53,48,9,-1,-1,0),
(5,5,38734,7,7,1,220,18,10,219,17,9,-1,-1,0),
(8,8,1908,1,1,1,100,0,0,99,0,0,-1,-1,0),
(8,8,18209,1,1,14,140,0,0,9,0,0,604800000,604526518,0),
(8,8,18210,1,1,13,-130,0,0,-11,0,0,604800000,604503263,0);

/*Table structure for table `character_banned` */

DROP TABLE IF EXISTS `character_banned`;

CREATE TABLE `character_banned` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';

/*Data for the table `character_banned` */

/*Table structure for table `character_battleground_data` */

DROP TABLE IF EXISTS `character_battleground_data`;

CREATE TABLE `character_battleground_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `instanceId` int(10) unsigned NOT NULL COMMENT 'Instance Identifier',
  `team` smallint(5) unsigned NOT NULL,
  `joinX` float NOT NULL DEFAULT '0',
  `joinY` float NOT NULL DEFAULT '0',
  `joinZ` float NOT NULL DEFAULT '0',
  `joinO` float NOT NULL DEFAULT '0',
  `joinMapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `taxiStart` int(10) unsigned NOT NULL DEFAULT '0',
  `taxiEnd` int(10) unsigned NOT NULL DEFAULT '0',
  `mountSpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_battleground_data` */

insert  into `character_battleground_data`(`guid`,`instanceId`,`team`,`joinX`,`joinY`,`joinZ`,`joinO`,`joinMapId`,`taxiStart`,`taxiEnd`,`mountSpell`) values 
(1,0,0,0,0,0,0,65535,0,0,0),
(2,0,0,0,0,0,0,65535,0,0,0),
(3,0,0,0,0,0,0,65535,0,0,0),
(4,0,0,0,0,0,0,65535,0,0,0),
(5,0,0,0,0,0,0,65535,0,0,0),
(6,0,0,0,0,0,0,65535,0,0,0),
(8,0,0,0,0,0,0,65535,0,0,0);

/*Table structure for table `character_battleground_random` */

DROP TABLE IF EXISTS `character_battleground_random`;

CREATE TABLE `character_battleground_random` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_battleground_random` */

/*Table structure for table `character_declinedname` */

DROP TABLE IF EXISTS `character_declinedname`;

CREATE TABLE `character_declinedname` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL DEFAULT '',
  `dative` varchar(15) NOT NULL DEFAULT '',
  `accusative` varchar(15) NOT NULL DEFAULT '',
  `instrumental` varchar(15) NOT NULL DEFAULT '',
  `prepositional` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_declinedname` */

/*Table structure for table `character_equipmentsets` */

DROP TABLE IF EXISTS `character_equipmentsets`;

CREATE TABLE `character_equipmentsets` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `setguid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setindex` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(31) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `ignore_mask` int(11) unsigned NOT NULL DEFAULT '0',
  `item0` int(11) unsigned NOT NULL DEFAULT '0',
  `item1` int(11) unsigned NOT NULL DEFAULT '0',
  `item2` int(11) unsigned NOT NULL DEFAULT '0',
  `item3` int(11) unsigned NOT NULL DEFAULT '0',
  `item4` int(11) unsigned NOT NULL DEFAULT '0',
  `item5` int(11) unsigned NOT NULL DEFAULT '0',
  `item6` int(11) unsigned NOT NULL DEFAULT '0',
  `item7` int(11) unsigned NOT NULL DEFAULT '0',
  `item8` int(11) unsigned NOT NULL DEFAULT '0',
  `item9` int(11) unsigned NOT NULL DEFAULT '0',
  `item10` int(11) unsigned NOT NULL DEFAULT '0',
  `item11` int(11) unsigned NOT NULL DEFAULT '0',
  `item12` int(11) unsigned NOT NULL DEFAULT '0',
  `item13` int(11) unsigned NOT NULL DEFAULT '0',
  `item14` int(11) unsigned NOT NULL DEFAULT '0',
  `item15` int(11) unsigned NOT NULL DEFAULT '0',
  `item16` int(11) unsigned NOT NULL DEFAULT '0',
  `item17` int(11) unsigned NOT NULL DEFAULT '0',
  `item18` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_equipmentsets` */

/*Table structure for table `character_fishingsteps` */

DROP TABLE IF EXISTS `character_fishingsteps`;

CREATE TABLE `character_fishingsteps` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `fishingSteps` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_fishingsteps` */

/*Table structure for table `character_gifts` */

DROP TABLE IF EXISTS `character_gifts`;

CREATE TABLE `character_gifts` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_gifts` */

/*Table structure for table `character_glyphs` */

DROP TABLE IF EXISTS `character_glyphs`;

CREATE TABLE `character_glyphs` (
  `guid` int(10) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `glyph1` smallint(5) unsigned DEFAULT '0',
  `glyph2` smallint(5) unsigned DEFAULT '0',
  `glyph3` smallint(5) unsigned DEFAULT '0',
  `glyph4` smallint(5) unsigned DEFAULT '0',
  `glyph5` smallint(5) unsigned DEFAULT '0',
  `glyph6` smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (`guid`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_glyphs` */

insert  into `character_glyphs`(`guid`,`talentGroup`,`glyph1`,`glyph2`,`glyph3`,`glyph4`,`glyph5`,`glyph6`) values 
(1,0,0,0,0,0,0,0),
(2,0,0,0,0,0,0,0),
(3,0,0,0,0,0,0,0),
(4,0,0,0,0,0,0,0),
(5,0,0,0,0,0,0,0),
(6,0,0,0,0,0,0,0),
(8,0,0,0,0,0,0,0);

/*Table structure for table `character_homebind` */

DROP TABLE IF EXISTS `character_homebind`;

CREATE TABLE `character_homebind` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `zoneId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Zone Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_homebind` */

insert  into `character_homebind`(`guid`,`mapId`,`zoneId`,`posX`,`posY`,`posZ`) values 
(1,0,12,-8949.95,-132.493,83.5312),
(2,1,215,-2917.58,-257.98,52.9968),
(3,0,12,-8949.95,-132.493,83.5312),
(4,0,1,-6240.32,331.033,382.758),
(5,530,3431,10349.6,-6357.29,33.4026),
(6,0,12,-8949.95,-132.493,83.5312),
(8,1,14,-618.518,-4251.67,38.718);

/*Table structure for table `character_instance` */

DROP TABLE IF EXISTS `character_instance`;

CREATE TABLE `character_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `extendState` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_instance` */

/*Table structure for table `character_inventory` */

DROP TABLE IF EXISTS `character_inventory`;

CREATE TABLE `character_inventory` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bag` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Global Unique Identifier',
  PRIMARY KEY (`item`),
  UNIQUE KEY `guid` (`guid`,`bag`,`slot`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_inventory` */

insert  into `character_inventory`(`guid`,`bag`,`slot`,`item`) values 
(1,0,3,155),
(1,0,4,32),
(1,0,6,4),
(1,0,7,34),
(1,0,15,156),
(1,0,19,158),
(1,0,20,157),
(1,0,21,160),
(1,0,22,159),
(1,0,23,12),
(1,0,24,2),
(1,0,25,33),
(1,0,26,6),
(1,0,27,8),
(1,0,28,10),
(1,0,29,40),
(1,0,30,161),
(1,0,31,164),
(1,0,32,165),
(1,0,118,162),
(2,0,0,30),
(2,0,4,28),
(2,0,6,18),
(2,0,7,31),
(2,0,15,39),
(2,0,23,20),
(2,0,24,41),
(2,0,26,72),
(2,0,27,66),
(2,0,30,71),
(2,0,31,64),
(3,0,3,44),
(3,0,6,48),
(3,0,7,46),
(3,0,15,52),
(3,0,23,50),
(3,0,24,187),
(3,0,25,188),
(4,0,3,54),
(4,0,6,56),
(4,0,7,58),
(4,0,15,60),
(4,0,23,62),
(5,0,0,90),
(5,0,2,99),
(5,0,4,93),
(5,0,5,101),
(5,0,6,96),
(5,0,7,95),
(5,0,10,102),
(5,0,14,94),
(5,0,16,91),
(5,0,23,86),
(5,0,24,76),
(5,0,25,82),
(5,0,26,78),
(5,0,28,84),
(5,0,29,80),
(5,0,30,92),
(5,0,31,88),
(5,0,32,98),
(5,0,33,100),
(5,0,34,97),
(5,0,37,89),
(6,0,0,115),
(6,0,2,118),
(6,0,3,104),
(6,0,4,113),
(6,0,5,119),
(6,0,6,117),
(6,0,7,121),
(6,0,8,120),
(6,0,9,116),
(6,0,15,112),
(6,0,23,110),
(6,0,24,108),
(6,0,25,106),
(6,0,26,147),
(6,0,27,148),
(6,0,28,149),
(6,0,29,146),
(8,0,3,133),
(8,0,6,135),
(8,0,7,137),
(8,0,15,141),
(8,0,19,143),
(8,0,20,144),
(8,0,21,142),
(8,0,22,145),
(8,0,23,139),
(8,0,24,150),
(8,0,25,151),
(8,0,26,152),
(8,0,27,153),
(8,0,28,154);

/*Table structure for table `character_pet` */

DROP TABLE IF EXISTS `character_pet`;

CREATE TABLE `character_pet` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` int(10) unsigned DEFAULT '0',
  `CreatedBySpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `PetType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` smallint(5) unsigned NOT NULL DEFAULT '1',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `Reactstate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(21) NOT NULL DEFAULT 'Pet',
  `renamed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `curhealth` int(10) unsigned NOT NULL DEFAULT '1',
  `curmana` int(10) unsigned NOT NULL DEFAULT '0',
  `curhappiness` int(10) unsigned NOT NULL DEFAULT '0',
  `savetime` int(10) unsigned NOT NULL DEFAULT '0',
  `abdata` text,
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`),
  KEY `idx_slot` (`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

/*Data for the table `character_pet` */

/*Table structure for table `character_pet_declinedname` */

DROP TABLE IF EXISTS `character_pet_declinedname`;

CREATE TABLE `character_pet_declinedname` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `genitive` varchar(12) NOT NULL DEFAULT '',
  `dative` varchar(12) NOT NULL DEFAULT '',
  `accusative` varchar(12) NOT NULL DEFAULT '',
  `instrumental` varchar(12) NOT NULL DEFAULT '',
  `prepositional` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_pet_declinedname` */

/*Table structure for table `character_queststatus` */

DROP TABLE IF EXISTS `character_queststatus`;

CREATE TABLE `character_queststatus` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `explored` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timer` int(10) unsigned NOT NULL DEFAULT '0',
  `mobcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playercount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus` */

insert  into `character_queststatus`(`guid`,`quest`,`status`,`explored`,`timer`,`mobcount1`,`mobcount2`,`mobcount3`,`mobcount4`,`itemcount1`,`itemcount2`,`itemcount3`,`itemcount4`,`playercount`) values 
(3,783,1,0,1502316895,0,0,0,0,0,0,0,0,0),
(6,783,1,0,1502208806,0,0,0,0,0,0,0,0,0);

/*Table structure for table `character_queststatus_daily` */

DROP TABLE IF EXISTS `character_queststatus_daily`;

CREATE TABLE `character_queststatus_daily` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus_daily` */

/*Table structure for table `character_queststatus_monthly` */

DROP TABLE IF EXISTS `character_queststatus_monthly`;

CREATE TABLE `character_queststatus_monthly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus_monthly` */

/*Table structure for table `character_queststatus_rewarded` */

DROP TABLE IF EXISTS `character_queststatus_rewarded`;

CREATE TABLE `character_queststatus_rewarded` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `active` tinyint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus_rewarded` */

/*Table structure for table `character_queststatus_seasonal` */

DROP TABLE IF EXISTS `character_queststatus_seasonal`;

CREATE TABLE `character_queststatus_seasonal` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `event` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus_seasonal` */

/*Table structure for table `character_queststatus_weekly` */

DROP TABLE IF EXISTS `character_queststatus_weekly`;

CREATE TABLE `character_queststatus_weekly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_queststatus_weekly` */

/*Table structure for table `character_reputation` */

DROP TABLE IF EXISTS `character_reputation`;

CREATE TABLE `character_reputation` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `faction` smallint(5) unsigned NOT NULL DEFAULT '0',
  `standing` int(11) NOT NULL DEFAULT '0',
  `flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_reputation` */

insert  into `character_reputation`(`guid`,`faction`,`standing`,`flags`) values 
(1,21,0,64),
(1,46,0,4),
(1,47,0,17),
(1,54,0,17),
(1,59,0,16),
(1,67,0,14),
(1,68,0,6),
(1,69,0,17),
(1,70,0,2),
(1,72,0,17),
(1,76,0,6),
(1,81,0,6),
(1,83,0,4),
(1,86,0,4),
(1,87,0,2),
(1,92,0,2),
(1,93,0,2),
(1,169,0,12),
(1,270,0,16),
(1,289,0,4),
(1,349,0,0),
(1,369,0,64),
(1,469,0,25),
(1,470,0,64),
(1,471,0,20),
(1,509,0,16),
(1,510,0,2),
(1,529,0,0),
(1,530,0,6),
(1,549,0,4),
(1,550,0,4),
(1,551,0,4),
(1,569,0,4),
(1,570,0,4),
(1,571,0,4),
(1,574,0,4),
(1,576,0,2),
(1,577,0,64),
(1,589,0,0),
(1,609,0,0),
(1,729,0,2),
(1,730,0,16),
(1,749,0,0),
(1,809,0,16),
(1,889,0,6),
(1,890,0,16),
(1,891,0,24),
(1,892,0,14),
(1,909,0,16),
(1,910,0,2),
(1,911,0,6),
(1,922,0,6),
(1,930,0,17),
(1,932,0,80),
(1,933,0,16),
(1,934,0,80),
(1,935,0,16),
(1,936,0,28),
(1,941,0,6),
(1,942,0,16),
(1,946,0,16),
(1,947,0,2),
(1,948,0,8),
(1,949,0,24),
(1,952,0,0),
(1,967,0,16),
(1,970,0,0),
(1,978,0,16),
(1,980,0,0),
(1,989,0,16),
(1,990,0,16),
(1,1005,0,4),
(1,1011,0,16),
(1,1012,0,16),
(1,1015,0,2),
(1,1031,0,16),
(1,1037,4053,137),
(1,1038,0,16),
(1,1050,2023,17),
(1,1052,0,2),
(1,1064,0,6),
(1,1067,0,2),
(1,1068,2023,17),
(1,1073,0,16),
(1,1077,0,16),
(1,1082,0,4),
(1,1085,0,6),
(1,1090,0,16),
(1,1091,0,16),
(1,1094,2023,17),
(1,1097,0,0),
(1,1098,0,16),
(1,1104,0,16),
(1,1105,0,16),
(1,1106,0,16),
(1,1117,0,12),
(1,1118,0,12),
(1,1119,0,2),
(1,1124,0,6),
(1,1126,2023,17),
(1,1136,0,4),
(1,1137,0,4),
(1,1154,0,4),
(1,1155,0,4),
(1,1156,0,16),
(2,21,0,64),
(2,46,0,4),
(2,47,0,6),
(2,54,0,6),
(2,59,0,16),
(2,67,0,25),
(2,68,0,17),
(2,69,0,6),
(2,70,0,2),
(2,72,0,6),
(2,76,0,17),
(2,81,0,17),
(2,83,0,4),
(2,86,0,4),
(2,87,0,2),
(2,92,0,2),
(2,93,0,2),
(2,169,0,12),
(2,270,0,16),
(2,289,0,4),
(2,349,0,0),
(2,369,0,64),
(2,469,0,14),
(2,470,0,64),
(2,471,0,22),
(2,509,0,2),
(2,510,0,16),
(2,529,0,0),
(2,530,0,17),
(2,549,0,4),
(2,550,0,4),
(2,551,0,4),
(2,569,0,4),
(2,570,0,4),
(2,571,0,4),
(2,574,0,4),
(2,576,0,2),
(2,577,0,64),
(2,589,0,6),
(2,609,0,0),
(2,729,0,16),
(2,730,0,2),
(2,749,0,0),
(2,809,0,16),
(2,889,0,16),
(2,890,0,6),
(2,891,0,14),
(2,892,0,24),
(2,909,0,16),
(2,910,0,2),
(2,911,0,17),
(2,922,0,16),
(2,930,0,6),
(2,932,0,80),
(2,933,0,16),
(2,934,0,80),
(2,935,0,16),
(2,936,0,28),
(2,941,0,16),
(2,942,0,16),
(2,946,0,2),
(2,947,0,16),
(2,948,0,8),
(2,949,0,24),
(2,952,0,0),
(2,967,0,16),
(2,970,0,0),
(2,978,0,2),
(2,980,0,0),
(2,989,0,16),
(2,990,0,16),
(2,1005,0,4),
(2,1011,0,16),
(2,1012,0,16),
(2,1015,0,2),
(2,1031,0,16),
(2,1037,0,6),
(2,1038,0,16),
(2,1050,0,6),
(2,1052,0,152),
(2,1064,0,16),
(2,1067,0,16),
(2,1068,0,6),
(2,1073,0,16),
(2,1077,0,16),
(2,1082,0,2),
(2,1085,0,16),
(2,1090,0,17),
(2,1091,0,16),
(2,1094,0,6),
(2,1097,0,0),
(2,1098,0,16),
(2,1104,0,16),
(2,1105,0,16),
(2,1106,0,16),
(2,1117,0,12),
(2,1118,0,12),
(2,1119,0,2),
(2,1124,0,16),
(2,1126,0,2),
(2,1136,0,4),
(2,1137,0,4),
(2,1154,0,4),
(2,1155,0,4),
(2,1156,0,16),
(3,21,0,64),
(3,46,0,4),
(3,47,0,17),
(3,54,0,17),
(3,59,0,16),
(3,67,0,14),
(3,68,0,6),
(3,69,0,17),
(3,70,0,2),
(3,72,0,17),
(3,76,0,6),
(3,81,0,6),
(3,83,0,4),
(3,86,0,4),
(3,87,0,2),
(3,92,0,2),
(3,93,0,2),
(3,169,0,12),
(3,270,0,16),
(3,289,0,4),
(3,349,0,0),
(3,369,0,64),
(3,469,0,25),
(3,470,0,64),
(3,471,0,20),
(3,509,0,16),
(3,510,0,2),
(3,529,0,0),
(3,530,0,6),
(3,549,0,4),
(3,550,0,4),
(3,551,0,4),
(3,569,0,4),
(3,570,0,4),
(3,571,0,4),
(3,574,0,4),
(3,576,0,2),
(3,577,0,64),
(3,589,0,0),
(3,609,0,0),
(3,729,0,2),
(3,730,0,16),
(3,749,0,0),
(3,809,0,16),
(3,889,0,6),
(3,890,0,16),
(3,891,0,24),
(3,892,0,14),
(3,909,0,16),
(3,910,0,2),
(3,911,0,6),
(3,922,0,6),
(3,930,0,17),
(3,932,0,80),
(3,933,0,16),
(3,934,0,80),
(3,935,0,16),
(3,936,0,28),
(3,941,0,6),
(3,942,0,16),
(3,946,0,16),
(3,947,0,2),
(3,948,0,8),
(3,949,0,24),
(3,952,0,0),
(3,967,0,16),
(3,970,0,0),
(3,978,0,16),
(3,980,0,0),
(3,989,0,16),
(3,990,0,16),
(3,1005,0,4),
(3,1011,0,16),
(3,1012,0,16),
(3,1015,0,2),
(3,1031,0,16),
(3,1037,0,136),
(3,1038,0,16),
(3,1050,0,16),
(3,1052,0,2),
(3,1064,0,6),
(3,1067,0,2),
(3,1068,0,16),
(3,1073,0,16),
(3,1077,0,16),
(3,1082,0,4),
(3,1085,0,6),
(3,1090,0,17),
(3,1091,0,16),
(3,1094,0,16),
(3,1097,0,0),
(3,1098,0,16),
(3,1104,0,16),
(3,1105,0,16),
(3,1106,0,16),
(3,1117,0,12),
(3,1118,0,12),
(3,1119,0,2),
(3,1124,0,6),
(3,1126,0,16),
(3,1136,0,4),
(3,1137,0,4),
(3,1154,0,4),
(3,1155,0,4),
(3,1156,0,16),
(4,21,0,64),
(4,46,0,4),
(4,47,0,17),
(4,54,0,17),
(4,59,0,16),
(4,67,0,14),
(4,68,0,6),
(4,69,0,17),
(4,70,0,2),
(4,72,0,17),
(4,76,0,6),
(4,81,0,6),
(4,83,0,4),
(4,86,0,4),
(4,87,0,2),
(4,92,0,2),
(4,93,0,2),
(4,169,0,12),
(4,270,0,16),
(4,289,0,4),
(4,349,0,0),
(4,369,0,64),
(4,469,0,25),
(4,470,0,64),
(4,471,0,4),
(4,509,0,16),
(4,510,0,2),
(4,529,0,0),
(4,530,0,6),
(4,549,0,4),
(4,550,0,4),
(4,551,0,4),
(4,569,0,4),
(4,570,0,4),
(4,571,0,4),
(4,574,0,4),
(4,576,0,2),
(4,577,0,64),
(4,589,0,0),
(4,609,0,0),
(4,729,0,2),
(4,730,0,16),
(4,749,0,0),
(4,809,0,16),
(4,889,0,6),
(4,890,0,16),
(4,891,0,24),
(4,892,0,14),
(4,909,0,16),
(4,910,0,2),
(4,911,0,6),
(4,922,0,6),
(4,930,0,17),
(4,932,0,80),
(4,933,0,16),
(4,934,0,80),
(4,935,0,16),
(4,936,0,28),
(4,941,0,6),
(4,942,0,16),
(4,946,0,16),
(4,947,0,2),
(4,948,0,8),
(4,949,0,24),
(4,952,0,0),
(4,967,0,16),
(4,970,0,0),
(4,978,0,16),
(4,980,0,0),
(4,989,0,16),
(4,990,0,16),
(4,1005,0,4),
(4,1011,0,16),
(4,1012,0,16),
(4,1015,0,2),
(4,1031,0,16),
(4,1037,0,136),
(4,1038,0,16),
(4,1050,0,16),
(4,1052,0,2),
(4,1064,0,6),
(4,1067,0,2),
(4,1068,0,16),
(4,1073,0,16),
(4,1077,0,16),
(4,1082,0,4),
(4,1085,0,6),
(4,1090,0,16),
(4,1091,0,16),
(4,1094,0,16),
(4,1097,0,0),
(4,1098,0,16),
(4,1104,0,16),
(4,1105,0,16),
(4,1106,0,16),
(4,1117,0,12),
(4,1118,0,12),
(4,1119,0,2),
(4,1124,0,6),
(4,1126,0,16),
(4,1136,0,4),
(4,1137,0,4),
(4,1154,0,4),
(4,1155,0,4),
(4,1156,0,16),
(5,21,0,64),
(5,46,0,4),
(5,47,0,6),
(5,54,0,6),
(5,59,0,16),
(5,67,0,25),
(5,68,0,17),
(5,69,0,6),
(5,70,0,2),
(5,72,0,6),
(5,76,0,17),
(5,81,0,17),
(5,83,0,4),
(5,86,0,4),
(5,87,0,2),
(5,92,0,2),
(5,93,0,2),
(5,169,0,12),
(5,270,0,16),
(5,289,0,4),
(5,349,0,0),
(5,369,0,64),
(5,469,0,14),
(5,470,0,64),
(5,471,0,22),
(5,509,0,2),
(5,510,0,16),
(5,529,0,0),
(5,530,0,17),
(5,549,0,4),
(5,550,0,4),
(5,551,0,4),
(5,569,0,4),
(5,570,0,4),
(5,571,0,4),
(5,574,0,4),
(5,576,0,2),
(5,577,0,64),
(5,589,0,6),
(5,609,0,0),
(5,729,0,16),
(5,730,0,2),
(5,749,0,0),
(5,809,0,16),
(5,889,0,16),
(5,890,0,6),
(5,891,0,0),
(5,892,0,24),
(5,909,0,16),
(5,910,0,2),
(5,911,0,17),
(5,922,0,16),
(5,930,0,6),
(5,932,0,80),
(5,933,0,16),
(5,934,0,80),
(5,935,0,16),
(5,936,0,28),
(5,941,0,16),
(5,942,0,16),
(5,946,0,2),
(5,947,0,16),
(5,948,0,8),
(5,949,0,24),
(5,952,0,0),
(5,967,0,16),
(5,970,0,0),
(5,978,0,2),
(5,980,0,0),
(5,989,0,16),
(5,990,0,16),
(5,1005,0,4),
(5,1011,0,16),
(5,1012,0,16),
(5,1015,0,2),
(5,1031,0,16),
(5,1037,0,6),
(5,1038,0,16),
(5,1050,0,6),
(5,1052,0,152),
(5,1064,0,16),
(5,1067,0,16),
(5,1068,0,6),
(5,1073,0,16),
(5,1077,0,16),
(5,1082,0,2),
(5,1085,0,16),
(5,1090,0,16),
(5,1091,0,16),
(5,1094,0,6),
(5,1097,0,0),
(5,1098,0,16),
(5,1104,0,16),
(5,1105,0,16),
(5,1106,0,16),
(5,1117,0,12),
(5,1118,0,12),
(5,1119,0,2),
(5,1124,0,16),
(5,1126,0,2),
(5,1136,0,4),
(5,1137,0,4),
(5,1154,0,4),
(5,1155,0,4),
(5,1156,0,16),
(6,21,0,64),
(6,46,0,4),
(6,47,0,17),
(6,54,0,17),
(6,59,0,16),
(6,67,0,14),
(6,68,0,6),
(6,69,0,17),
(6,70,0,2),
(6,72,0,17),
(6,76,0,6),
(6,81,0,6),
(6,83,0,4),
(6,86,0,4),
(6,87,0,2),
(6,92,0,2),
(6,93,0,2),
(6,169,0,12),
(6,270,0,16),
(6,289,0,4),
(6,349,0,0),
(6,369,0,64),
(6,469,0,25),
(6,470,0,64),
(6,471,0,20),
(6,509,0,16),
(6,510,0,2),
(6,529,0,0),
(6,530,0,6),
(6,549,0,4),
(6,550,0,4),
(6,551,0,4),
(6,569,0,4),
(6,570,0,4),
(6,571,0,4),
(6,574,0,4),
(6,576,0,2),
(6,577,0,64),
(6,589,0,0),
(6,609,0,0),
(6,729,0,2),
(6,730,0,16),
(6,749,0,0),
(6,809,0,16),
(6,889,0,6),
(6,890,0,16),
(6,891,0,24),
(6,892,0,14),
(6,909,0,16),
(6,910,0,2),
(6,911,0,6),
(6,922,0,6),
(6,930,0,17),
(6,932,0,80),
(6,933,0,16),
(6,934,0,80),
(6,935,0,16),
(6,936,0,28),
(6,941,0,6),
(6,942,0,16),
(6,946,0,16),
(6,947,0,2),
(6,948,0,8),
(6,949,0,24),
(6,952,0,0),
(6,967,0,16),
(6,970,0,0),
(6,978,0,16),
(6,980,0,0),
(6,989,0,16),
(6,990,0,16),
(6,1005,0,4),
(6,1011,0,16),
(6,1012,0,16),
(6,1015,0,2),
(6,1031,0,16),
(6,1037,0,136),
(6,1038,0,16),
(6,1050,0,16),
(6,1052,0,2),
(6,1064,0,6),
(6,1067,0,2),
(6,1068,0,16),
(6,1073,0,16),
(6,1077,0,16),
(6,1082,0,4),
(6,1085,0,6),
(6,1090,0,16),
(6,1091,0,16),
(6,1094,0,16),
(6,1097,0,0),
(6,1098,0,16),
(6,1104,0,16),
(6,1105,0,16),
(6,1106,0,16),
(6,1117,0,12),
(6,1118,0,12),
(6,1119,0,2),
(6,1124,0,6),
(6,1126,0,16),
(6,1136,0,4),
(6,1137,0,4),
(6,1154,0,4),
(6,1155,0,4),
(6,1156,0,16),
(8,21,0,64),
(8,46,0,4),
(8,47,0,6),
(8,54,0,6),
(8,59,0,16),
(8,67,0,25),
(8,68,0,17),
(8,69,0,6),
(8,70,0,2),
(8,72,0,6),
(8,76,0,17),
(8,81,0,17),
(8,83,0,4),
(8,86,0,4),
(8,87,0,2),
(8,92,0,2),
(8,93,0,2),
(8,169,0,12),
(8,270,0,16),
(8,289,0,4),
(8,349,0,0),
(8,369,0,64),
(8,469,0,14),
(8,470,0,64),
(8,471,0,22),
(8,509,0,2),
(8,510,0,16),
(8,529,0,0),
(8,530,0,17),
(8,549,0,4),
(8,550,0,4),
(8,551,0,4),
(8,569,0,4),
(8,570,0,4),
(8,571,0,4),
(8,574,0,4),
(8,576,0,2),
(8,577,0,64),
(8,589,0,6),
(8,609,0,0),
(8,729,0,16),
(8,730,0,2),
(8,749,0,0),
(8,809,0,16),
(8,889,0,16),
(8,890,0,6),
(8,891,0,14),
(8,892,0,24),
(8,909,0,16),
(8,910,0,2),
(8,911,0,17),
(8,922,0,16),
(8,930,0,6),
(8,932,0,80),
(8,933,0,16),
(8,934,0,80),
(8,935,0,16),
(8,936,0,28),
(8,941,0,16),
(8,942,0,16),
(8,946,0,2),
(8,947,0,16),
(8,948,0,8),
(8,949,0,24),
(8,952,0,0),
(8,967,0,16),
(8,970,0,0),
(8,978,0,2),
(8,980,0,0),
(8,989,0,16),
(8,990,0,16),
(8,1005,0,4),
(8,1011,0,16),
(8,1012,0,16),
(8,1015,0,2),
(8,1031,0,16),
(8,1037,0,6),
(8,1038,0,16),
(8,1050,0,6),
(8,1052,0,152),
(8,1064,0,16),
(8,1067,0,16),
(8,1068,0,6),
(8,1073,0,16),
(8,1077,0,16),
(8,1082,0,2),
(8,1085,0,16),
(8,1090,0,16),
(8,1091,0,16),
(8,1094,0,6),
(8,1097,0,0),
(8,1098,0,16),
(8,1104,0,16),
(8,1105,0,16),
(8,1106,0,16),
(8,1117,0,12),
(8,1118,0,12),
(8,1119,0,2),
(8,1124,0,16),
(8,1126,0,2),
(8,1136,0,4),
(8,1137,0,4),
(8,1154,0,4),
(8,1155,0,4),
(8,1156,0,16);

/*Table structure for table `character_skills` */

DROP TABLE IF EXISTS `character_skills`;

CREATE TABLE `character_skills` (
  `guid` int(10) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` smallint(5) unsigned NOT NULL,
  `value` smallint(5) unsigned NOT NULL,
  `max` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_skills` */

insert  into `character_skills`(`guid`,`skill`,`value`,`max`) values 
(1,6,5,1275),
(1,8,5,1275),
(1,43,8,1275),
(1,95,540,1275),
(1,98,300,300),
(1,136,1,1275),
(1,162,1,1275),
(1,173,1,1275),
(1,183,5,1275),
(1,228,1,1275),
(1,237,5,1275),
(1,415,1,1),
(1,754,5,1275),
(1,769,1,1275),
(1,777,1,1275),
(1,778,1,1275),
(2,54,1,425),
(2,95,1,425),
(2,109,300,300),
(2,115,300,300),
(2,124,5,425),
(2,134,5,425),
(2,136,1,425),
(2,162,1,425),
(2,183,5,425),
(2,414,1,1),
(2,415,1,1),
(2,573,5,425),
(2,574,5,425),
(2,762,300,300),
(2,769,1,425),
(2,777,1,425),
(2,778,1,425),
(3,43,1,15),
(3,54,1,15),
(3,55,1,15),
(3,95,15,15),
(3,98,300,300),
(3,160,11,15),
(3,162,1,15),
(3,183,5,15),
(3,184,5,15),
(3,267,5,15),
(3,413,1,1),
(3,414,1,1),
(3,415,1,1),
(3,433,1,1),
(3,594,5,15),
(3,754,5,15),
(3,777,1,15),
(3,778,1,15),
(4,26,5,5),
(4,43,1,5),
(4,44,1,5),
(4,54,1,5),
(4,55,1,5),
(4,95,5,5),
(4,98,300,300),
(4,101,5,5),
(4,111,300,300),
(4,160,1,5),
(4,162,1,5),
(4,172,2,5),
(4,173,1,5),
(4,183,5,5),
(4,256,5,5),
(4,257,5,5),
(4,413,1,1),
(4,414,1,1),
(4,415,1,1),
(4,433,1,1),
(4,777,1,5),
(4,778,1,5),
(5,54,1,400),
(5,56,5,400),
(5,78,5,400),
(5,95,1,400),
(5,109,300,300),
(5,136,1,400),
(5,137,300,300),
(5,162,1,400),
(5,183,5,400),
(5,228,1,400),
(5,415,1,1),
(5,613,5,400),
(5,756,5,400),
(5,769,1,75),
(5,777,1,400),
(5,778,1,400),
(6,43,1,400),
(6,54,1,400),
(6,55,1,400),
(6,95,1,400),
(6,98,300,300),
(6,129,1,75),
(6,160,1,400),
(6,162,1,400),
(6,183,5,400),
(6,184,5,400),
(6,267,5,400),
(6,293,1,1),
(6,413,1,1),
(6,414,1,1),
(6,415,1,1),
(6,433,1,1),
(6,594,5,400),
(6,754,5,400),
(6,762,75,75),
(6,777,1,400),
(6,778,1,400),
(8,26,5,5),
(8,43,1,5),
(8,44,1,5),
(8,54,1,5),
(8,55,1,5),
(8,95,1,5),
(8,109,300,300),
(8,125,5,5),
(8,129,1,450),
(8,138,300,300),
(8,140,300,300),
(8,162,1,5),
(8,164,1,450),
(8,165,1,450),
(8,171,1,450),
(8,172,1,5),
(8,173,1,5),
(8,183,5,5),
(8,185,1,450),
(8,197,1,450),
(8,202,1,450),
(8,256,5,5),
(8,257,5,5),
(8,333,1,450),
(8,413,1,1),
(8,414,1,1),
(8,415,1,1),
(8,433,1,1),
(8,755,1,450),
(8,769,1,75),
(8,773,1,450),
(8,777,1,5),
(8,778,1,5);

/*Table structure for table `character_social` */

DROP TABLE IF EXISTS `character_social`;

CREATE TABLE `character_social` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL DEFAULT '' COMMENT 'Friend Note',
  PRIMARY KEY (`guid`,`friend`,`flags`),
  KEY `friend` (`friend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_social` */

insert  into `character_social`(`guid`,`friend`,`flags`,`note`) values 
(1,2,1,''),
(1,3,1,''),
(1,4,1,''),
(4,1,1,'');

/*Table structure for table `character_spell` */

DROP TABLE IF EXISTS `character_spell`;

CREATE TABLE `character_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `character_spell` */

insert  into `character_spell`(`guid`,`spell`,`active`,`disabled`) values 
(1,5,1,0),
(1,265,1,0),
(1,1908,1,0),
(1,6560,1,0),
(1,7482,1,0),
(1,8295,1,0),
(1,10073,1,0),
(1,11821,1,0),
(1,18209,1,0),
(1,18210,1,0),
(1,18389,1,0),
(1,19901,1,0),
(1,23789,1,0),
(1,25565,1,0),
(1,26368,1,0),
(1,27254,1,0),
(1,27255,1,0),
(1,27258,1,0),
(1,27261,1,0),
(1,33153,1,0),
(1,35182,1,0),
(1,35886,1,0),
(1,35912,1,0),
(1,36356,1,0),
(1,38505,1,0),
(1,38734,1,0),
(1,39258,1,0),
(1,42777,1,0),
(1,45645,1,0),
(1,45646,1,0),
(1,45647,1,0),
(1,45648,1,0),
(1,45649,1,0),
(1,45650,1,0),
(1,45659,1,0),
(1,45813,1,0),
(1,69904,1,0),
(2,5,1,0),
(2,201,1,0),
(2,202,1,0),
(2,265,1,0),
(2,768,1,0),
(2,770,1,0),
(2,783,1,0),
(2,1066,1,0),
(2,1178,1,0),
(2,1908,1,0),
(2,1953,1,0),
(2,2782,1,0),
(2,2893,1,0),
(2,3025,1,0),
(2,5209,1,0),
(2,5215,1,0),
(2,5229,1,0),
(2,5420,1,0),
(2,5421,1,0),
(2,6560,1,0),
(2,6795,1,0),
(2,7482,1,0),
(2,8295,1,0),
(2,8946,1,0),
(2,8983,1,0),
(2,9634,1,0),
(2,9635,1,0),
(2,10073,1,0),
(2,11821,1,0),
(2,16818,1,0),
(2,16820,1,0),
(2,16822,1,0),
(2,16835,1,0),
(2,16840,1,0),
(2,16847,1,0),
(2,16857,1,0),
(2,16862,1,0),
(2,16864,1,0),
(2,16899,1,0),
(2,16913,1,0),
(2,16924,1,0),
(2,16931,1,0),
(2,16938,1,0),
(2,16941,1,0),
(2,16944,1,0),
(2,16949,1,0),
(2,16954,1,0),
(2,16961,1,0),
(2,16968,1,0),
(2,16975,1,0),
(2,16979,1,0),
(2,16999,1,0),
(2,17007,1,0),
(2,17051,1,0),
(2,17061,1,0),
(2,17066,1,0),
(2,17073,1,0),
(2,17078,1,0),
(2,17108,1,0),
(2,17113,1,0),
(2,17116,1,0),
(2,17120,1,0),
(2,17124,1,0),
(2,18209,1,0),
(2,18210,1,0),
(2,18389,1,0),
(2,18562,1,0),
(2,18658,1,0),
(2,18960,1,0),
(2,19901,1,0),
(2,21178,1,0),
(2,22812,1,0),
(2,22842,1,0),
(2,23789,1,0),
(2,24858,1,0),
(2,24866,1,0),
(2,24894,1,0),
(2,24905,1,0),
(2,24907,1,0),
(2,24946,1,0),
(2,24972,1,0),
(2,25565,1,0),
(2,26368,1,0),
(2,26995,1,0),
(2,27254,1,0),
(2,27255,1,0),
(2,27258,1,0),
(2,27261,1,0),
(2,29166,1,0),
(2,33153,1,0),
(2,33357,1,0),
(2,33591,1,0),
(2,33596,1,0),
(2,33602,1,0),
(2,33607,1,0),
(2,33786,1,0),
(2,33831,1,0),
(2,33856,1,0),
(2,33867,1,0),
(2,33873,1,0),
(2,33880,1,0),
(2,33883,1,0),
(2,33890,1,0),
(2,33891,1,0),
(2,33917,1,0),
(2,33956,1,0),
(2,33957,1,0),
(2,34091,1,0),
(2,34153,1,0),
(2,34300,1,0),
(2,35182,1,0),
(2,35364,1,0),
(2,35886,1,0),
(2,35912,1,0),
(2,36356,1,0),
(2,37117,1,0),
(2,38505,1,0),
(2,38734,1,0),
(2,39258,1,0),
(2,40120,1,0),
(2,45645,1,0),
(2,45646,1,0),
(2,45647,1,0),
(2,45648,1,0),
(2,45649,1,0),
(2,45650,1,0),
(2,45659,1,0),
(2,45813,1,0),
(2,48378,1,0),
(2,48393,1,0),
(2,48396,1,0),
(2,48410,1,0),
(2,48412,1,0),
(2,48441,1,0),
(2,48443,1,0),
(2,48445,1,0),
(2,48447,1,0),
(2,48451,1,0),
(2,48461,1,0),
(2,48463,1,0),
(2,48465,1,0),
(2,48466,1,0),
(2,48467,1,0),
(2,48468,1,0),
(2,48469,1,0),
(2,48470,1,0),
(2,48477,1,0),
(2,48480,1,0),
(2,48485,1,0),
(2,48491,1,0),
(2,48495,1,0),
(2,48500,1,0),
(2,48511,1,0),
(2,48514,1,0),
(2,48525,1,0),
(2,48537,1,0),
(2,48545,1,0),
(2,48560,1,0),
(2,48562,1,0),
(2,48564,1,0),
(2,48566,1,0),
(2,48568,1,0),
(2,48570,1,0),
(2,48572,1,0),
(2,48574,1,0),
(2,48575,1,0),
(2,48577,1,0),
(2,48579,1,0),
(2,49376,1,0),
(2,49377,1,0),
(2,49800,1,0),
(2,49802,1,0),
(2,49803,1,0),
(2,50213,1,0),
(2,50322,1,0),
(2,50334,1,0),
(2,50464,1,0),
(2,50763,1,0),
(2,51183,1,0),
(2,51269,1,0),
(2,52610,1,0),
(2,53201,1,0),
(2,53227,1,0),
(2,53251,1,0),
(2,53307,1,0),
(2,53308,1,0),
(2,53312,1,0),
(2,54197,1,0),
(2,57814,1,0),
(2,57851,1,0),
(2,57865,1,0),
(2,57877,1,0),
(2,57881,1,0),
(2,61230,1,0),
(2,61336,1,0),
(2,61346,1,0),
(2,61384,1,0),
(2,61447,1,0),
(2,62078,1,0),
(2,63411,1,0),
(2,63503,1,0),
(2,64801,1,0),
(2,65139,1,0),
(2,75134,1,0),
(4,69904,1,0),
(5,5,1,0),
(5,265,1,0),
(5,1908,1,0),
(5,6560,1,0),
(5,7482,1,0),
(5,8295,1,0),
(5,10060,1,0),
(5,10073,1,0),
(5,11821,1,0),
(5,14751,1,0),
(5,14767,1,0),
(5,14769,1,0),
(5,14771,1,0),
(5,14772,1,0),
(5,14774,1,0),
(5,14777,1,0),
(5,14781,1,0),
(5,14785,1,0),
(5,14788,1,0),
(5,18209,1,0),
(5,18210,1,0),
(5,18389,1,0),
(5,18555,1,0),
(5,19901,1,0),
(5,23789,1,0),
(5,25565,1,0),
(5,26368,1,0),
(5,27254,1,0),
(5,27255,1,0),
(5,27258,1,0),
(5,27261,1,0),
(5,33153,1,0),
(5,33172,1,0),
(5,33190,1,0),
(5,33202,1,0),
(5,33206,1,0),
(5,34910,1,0),
(5,35182,1,0),
(5,35886,1,0),
(5,35912,1,0),
(5,36356,1,0),
(5,38505,1,0),
(5,38734,1,0),
(5,39258,1,0),
(5,45244,1,0),
(5,45645,1,0),
(5,45646,1,0),
(5,45647,1,0),
(5,45648,1,0),
(5,45649,1,0),
(5,45650,1,0),
(5,45659,1,0),
(5,45813,1,0),
(5,47508,1,0),
(5,47515,1,0),
(5,47517,1,0),
(5,47537,1,0),
(5,47540,1,0),
(5,47757,1,0),
(5,49306,1,0),
(5,52800,1,0),
(5,52803,1,0),
(5,57472,1,0),
(5,63506,1,0),
(5,63574,1,0),
(6,498,1,0),
(6,642,1,0),
(6,1038,1,0),
(6,1044,1,0),
(6,1152,1,0),
(6,3127,1,0),
(6,3273,1,0),
(6,4987,1,0),
(6,5502,1,0),
(6,6940,1,0),
(6,10278,1,0),
(6,10308,1,0),
(6,10326,1,0),
(6,13819,1,0),
(6,19746,1,0),
(6,19752,1,0),
(6,20164,1,0),
(6,20165,1,0),
(6,20166,1,0),
(6,20217,1,0),
(6,20271,1,0),
(6,25780,1,0),
(6,25898,1,0),
(6,31789,1,0),
(6,31801,1,0),
(6,31884,1,0),
(6,32223,1,0),
(6,33388,1,0),
(6,48782,1,0),
(6,48785,1,0),
(6,48788,1,0),
(6,48801,1,0),
(6,48806,1,0),
(6,48817,1,0),
(6,48819,1,0),
(6,48932,1,0),
(6,48934,1,0),
(6,48936,1,0),
(6,48938,1,0),
(6,48942,1,0),
(6,48943,1,0),
(6,48945,1,0),
(6,48947,1,0),
(6,53407,1,0),
(6,53408,1,0),
(6,53601,1,0),
(6,54043,1,0),
(6,54428,1,0),
(6,61411,1,0),
(6,62124,1,0),
(8,5,1,0),
(8,265,1,0),
(8,668,1,0),
(8,670,1,0),
(8,671,1,0),
(8,672,1,0),
(8,813,1,0),
(8,815,1,0),
(8,817,1,0),
(8,1908,1,0),
(8,2153,1,0),
(8,2158,1,0),
(8,2159,1,0),
(8,2160,1,0),
(8,2161,1,0),
(8,2162,1,0),
(8,2163,1,0),
(8,2164,1,0),
(8,2165,1,0),
(8,2166,1,0),
(8,2167,1,0),
(8,2168,1,0),
(8,2169,1,0),
(8,2331,1,0),
(8,2332,1,0),
(8,2333,1,0),
(8,2334,1,0),
(8,2335,1,0),
(8,2336,1,0),
(8,2337,1,0),
(8,2385,1,0),
(8,2386,1,0),
(8,2389,1,0),
(8,2392,1,0),
(8,2393,1,0),
(8,2394,1,0),
(8,2395,1,0),
(8,2396,1,0),
(8,2397,1,0),
(8,2399,1,0),
(8,2401,1,0),
(8,2402,1,0),
(8,2403,1,0),
(8,2406,1,0),
(8,2539,1,0),
(8,2541,1,0),
(8,2542,1,0),
(8,2543,1,0),
(8,2544,1,0),
(8,2545,1,0),
(8,2546,1,0),
(8,2547,1,0),
(8,2548,1,0),
(8,2549,1,0),
(8,2661,1,0),
(8,2662,1,0),
(8,2664,1,0),
(8,2665,1,0),
(8,2666,1,0),
(8,2667,1,0),
(8,2668,1,0),
(8,2670,1,0),
(8,2671,1,0),
(8,2672,1,0),
(8,2673,1,0),
(8,2674,1,0),
(8,2675,1,0),
(8,2737,1,0),
(8,2738,1,0),
(8,2739,1,0),
(8,2740,1,0),
(8,2741,1,0),
(8,2742,1,0),
(8,2795,1,0),
(8,2964,1,0),
(8,3116,1,0),
(8,3117,1,0),
(8,3170,1,0),
(8,3171,1,0),
(8,3172,1,0),
(8,3173,1,0),
(8,3174,1,0),
(8,3175,1,0),
(8,3176,1,0),
(8,3177,1,0),
(8,3188,1,0),
(8,3230,1,0),
(8,3276,1,0),
(8,3277,1,0),
(8,3278,1,0),
(8,3292,1,0),
(8,3293,1,0),
(8,3294,1,0),
(8,3295,1,0),
(8,3296,1,0),
(8,3297,1,0),
(8,3319,1,0),
(8,3320,1,0),
(8,3321,1,0),
(8,3323,1,0),
(8,3324,1,0),
(8,3325,1,0),
(8,3326,1,0),
(8,3328,1,0),
(8,3330,1,0),
(8,3331,1,0),
(8,3333,1,0),
(8,3334,1,0),
(8,3336,1,0),
(8,3337,1,0),
(8,3370,1,0),
(8,3371,1,0),
(8,3372,1,0),
(8,3373,1,0),
(8,3376,1,0),
(8,3377,1,0),
(8,3397,1,0),
(8,3398,1,0),
(8,3399,1,0),
(8,3400,1,0),
(8,3447,1,0),
(8,3448,1,0),
(8,3449,1,0),
(8,3450,1,0),
(8,3451,1,0),
(8,3452,1,0),
(8,3453,1,0),
(8,3454,1,0),
(8,3491,1,0),
(8,3492,1,0),
(8,3493,1,0),
(8,3494,1,0),
(8,3495,1,0),
(8,3496,1,0),
(8,3497,1,0),
(8,3498,1,0),
(8,3500,1,0),
(8,3501,1,0),
(8,3502,1,0),
(8,3503,1,0),
(8,3504,1,0),
(8,3505,1,0),
(8,3506,1,0),
(8,3507,1,0),
(8,3508,1,0),
(8,3511,1,0),
(8,3513,1,0),
(8,3515,1,0),
(8,3753,1,0),
(8,3755,1,0),
(8,3756,1,0),
(8,3757,1,0),
(8,3758,1,0),
(8,3759,1,0),
(8,3760,1,0),
(8,3761,1,0),
(8,3762,1,0),
(8,3763,1,0),
(8,3764,1,0),
(8,3765,1,0),
(8,3766,1,0),
(8,3767,1,0),
(8,3768,1,0),
(8,3769,1,0),
(8,3770,1,0),
(8,3771,1,0),
(8,3772,1,0),
(8,3773,1,0),
(8,3774,1,0),
(8,3775,1,0),
(8,3776,1,0),
(8,3777,1,0),
(8,3778,1,0),
(8,3779,1,0),
(8,3780,1,0),
(8,3813,1,0),
(8,3816,1,0),
(8,3817,1,0),
(8,3818,1,0),
(8,3839,1,0),
(8,3840,1,0),
(8,3841,1,0),
(8,3842,1,0),
(8,3843,1,0),
(8,3844,1,0),
(8,3845,1,0),
(8,3847,1,0),
(8,3848,1,0),
(8,3849,1,0),
(8,3850,1,0),
(8,3851,1,0),
(8,3852,1,0),
(8,3854,1,0),
(8,3855,1,0),
(8,3856,1,0),
(8,3857,1,0),
(8,3858,1,0),
(8,3859,1,0),
(8,3860,1,0),
(8,3861,1,0),
(8,3862,1,0),
(8,3863,1,0),
(8,3864,1,0),
(8,3865,1,0),
(8,3866,1,0),
(8,3868,1,0),
(8,3869,1,0),
(8,3870,1,0),
(8,3871,1,0),
(8,3872,1,0),
(8,3873,1,0),
(8,3914,1,0),
(8,3922,1,0),
(8,3923,1,0),
(8,3924,1,0),
(8,3925,1,0),
(8,3926,1,0),
(8,3928,1,0),
(8,3929,1,0),
(8,3930,1,0),
(8,3931,1,0),
(8,3932,1,0),
(8,3933,1,0),
(8,3934,1,0),
(8,3936,1,0),
(8,3937,1,0),
(8,3938,1,0),
(8,3939,1,0),
(8,3940,1,0),
(8,3941,1,0),
(8,3942,1,0),
(8,3944,1,0),
(8,3945,1,0),
(8,3946,1,0),
(8,3947,1,0),
(8,3949,1,0),
(8,3950,1,0),
(8,3952,1,0),
(8,3953,1,0),
(8,3954,1,0),
(8,3955,1,0),
(8,3956,1,0),
(8,3957,1,0),
(8,3958,1,0),
(8,3959,1,0),
(8,3960,1,0),
(8,3961,1,0),
(8,3962,1,0),
(8,3963,1,0),
(8,3965,1,0),
(8,3966,1,0),
(8,3967,1,0),
(8,3968,1,0),
(8,3969,1,0),
(8,3971,1,0),
(8,3972,1,0),
(8,3973,1,0),
(8,3977,1,0),
(8,3978,1,0),
(8,3979,1,0),
(8,4094,1,0),
(8,4096,1,0),
(8,4097,1,0),
(8,4508,1,0),
(8,4942,1,0),
(8,5244,1,0),
(8,6412,1,0),
(8,6413,1,0),
(8,6414,1,0),
(8,6415,1,0),
(8,6416,1,0),
(8,6417,1,0),
(8,6418,1,0),
(8,6419,1,0),
(8,6458,1,0),
(8,6499,1,0),
(8,6500,1,0),
(8,6501,1,0),
(8,6517,1,0),
(8,6518,1,0),
(8,6521,1,0),
(8,6560,1,0),
(8,6617,1,0),
(8,6618,1,0),
(8,6624,1,0),
(8,6661,1,0),
(8,6686,1,0),
(8,6688,1,0),
(8,6690,1,0),
(8,6692,1,0),
(8,6693,1,0),
(8,6695,1,0),
(8,6702,1,0),
(8,6703,1,0),
(8,6704,1,0),
(8,6705,1,0),
(8,7133,1,0),
(8,7135,1,0),
(8,7147,1,0),
(8,7149,1,0),
(8,7151,1,0),
(8,7153,1,0),
(8,7156,1,0),
(8,7179,1,0),
(8,7181,1,0),
(8,7213,1,0),
(8,7221,1,0),
(8,7222,1,0),
(8,7223,1,0),
(8,7224,1,0),
(8,7255,1,0),
(8,7256,1,0),
(8,7257,1,0),
(8,7258,1,0),
(8,7259,1,0),
(8,7340,1,0),
(8,7341,1,0),
(8,7408,1,0),
(8,7420,1,0),
(8,7426,1,0),
(8,7430,1,0),
(8,7443,1,0),
(8,7454,1,0),
(8,7457,1,0),
(8,7482,1,0),
(8,7623,1,0),
(8,7624,1,0),
(8,7629,1,0),
(8,7630,1,0),
(8,7633,1,0),
(8,7636,1,0),
(8,7639,1,0),
(8,7643,1,0),
(8,7745,1,0),
(8,7748,1,0),
(8,7751,1,0),
(8,7752,1,0),
(8,7753,1,0),
(8,7754,1,0),
(8,7755,1,0),
(8,7766,1,0),
(8,7771,1,0),
(8,7776,1,0),
(8,7779,1,0),
(8,7782,1,0),
(8,7786,1,0),
(8,7788,1,0),
(8,7793,1,0),
(8,7795,1,0),
(8,7817,1,0),
(8,7818,1,0),
(8,7827,1,0),
(8,7828,1,0),
(8,7836,1,0),
(8,7837,1,0),
(8,7841,1,0),
(8,7845,1,0),
(8,7857,1,0),
(8,7859,1,0),
(8,7861,1,0),
(8,7863,1,0),
(8,7867,1,0),
(8,7892,1,0),
(8,7893,1,0),
(8,7928,1,0),
(8,7929,1,0),
(8,7934,1,0),
(8,7935,1,0),
(8,7953,1,0),
(8,7954,1,0),
(8,7955,1,0),
(8,8238,1,0),
(8,8240,1,0),
(8,8243,1,0),
(8,8295,1,0),
(8,8322,1,0),
(8,8334,1,0),
(8,8339,1,0),
(8,8366,1,0),
(8,8367,1,0),
(8,8368,1,0),
(8,8465,1,0),
(8,8467,1,0),
(8,8483,1,0),
(8,8489,1,0),
(8,8607,1,0),
(8,8758,1,0),
(8,8760,1,0),
(8,8762,1,0),
(8,8764,1,0),
(8,8766,1,0),
(8,8768,1,0),
(8,8770,1,0),
(8,8772,1,0),
(8,8774,1,0),
(8,8776,1,0),
(8,8778,1,0),
(8,8780,1,0),
(8,8782,1,0),
(8,8784,1,0),
(8,8786,1,0),
(8,8789,1,0),
(8,8791,1,0),
(8,8793,1,0),
(8,8795,1,0),
(8,8797,1,0),
(8,8799,1,0),
(8,8802,1,0),
(8,8804,1,0),
(8,8880,1,0),
(8,8895,1,0),
(8,9060,1,0),
(8,9062,1,0),
(8,9064,1,0),
(8,9065,1,0),
(8,9068,1,0),
(8,9070,1,0),
(8,9072,1,0),
(8,9074,1,0),
(8,9145,1,0),
(8,9146,1,0),
(8,9147,1,0),
(8,9148,1,0),
(8,9149,1,0),
(8,9193,1,0),
(8,9194,1,0),
(8,9195,1,0),
(8,9196,1,0),
(8,9197,1,0),
(8,9198,1,0),
(8,9201,1,0),
(8,9202,1,0),
(8,9206,1,0),
(8,9207,1,0),
(8,9208,1,0),
(8,9269,1,0),
(8,9271,1,0),
(8,9273,1,0),
(8,9513,1,0),
(8,9787,1,0),
(8,9788,1,0),
(8,9811,1,0),
(8,9813,1,0),
(8,9814,1,0),
(8,9818,1,0),
(8,9820,1,0),
(8,9916,1,0),
(8,9918,1,0),
(8,9920,1,0),
(8,9921,1,0),
(8,9926,1,0),
(8,9928,1,0),
(8,9931,1,0),
(8,9933,1,0),
(8,9935,1,0),
(8,9937,1,0),
(8,9939,1,0),
(8,9942,1,0),
(8,9945,1,0),
(8,9950,1,0),
(8,9952,1,0),
(8,9954,1,0),
(8,9957,1,0),
(8,9959,1,0),
(8,9961,1,0),
(8,9964,1,0),
(8,9966,1,0),
(8,9968,1,0),
(8,9970,1,0),
(8,9972,1,0),
(8,9974,1,0),
(8,9979,1,0),
(8,9980,1,0),
(8,9983,1,0),
(8,9985,1,0),
(8,9986,1,0),
(8,9987,1,0),
(8,9993,1,0),
(8,9995,1,0),
(8,9997,1,0),
(8,10001,1,0),
(8,10003,1,0),
(8,10005,1,0),
(8,10007,1,0),
(8,10009,1,0),
(8,10011,1,0),
(8,10013,1,0),
(8,10015,1,0),
(8,10073,1,0),
(8,10482,1,0),
(8,10487,1,0),
(8,10490,1,0),
(8,10499,1,0),
(8,10507,1,0),
(8,10509,1,0),
(8,10511,1,0),
(8,10516,1,0),
(8,10518,1,0),
(8,10520,1,0),
(8,10525,1,0),
(8,10529,1,0),
(8,10531,1,0),
(8,10533,1,0),
(8,10542,1,0),
(8,10544,1,0),
(8,10546,1,0),
(8,10548,1,0),
(8,10550,1,0),
(8,10552,1,0),
(8,10554,1,0),
(8,10556,1,0),
(8,10558,1,0),
(8,10560,1,0),
(8,10562,1,0),
(8,10564,1,0),
(8,10566,1,0),
(8,10568,1,0),
(8,10570,1,0),
(8,10572,1,0),
(8,10574,1,0),
(8,10619,1,0),
(8,10621,1,0),
(8,10630,1,0),
(8,10632,1,0),
(8,10647,1,0),
(8,10650,1,0),
(8,10656,1,0),
(8,10658,1,0),
(8,10660,1,0),
(8,10840,1,0),
(8,10841,1,0),
(8,11448,1,0),
(8,11449,1,0),
(8,11450,1,0),
(8,11451,1,0),
(8,11452,1,0),
(8,11453,1,0),
(8,11454,1,0),
(8,11456,1,0),
(8,11457,1,0),
(8,11458,1,0),
(8,11459,1,0),
(8,11460,1,0),
(8,11461,1,0),
(8,11464,1,0),
(8,11465,1,0),
(8,11466,1,0),
(8,11467,1,0),
(8,11468,1,0),
(8,11472,1,0),
(8,11473,1,0),
(8,11476,1,0),
(8,11477,1,0),
(8,11478,1,0),
(8,11479,1,0),
(8,11480,1,0),
(8,11643,1,0),
(8,11821,1,0),
(8,12045,1,0),
(8,12046,1,0),
(8,12047,1,0),
(8,12048,1,0),
(8,12049,1,0),
(8,12050,1,0),
(8,12052,1,0),
(8,12053,1,0),
(8,12055,1,0),
(8,12056,1,0),
(8,12059,1,0),
(8,12060,1,0),
(8,12061,1,0),
(8,12062,1,0),
(8,12063,1,0),
(8,12064,1,0),
(8,12065,1,0),
(8,12066,1,0),
(8,12067,1,0),
(8,12068,1,0),
(8,12069,1,0),
(8,12070,1,0),
(8,12071,1,0),
(8,12072,1,0),
(8,12073,1,0),
(8,12074,1,0),
(8,12075,1,0),
(8,12076,1,0),
(8,12077,1,0),
(8,12078,1,0),
(8,12079,1,0),
(8,12080,1,0),
(8,12081,1,0),
(8,12082,1,0),
(8,12083,1,0),
(8,12084,1,0),
(8,12085,1,0),
(8,12086,1,0),
(8,12087,1,0),
(8,12088,1,0),
(8,12089,1,0),
(8,12090,1,0),
(8,12091,1,0),
(8,12092,1,0),
(8,12093,1,0),
(8,12259,1,0),
(8,12584,1,0),
(8,12585,1,0),
(8,12586,1,0),
(8,12587,1,0),
(8,12589,1,0),
(8,12590,1,0),
(8,12591,1,0),
(8,12594,1,0),
(8,12595,1,0),
(8,12596,1,0),
(8,12597,1,0),
(8,12599,1,0),
(8,12603,1,0),
(8,12607,1,0),
(8,12609,1,0),
(8,12614,1,0),
(8,12615,1,0),
(8,12616,1,0),
(8,12617,1,0),
(8,12618,1,0),
(8,12619,1,0),
(8,12620,1,0),
(8,12621,1,0),
(8,12622,1,0),
(8,12624,1,0),
(8,12715,1,0),
(8,12716,1,0),
(8,12717,1,0),
(8,12718,1,0),
(8,12720,1,0),
(8,12722,1,0),
(8,12754,1,0),
(8,12755,1,0),
(8,12758,1,0),
(8,12759,1,0),
(8,12760,1,0),
(8,12895,1,0),
(8,12897,1,0),
(8,12899,1,0),
(8,12900,1,0),
(8,12902,1,0),
(8,12903,1,0),
(8,12904,1,0),
(8,12905,1,0),
(8,12906,1,0),
(8,12907,1,0),
(8,12908,1,0),
(8,13028,1,0),
(8,13240,1,0),
(8,13378,1,0),
(8,13380,1,0),
(8,13419,1,0),
(8,13421,1,0),
(8,13464,1,0),
(8,13485,1,0),
(8,13501,1,0),
(8,13503,1,0),
(8,13522,1,0),
(8,13529,1,0),
(8,13536,1,0),
(8,13538,1,0),
(8,13607,1,0),
(8,13612,1,0),
(8,13617,1,0),
(8,13620,1,0),
(8,13622,1,0),
(8,13626,1,0),
(8,13628,1,0),
(8,13631,1,0),
(8,13635,1,0),
(8,13637,1,0),
(8,13640,1,0),
(8,13642,1,0),
(8,13644,1,0),
(8,13646,1,0),
(8,13648,1,0),
(8,13653,1,0),
(8,13655,1,0),
(8,13657,1,0),
(8,13659,1,0),
(8,13661,1,0),
(8,13663,1,0),
(8,13687,1,0),
(8,13689,1,0),
(8,13693,1,0),
(8,13695,1,0),
(8,13698,1,0),
(8,13700,1,0),
(8,13702,1,0),
(8,13746,1,0),
(8,13794,1,0),
(8,13815,1,0),
(8,13817,1,0),
(8,13822,1,0),
(8,13836,1,0),
(8,13841,1,0),
(8,13846,1,0),
(8,13858,1,0),
(8,13868,1,0),
(8,13882,1,0),
(8,13887,1,0),
(8,13890,1,0),
(8,13898,1,0),
(8,13905,1,0),
(8,13915,1,0),
(8,13917,1,0),
(8,13931,1,0),
(8,13933,1,0),
(8,13935,1,0),
(8,13937,1,0),
(8,13939,1,0),
(8,13941,1,0),
(8,13943,1,0),
(8,13945,1,0),
(8,13947,1,0),
(8,13948,1,0),
(8,14293,1,0),
(8,14379,1,0),
(8,14380,1,0),
(8,14807,1,0),
(8,14809,1,0),
(8,14810,1,0),
(8,14930,1,0),
(8,14932,1,0),
(8,15255,1,0),
(8,15292,1,0),
(8,15293,1,0),
(8,15294,1,0),
(8,15295,1,0),
(8,15296,1,0),
(8,15596,1,0),
(8,15628,1,0),
(8,15633,1,0),
(8,15833,1,0),
(8,15853,1,0),
(8,15855,1,0),
(8,15856,1,0),
(8,15861,1,0),
(8,15863,1,0),
(8,15865,1,0),
(8,15906,1,0),
(8,15910,1,0),
(8,15915,1,0),
(8,15933,1,0),
(8,15935,1,0),
(8,15972,1,0),
(8,15973,1,0),
(8,16639,1,0),
(8,16640,1,0),
(8,16641,1,0),
(8,16642,1,0),
(8,16643,1,0),
(8,16644,1,0),
(8,16645,1,0),
(8,16646,1,0),
(8,16647,1,0),
(8,16648,1,0),
(8,16649,1,0),
(8,16650,1,0),
(8,16651,1,0),
(8,16652,1,0),
(8,16653,1,0),
(8,16654,1,0),
(8,16655,1,0),
(8,16656,1,0),
(8,16657,1,0),
(8,16658,1,0),
(8,16659,1,0),
(8,16660,1,0),
(8,16661,1,0),
(8,16662,1,0),
(8,16663,1,0),
(8,16664,1,0),
(8,16665,1,0),
(8,16667,1,0),
(8,16724,1,0),
(8,16725,1,0),
(8,16726,1,0),
(8,16728,1,0),
(8,16729,1,0),
(8,16730,1,0),
(8,16731,1,0),
(8,16732,1,0),
(8,16741,1,0),
(8,16742,1,0),
(8,16744,1,0),
(8,16745,1,0),
(8,16746,1,0),
(8,16960,1,0),
(8,16965,1,0),
(8,16967,1,0),
(8,16969,1,0),
(8,16970,1,0),
(8,16971,1,0),
(8,16973,1,0),
(8,16978,1,0),
(8,16980,1,0),
(8,16983,1,0),
(8,16984,1,0),
(8,16985,1,0),
(8,16986,1,0),
(8,16987,1,0),
(8,16988,1,0),
(8,16990,1,0),
(8,16991,1,0),
(8,16992,1,0),
(8,16993,1,0),
(8,16994,1,0),
(8,16995,1,0),
(8,17039,1,0),
(8,17040,1,0),
(8,17041,1,0),
(8,17180,1,0),
(8,17181,1,0),
(8,17187,1,0),
(8,17551,1,0),
(8,17552,1,0),
(8,17553,1,0),
(8,17554,1,0),
(8,17555,1,0),
(8,17556,1,0),
(8,17557,1,0),
(8,17559,1,0),
(8,17560,1,0),
(8,17561,1,0),
(8,17562,1,0),
(8,17563,1,0),
(8,17564,1,0),
(8,17565,1,0),
(8,17566,1,0),
(8,17570,1,0),
(8,17571,1,0),
(8,17572,1,0),
(8,17573,1,0),
(8,17574,1,0),
(8,17575,1,0),
(8,17576,1,0),
(8,17577,1,0),
(8,17578,1,0),
(8,17579,1,0),
(8,17580,1,0),
(8,17632,1,0),
(8,17634,1,0),
(8,17635,1,0),
(8,17636,1,0),
(8,17637,1,0),
(8,17638,1,0),
(8,17737,1,0),
(8,18209,1,0),
(8,18210,1,0),
(8,18238,1,0),
(8,18239,1,0),
(8,18240,1,0),
(8,18241,1,0),
(8,18242,1,0),
(8,18243,1,0),
(8,18244,1,0),
(8,18245,1,0),
(8,18246,1,0),
(8,18247,1,0),
(8,18389,1,0),
(8,18401,1,0),
(8,18402,1,0),
(8,18403,1,0),
(8,18404,1,0),
(8,18405,1,0),
(8,18406,1,0),
(8,18407,1,0),
(8,18408,1,0),
(8,18409,1,0),
(8,18410,1,0),
(8,18411,1,0),
(8,18412,1,0),
(8,18413,1,0),
(8,18414,1,0),
(8,18415,1,0),
(8,18416,1,0),
(8,18417,1,0),
(8,18418,1,0),
(8,18419,1,0),
(8,18420,1,0),
(8,18421,1,0),
(8,18422,1,0),
(8,18423,1,0),
(8,18424,1,0),
(8,18434,1,0),
(8,18436,1,0),
(8,18437,1,0),
(8,18438,1,0),
(8,18439,1,0),
(8,18440,1,0),
(8,18441,1,0),
(8,18442,1,0),
(8,18444,1,0),
(8,18445,1,0),
(8,18446,1,0),
(8,18447,1,0),
(8,18448,1,0),
(8,18449,1,0),
(8,18450,1,0),
(8,18451,1,0),
(8,18452,1,0),
(8,18453,1,0),
(8,18454,1,0),
(8,18455,1,0),
(8,18456,1,0),
(8,18457,1,0),
(8,18458,1,0),
(8,18560,1,0),
(8,18629,1,0),
(8,18630,1,0),
(8,19047,1,0),
(8,19048,1,0),
(8,19049,1,0),
(8,19050,1,0),
(8,19051,1,0),
(8,19052,1,0),
(8,19053,1,0),
(8,19054,1,0),
(8,19055,1,0),
(8,19058,1,0),
(8,19059,1,0),
(8,19060,1,0),
(8,19061,1,0),
(8,19062,1,0),
(8,19063,1,0),
(8,19064,1,0),
(8,19065,1,0),
(8,19066,1,0),
(8,19067,1,0),
(8,19068,1,0),
(8,19070,1,0),
(8,19071,1,0),
(8,19072,1,0),
(8,19073,1,0),
(8,19074,1,0),
(8,19075,1,0),
(8,19076,1,0),
(8,19077,1,0),
(8,19078,1,0),
(8,19079,1,0),
(8,19080,1,0),
(8,19081,1,0),
(8,19082,1,0),
(8,19083,1,0),
(8,19084,1,0),
(8,19085,1,0),
(8,19086,1,0),
(8,19087,1,0),
(8,19088,1,0),
(8,19089,1,0),
(8,19090,1,0),
(8,19091,1,0),
(8,19092,1,0),
(8,19093,1,0),
(8,19094,1,0),
(8,19095,1,0),
(8,19097,1,0),
(8,19098,1,0),
(8,19100,1,0),
(8,19101,1,0),
(8,19102,1,0),
(8,19103,1,0),
(8,19104,1,0),
(8,19106,1,0),
(8,19107,1,0),
(8,19435,1,0),
(8,19567,1,0),
(8,19666,1,0),
(8,19667,1,0),
(8,19668,1,0),
(8,19669,1,0),
(8,19788,1,0),
(8,19790,1,0),
(8,19791,1,0),
(8,19792,1,0),
(8,19793,1,0),
(8,19794,1,0),
(8,19795,1,0),
(8,19796,1,0),
(8,19799,1,0),
(8,19800,1,0),
(8,19814,1,0),
(8,19815,1,0),
(8,19819,1,0),
(8,19825,1,0),
(8,19830,1,0),
(8,19831,1,0),
(8,19833,1,0),
(8,19901,1,0),
(8,20008,1,0),
(8,20009,1,0),
(8,20010,1,0),
(8,20011,1,0),
(8,20012,1,0),
(8,20013,1,0),
(8,20014,1,0),
(8,20015,1,0),
(8,20016,1,0),
(8,20017,1,0),
(8,20020,1,0),
(8,20023,1,0),
(8,20024,1,0),
(8,20025,1,0),
(8,20026,1,0),
(8,20028,1,0),
(8,20029,1,0),
(8,20030,1,0),
(8,20031,1,0),
(8,20032,1,0),
(8,20033,1,0),
(8,20034,1,0),
(8,20035,1,0),
(8,20036,1,0),
(8,20051,1,0),
(8,20201,1,0),
(8,20219,1,0),
(8,20222,1,0),
(8,20626,1,0),
(8,20648,1,0),
(8,20649,1,0),
(8,20650,1,0),
(8,20848,1,0),
(8,20849,1,0),
(8,20853,1,0),
(8,20854,1,0),
(8,20855,1,0),
(8,20872,1,0),
(8,20873,1,0),
(8,20874,1,0),
(8,20876,1,0),
(8,20890,1,0),
(8,20897,1,0),
(8,20916,1,0),
(8,21143,1,0),
(8,21144,1,0),
(8,21161,1,0),
(8,21175,1,0),
(8,21913,1,0),
(8,21923,1,0),
(8,21931,1,0),
(8,21940,1,0),
(8,21943,1,0),
(8,21945,1,0),
(8,22331,1,0),
(8,22480,1,0),
(8,22704,1,0),
(8,22711,1,0),
(8,22727,1,0),
(8,22732,1,0),
(8,22749,1,0),
(8,22750,1,0),
(8,22757,1,0),
(8,22759,1,0),
(8,22761,1,0),
(8,22793,1,0),
(8,22795,1,0),
(8,22797,1,0),
(8,22808,1,0),
(8,22813,1,0),
(8,22815,1,0),
(8,22866,1,0),
(8,22867,1,0),
(8,22868,1,0),
(8,22869,1,0),
(8,22870,1,0),
(8,22902,1,0),
(8,22921,1,0),
(8,22922,1,0),
(8,22923,1,0),
(8,22926,1,0),
(8,22927,1,0),
(8,22928,1,0),
(8,23066,1,0),
(8,23067,1,0),
(8,23068,1,0),
(8,23069,1,0),
(8,23070,1,0),
(8,23071,1,0),
(8,23077,1,0),
(8,23078,1,0),
(8,23079,1,0),
(8,23080,1,0),
(8,23081,1,0),
(8,23082,1,0),
(8,23096,1,0),
(8,23129,1,0),
(8,23190,1,0),
(8,23399,1,0),
(8,23486,1,0),
(8,23489,1,0),
(8,23507,1,0),
(8,23628,1,0),
(8,23629,1,0),
(8,23632,1,0),
(8,23633,1,0),
(8,23636,1,0),
(8,23637,1,0),
(8,23638,1,0),
(8,23639,1,0),
(8,23650,1,0),
(8,23652,1,0),
(8,23653,1,0),
(8,23662,1,0),
(8,23663,1,0),
(8,23664,1,0),
(8,23665,1,0),
(8,23666,1,0),
(8,23667,1,0),
(8,23703,1,0),
(8,23704,1,0),
(8,23705,1,0),
(8,23706,1,0),
(8,23707,1,0),
(8,23708,1,0),
(8,23709,1,0),
(8,23710,1,0),
(8,23787,1,0),
(8,23789,1,0),
(8,23799,1,0),
(8,23800,1,0),
(8,23801,1,0),
(8,23802,1,0),
(8,23803,1,0),
(8,23804,1,0),
(8,24091,1,0),
(8,24092,1,0),
(8,24093,1,0),
(8,24121,1,0),
(8,24122,1,0),
(8,24123,1,0),
(8,24124,1,0),
(8,24125,1,0),
(8,24136,1,0),
(8,24137,1,0),
(8,24138,1,0),
(8,24139,1,0),
(8,24140,1,0),
(8,24141,1,0),
(8,24266,1,0),
(8,24356,1,0),
(8,24357,1,0),
(8,24365,1,0),
(8,24366,1,0),
(8,24367,1,0),
(8,24368,1,0),
(8,24399,1,0),
(8,24418,1,0),
(8,24654,1,0),
(8,24655,1,0),
(8,24703,1,0),
(8,24801,1,0),
(8,24846,1,0),
(8,24847,1,0),
(8,24848,1,0),
(8,24849,1,0),
(8,24850,1,0),
(8,24851,1,0),
(8,24901,1,0),
(8,24902,1,0),
(8,24903,1,0),
(8,24912,1,0),
(8,24913,1,0),
(8,24914,1,0),
(8,24940,1,0),
(8,25072,1,0),
(8,25073,1,0),
(8,25074,1,0),
(8,25078,1,0),
(8,25079,1,0),
(8,25080,1,0),
(8,25081,1,0),
(8,25082,1,0),
(8,25083,1,0),
(8,25084,1,0),
(8,25086,1,0),
(8,25124,1,0),
(8,25125,1,0),
(8,25126,1,0),
(8,25127,1,0),
(8,25128,1,0),
(8,25129,1,0),
(8,25130,1,0),
(8,25146,1,0),
(8,25278,1,0),
(8,25280,1,0),
(8,25283,1,0),
(8,25284,1,0),
(8,25287,1,0),
(8,25305,1,0),
(8,25317,1,0),
(8,25318,1,0),
(8,25320,1,0),
(8,25321,1,0),
(8,25323,1,0),
(8,25339,1,0),
(8,25490,1,0),
(8,25498,1,0),
(8,25565,1,0),
(8,25610,1,0),
(8,25612,1,0),
(8,25613,1,0),
(8,25614,1,0),
(8,25615,1,0),
(8,25617,1,0),
(8,25618,1,0),
(8,25619,1,0),
(8,25620,1,0),
(8,25621,1,0),
(8,25622,1,0),
(8,25659,1,0),
(8,25704,1,0),
(8,25954,1,0),
(8,26011,1,0),
(8,26085,1,0),
(8,26086,1,0),
(8,26087,1,0),
(8,26277,1,0),
(8,26279,1,0),
(8,26368,1,0),
(8,26403,1,0),
(8,26407,1,0),
(8,26416,1,0),
(8,26417,1,0),
(8,26418,1,0),
(8,26420,1,0),
(8,26421,1,0),
(8,26422,1,0),
(8,26423,1,0),
(8,26424,1,0),
(8,26425,1,0),
(8,26426,1,0),
(8,26427,1,0),
(8,26428,1,0),
(8,26442,1,0),
(8,26443,1,0),
(8,26745,1,0),
(8,26746,1,0),
(8,26747,1,0),
(8,26749,1,0),
(8,26750,1,0),
(8,26751,1,0),
(8,26752,1,0),
(8,26753,1,0),
(8,26754,1,0),
(8,26755,1,0),
(8,26756,1,0),
(8,26757,1,0),
(8,26758,1,0),
(8,26759,1,0),
(8,26760,1,0),
(8,26761,1,0),
(8,26762,1,0),
(8,26763,1,0),
(8,26764,1,0),
(8,26765,1,0),
(8,26770,1,0),
(8,26771,1,0),
(8,26772,1,0),
(8,26773,1,0),
(8,26774,1,0),
(8,26775,1,0),
(8,26776,1,0),
(8,26777,1,0),
(8,26778,1,0),
(8,26779,1,0),
(8,26780,1,0),
(8,26781,1,0),
(8,26782,1,0),
(8,26783,1,0),
(8,26784,1,0),
(8,26797,1,0),
(8,26798,1,0),
(8,26801,1,0),
(8,26872,1,0),
(8,26873,1,0),
(8,26874,1,0),
(8,26875,1,0),
(8,26876,1,0),
(8,26878,1,0),
(8,26880,1,0),
(8,26881,1,0),
(8,26882,1,0),
(8,26883,1,0),
(8,26885,1,0),
(8,26887,1,0),
(8,26896,1,0),
(8,26897,1,0),
(8,26900,1,0),
(8,26902,1,0),
(8,26903,1,0),
(8,26906,1,0),
(8,26907,1,0),
(8,26908,1,0),
(8,26909,1,0),
(8,26910,1,0),
(8,26911,1,0),
(8,26912,1,0),
(8,26914,1,0),
(8,26915,1,0),
(8,26916,1,0),
(8,26918,1,0),
(8,26920,1,0),
(8,26926,1,0),
(8,26927,1,0),
(8,26928,1,0),
(8,27032,1,0),
(8,27033,1,0),
(8,27254,1,0),
(8,27255,1,0),
(8,27258,1,0),
(8,27261,1,0),
(8,27585,1,0),
(8,27586,1,0),
(8,27587,1,0),
(8,27588,1,0),
(8,27589,1,0),
(8,27590,1,0),
(8,27658,1,0),
(8,27659,1,0),
(8,27660,1,0),
(8,27724,1,0),
(8,27725,1,0),
(8,27829,1,0),
(8,27830,1,0),
(8,27832,1,0),
(8,27837,1,0),
(8,27899,1,0),
(8,27905,1,0),
(8,27906,1,0),
(8,27911,1,0),
(8,27913,1,0),
(8,27914,1,0),
(8,27917,1,0),
(8,27920,1,0),
(8,27924,1,0),
(8,27926,1,0),
(8,27927,1,0),
(8,27944,1,0),
(8,27945,1,0),
(8,27946,1,0),
(8,27947,1,0),
(8,27948,1,0),
(8,27950,1,0),
(8,27951,1,0),
(8,27954,1,0),
(8,27957,1,0),
(8,27958,1,0),
(8,27960,1,0),
(8,27961,1,0),
(8,27962,1,0),
(8,27967,1,0),
(8,27968,1,0),
(8,27971,1,0),
(8,27972,1,0),
(8,27975,1,0),
(8,27977,1,0),
(8,27981,1,0),
(8,27982,1,0),
(8,27984,1,0),
(8,28003,1,0),
(8,28004,1,0),
(8,28016,1,0),
(8,28019,1,0),
(8,28021,1,0),
(8,28022,1,0),
(8,28027,1,0),
(8,28028,1,0),
(8,28205,1,0),
(8,28207,1,0),
(8,28208,1,0),
(8,28209,1,0),
(8,28210,1,0),
(8,28219,1,0),
(8,28220,1,0),
(8,28221,1,0),
(8,28222,1,0),
(8,28223,1,0),
(8,28224,1,0),
(8,28242,1,0),
(8,28243,1,0),
(8,28244,1,0),
(8,28267,1,0),
(8,28327,1,0),
(8,28461,1,0),
(8,28462,1,0),
(8,28463,1,0),
(8,28472,1,0),
(8,28473,1,0),
(8,28474,1,0),
(8,28480,1,0),
(8,28481,1,0),
(8,28482,1,0),
(8,28543,1,0),
(8,28544,1,0),
(8,28545,1,0),
(8,28546,1,0),
(8,28549,1,0),
(8,28550,1,0),
(8,28551,1,0),
(8,28552,1,0),
(8,28553,1,0),
(8,28554,1,0),
(8,28555,1,0),
(8,28556,1,0),
(8,28557,1,0),
(8,28558,1,0),
(8,28562,1,0),
(8,28563,1,0),
(8,28564,1,0),
(8,28565,1,0),
(8,28566,1,0),
(8,28567,1,0),
(8,28568,1,0),
(8,28569,1,0),
(8,28570,1,0),
(8,28571,1,0),
(8,28572,1,0),
(8,28573,1,0),
(8,28575,1,0),
(8,28576,1,0),
(8,28577,1,0),
(8,28578,1,0),
(8,28579,1,0),
(8,28580,1,0),
(8,28581,1,0),
(8,28582,1,0),
(8,28583,1,0),
(8,28584,1,0),
(8,28585,1,0),
(8,28586,1,0),
(8,28587,1,0),
(8,28588,1,0),
(8,28589,1,0),
(8,28590,1,0),
(8,28591,1,0),
(8,28672,1,0),
(8,28675,1,0),
(8,28677,1,0),
(8,28903,1,0),
(8,28905,1,0),
(8,28906,1,0),
(8,28907,1,0),
(8,28910,1,0),
(8,28912,1,0),
(8,28914,1,0),
(8,28915,1,0),
(8,28916,1,0),
(8,28917,1,0),
(8,28918,1,0),
(8,28924,1,0),
(8,28925,1,0),
(8,28927,1,0),
(8,28933,1,0),
(8,28936,1,0),
(8,28938,1,0),
(8,28944,1,0),
(8,28947,1,0),
(8,28948,1,0),
(8,28950,1,0),
(8,28953,1,0),
(8,28955,1,0),
(8,28957,1,0),
(8,29545,1,0),
(8,29547,1,0),
(8,29548,1,0),
(8,29549,1,0),
(8,29550,1,0),
(8,29551,1,0),
(8,29552,1,0),
(8,29553,1,0),
(8,29556,1,0),
(8,29557,1,0),
(8,29558,1,0),
(8,29565,1,0),
(8,29566,1,0),
(8,29568,1,0),
(8,29569,1,0),
(8,29571,1,0),
(8,29603,1,0),
(8,29605,1,0),
(8,29606,1,0),
(8,29608,1,0),
(8,29610,1,0),
(8,29611,1,0),
(8,29613,1,0),
(8,29614,1,0),
(8,29615,1,0),
(8,29616,1,0),
(8,29617,1,0),
(8,29619,1,0),
(8,29620,1,0),
(8,29621,1,0),
(8,29622,1,0),
(8,29628,1,0),
(8,29629,1,0),
(8,29630,1,0),
(8,29642,1,0),
(8,29643,1,0),
(8,29645,1,0),
(8,29648,1,0),
(8,29649,1,0),
(8,29654,1,0),
(8,29656,1,0),
(8,29657,1,0),
(8,29658,1,0),
(8,29662,1,0),
(8,29663,1,0),
(8,29664,1,0),
(8,29668,1,0),
(8,29669,1,0),
(8,29671,1,0),
(8,29672,1,0),
(8,29688,1,0),
(8,29692,1,0),
(8,29693,1,0),
(8,29694,1,0),
(8,29695,1,0),
(8,29696,1,0),
(8,29697,1,0),
(8,29698,1,0),
(8,29699,1,0),
(8,29700,1,0),
(8,29728,1,0),
(8,29729,1,0),
(8,29932,1,0),
(8,30303,1,0),
(8,30304,1,0),
(8,30305,1,0),
(8,30306,1,0),
(8,30307,1,0),
(8,30308,1,0),
(8,30309,1,0),
(8,30310,1,0),
(8,30311,1,0),
(8,30312,1,0),
(8,30313,1,0),
(8,30314,1,0),
(8,30315,1,0),
(8,30316,1,0),
(8,30317,1,0),
(8,30318,1,0),
(8,30325,1,0),
(8,30329,1,0),
(8,30332,1,0),
(8,30334,1,0),
(8,30337,1,0),
(8,30341,1,0),
(8,30342,1,0),
(8,30343,1,0),
(8,30344,1,0),
(8,30346,1,0),
(8,30347,1,0),
(8,30348,1,0),
(8,30349,1,0),
(8,30547,1,0),
(8,30548,1,0),
(8,30549,1,0),
(8,30551,1,0),
(8,30552,1,0),
(8,30556,1,0),
(8,30558,1,0),
(8,30560,1,0),
(8,30561,1,0),
(8,30563,1,0),
(8,30565,1,0),
(8,30566,1,0),
(8,30568,1,0),
(8,30569,1,0),
(8,30570,1,0),
(8,30573,1,0),
(8,30574,1,0),
(8,30575,1,0),
(8,31048,1,0),
(8,31049,1,0),
(8,31050,1,0),
(8,31051,1,0),
(8,31052,1,0),
(8,31053,1,0),
(8,31054,1,0),
(8,31055,1,0),
(8,31056,1,0),
(8,31057,1,0),
(8,31058,1,0),
(8,31060,1,0),
(8,31061,1,0),
(8,31062,1,0),
(8,31063,1,0),
(8,31064,1,0),
(8,31065,1,0),
(8,31066,1,0),
(8,31067,1,0),
(8,31068,1,0),
(8,31070,1,0),
(8,31071,1,0),
(8,31072,1,0),
(8,31076,1,0),
(8,31077,1,0),
(8,31078,1,0),
(8,31079,1,0),
(8,31080,1,0),
(8,31081,1,0),
(8,31082,1,0),
(8,31083,1,0),
(8,31084,1,0),
(8,31085,1,0),
(8,31087,1,0),
(8,31088,1,0),
(8,31089,1,0),
(8,31090,1,0),
(8,31091,1,0),
(8,31092,1,0),
(8,31094,1,0),
(8,31095,1,0),
(8,31096,1,0),
(8,31097,1,0),
(8,31098,1,0),
(8,31099,1,0),
(8,31100,1,0),
(8,31101,1,0),
(8,31102,1,0),
(8,31103,1,0),
(8,31104,1,0),
(8,31105,1,0),
(8,31106,1,0),
(8,31107,1,0),
(8,31108,1,0),
(8,31109,1,0),
(8,31110,1,0),
(8,31111,1,0),
(8,31112,1,0),
(8,31113,1,0),
(8,31149,1,0),
(8,31252,1,0),
(8,31373,1,0),
(8,31430,1,0),
(8,31431,1,0),
(8,31432,1,0),
(8,31433,1,0),
(8,31434,1,0),
(8,31435,1,0),
(8,31437,1,0),
(8,31438,1,0),
(8,31440,1,0),
(8,31441,1,0),
(8,31442,1,0),
(8,31443,1,0),
(8,31444,1,0),
(8,31448,1,0),
(8,31449,1,0),
(8,31450,1,0),
(8,31451,1,0),
(8,31452,1,0),
(8,31453,1,0),
(8,31454,1,0),
(8,31455,1,0),
(8,31456,1,0),
(8,31459,1,0),
(8,31460,1,0),
(8,31461,1,0),
(8,32178,1,0),
(8,32179,1,0),
(8,32284,1,0),
(8,32285,1,0),
(8,32454,1,0),
(8,32455,1,0),
(8,32456,1,0),
(8,32457,1,0),
(8,32458,1,0),
(8,32461,1,0),
(8,32462,1,0),
(8,32463,1,0),
(8,32464,1,0),
(8,32465,1,0),
(8,32466,1,0),
(8,32467,1,0),
(8,32468,1,0),
(8,32469,1,0),
(8,32470,1,0),
(8,32471,1,0),
(8,32472,1,0),
(8,32473,1,0),
(8,32478,1,0),
(8,32479,1,0),
(8,32480,1,0),
(8,32481,1,0),
(8,32482,1,0),
(8,32485,1,0),
(8,32487,1,0),
(8,32488,1,0),
(8,32489,1,0),
(8,32490,1,0),
(8,32493,1,0),
(8,32494,1,0),
(8,32495,1,0),
(8,32496,1,0),
(8,32497,1,0),
(8,32498,1,0),
(8,32499,1,0),
(8,32500,1,0),
(8,32501,1,0),
(8,32502,1,0),
(8,32503,1,0),
(8,32655,1,0),
(8,32656,1,0),
(8,32657,1,0),
(8,32664,1,0),
(8,32665,1,0),
(8,32667,1,0),
(8,32765,1,0),
(8,32766,1,0),
(8,32801,1,0),
(8,32807,1,0),
(8,32808,1,0),
(8,32809,1,0),
(8,32810,1,0),
(8,32814,1,0),
(8,32866,1,0),
(8,32867,1,0),
(8,32868,1,0),
(8,32869,1,0),
(8,32870,1,0),
(8,32871,1,0),
(8,32872,1,0),
(8,32873,1,0),
(8,32874,1,0),
(8,33153,1,0),
(8,33276,1,0),
(8,33277,1,0),
(8,33278,1,0),
(8,33279,1,0),
(8,33284,1,0),
(8,33285,1,0),
(8,33286,1,0),
(8,33287,1,0),
(8,33288,1,0),
(8,33289,1,0),
(8,33290,1,0),
(8,33291,1,0),
(8,33292,1,0),
(8,33293,1,0),
(8,33294,1,0),
(8,33295,1,0),
(8,33296,1,0),
(8,33732,1,0),
(8,33733,1,0),
(8,33738,1,0),
(8,33740,1,0),
(8,33741,1,0),
(8,33990,1,0),
(8,33991,1,0),
(8,33992,1,0),
(8,33993,1,0),
(8,33994,1,0),
(8,33995,1,0),
(8,33996,1,0),
(8,33997,1,0),
(8,33999,1,0),
(8,34001,1,0),
(8,34002,1,0),
(8,34003,1,0),
(8,34004,1,0),
(8,34005,1,0),
(8,34006,1,0),
(8,34007,1,0),
(8,34008,1,0),
(8,34009,1,0),
(8,34010,1,0),
(8,34069,1,0),
(8,34529,1,0),
(8,34530,1,0),
(8,34533,1,0),
(8,34534,1,0),
(8,34535,1,0),
(8,34537,1,0),
(8,34538,1,0),
(8,34540,1,0),
(8,34541,1,0),
(8,34542,1,0),
(8,34543,1,0),
(8,34544,1,0),
(8,34545,1,0),
(8,34546,1,0),
(8,34547,1,0),
(8,34548,1,0),
(8,34590,1,0),
(8,34607,1,0),
(8,34608,1,0),
(8,34955,1,0),
(8,34959,1,0),
(8,34960,1,0),
(8,34961,1,0),
(8,34979,1,0),
(8,34981,1,0),
(8,34982,1,0),
(8,34983,1,0),
(8,35182,1,0),
(8,35520,1,0),
(8,35521,1,0),
(8,35522,1,0),
(8,35523,1,0),
(8,35524,1,0),
(8,35525,1,0),
(8,35526,1,0),
(8,35527,1,0),
(8,35528,1,0),
(8,35529,1,0),
(8,35530,1,0),
(8,35531,1,0),
(8,35532,1,0),
(8,35533,1,0),
(8,35534,1,0),
(8,35535,1,0),
(8,35536,1,0),
(8,35537,1,0),
(8,35538,1,0),
(8,35539,1,0),
(8,35540,1,0),
(8,35543,1,0),
(8,35544,1,0),
(8,35549,1,0),
(8,35554,1,0),
(8,35555,1,0),
(8,35557,1,0),
(8,35558,1,0),
(8,35559,1,0),
(8,35560,1,0),
(8,35561,1,0),
(8,35562,1,0),
(8,35563,1,0),
(8,35564,1,0),
(8,35567,1,0),
(8,35568,1,0),
(8,35572,1,0),
(8,35573,1,0),
(8,35574,1,0),
(8,35575,1,0),
(8,35576,1,0),
(8,35577,1,0),
(8,35580,1,0),
(8,35582,1,0),
(8,35584,1,0),
(8,35585,1,0),
(8,35587,1,0),
(8,35588,1,0),
(8,35589,1,0),
(8,35590,1,0),
(8,35591,1,0),
(8,35886,1,0),
(8,35912,1,0),
(8,36074,1,0),
(8,36075,1,0),
(8,36076,1,0),
(8,36077,1,0),
(8,36078,1,0),
(8,36079,1,0),
(8,36122,1,0),
(8,36124,1,0),
(8,36125,1,0),
(8,36126,1,0),
(8,36128,1,0),
(8,36129,1,0),
(8,36130,1,0),
(8,36131,1,0),
(8,36133,1,0),
(8,36134,1,0),
(8,36135,1,0),
(8,36136,1,0),
(8,36137,1,0),
(8,36210,1,0),
(8,36256,1,0),
(8,36257,1,0),
(8,36258,1,0),
(8,36259,1,0),
(8,36260,1,0),
(8,36261,1,0),
(8,36262,1,0),
(8,36263,1,0),
(8,36315,1,0),
(8,36316,1,0),
(8,36317,1,0),
(8,36318,1,0),
(8,36349,1,0),
(8,36351,1,0),
(8,36352,1,0),
(8,36353,1,0),
(8,36355,1,0),
(8,36356,1,0),
(8,36357,1,0),
(8,36358,1,0),
(8,36359,1,0),
(8,36389,1,0),
(8,36390,1,0),
(8,36391,1,0),
(8,36392,1,0),
(8,36523,1,0),
(8,36524,1,0),
(8,36525,1,0),
(8,36526,1,0),
(8,36665,1,0),
(8,36667,1,0),
(8,36668,1,0),
(8,36669,1,0),
(8,36670,1,0),
(8,36672,1,0),
(8,36686,1,0),
(8,36954,1,0),
(8,36955,1,0),
(8,37818,1,0),
(8,37836,1,0),
(8,37855,1,0),
(8,37873,1,0),
(8,37882,1,0),
(8,37883,1,0),
(8,37884,1,0),
(8,38068,1,0),
(8,38070,1,0),
(8,38175,1,0),
(8,38473,1,0),
(8,38475,1,0),
(8,38476,1,0),
(8,38477,1,0),
(8,38478,1,0),
(8,38479,1,0),
(8,38503,1,0),
(8,38504,1,0),
(8,38505,1,0),
(8,38734,1,0),
(8,38867,1,0),
(8,38868,1,0),
(8,38960,1,0),
(8,38961,1,0),
(8,38962,1,0),
(8,39258,1,0),
(8,39451,1,0),
(8,39452,1,0),
(8,39455,1,0),
(8,39458,1,0),
(8,39462,1,0),
(8,39463,1,0),
(8,39466,1,0),
(8,39467,1,0),
(8,39470,1,0),
(8,39471,1,0),
(8,39636,1,0),
(8,39637,1,0),
(8,39638,1,0),
(8,39639,1,0),
(8,39705,1,0),
(8,39706,1,0),
(8,39710,1,0),
(8,39711,1,0),
(8,39712,1,0),
(8,39713,1,0),
(8,39714,1,0),
(8,39715,1,0),
(8,39716,1,0),
(8,39717,1,0),
(8,39718,1,0),
(8,39719,1,0),
(8,39720,1,0),
(8,39721,1,0),
(8,39722,1,0),
(8,39723,1,0),
(8,39724,1,0),
(8,39725,1,0),
(8,39727,1,0),
(8,39728,1,0),
(8,39729,1,0),
(8,39730,1,0),
(8,39731,1,0),
(8,39732,1,0),
(8,39733,1,0),
(8,39734,1,0),
(8,39735,1,0),
(8,39736,1,0),
(8,39737,1,0),
(8,39738,1,0),
(8,39739,1,0),
(8,39740,1,0),
(8,39741,1,0),
(8,39742,1,0),
(8,39895,1,0),
(8,39961,1,0),
(8,39963,1,0),
(8,39971,1,0),
(8,39973,1,0),
(8,39997,1,0),
(8,40001,1,0),
(8,40002,1,0),
(8,40003,1,0),
(8,40004,1,0),
(8,40005,1,0),
(8,40006,1,0),
(8,40020,1,0),
(8,40021,1,0),
(8,40023,1,0),
(8,40024,1,0),
(8,40033,1,0),
(8,40034,1,0),
(8,40035,1,0),
(8,40036,1,0),
(8,40060,1,0),
(8,40274,1,0),
(8,40514,1,0),
(8,41132,1,0),
(8,41133,1,0),
(8,41134,1,0),
(8,41135,1,0),
(8,41156,1,0),
(8,41157,1,0),
(8,41158,1,0),
(8,41160,1,0),
(8,41161,1,0),
(8,41162,1,0),
(8,41163,1,0),
(8,41164,1,0),
(8,41205,1,0),
(8,41206,1,0),
(8,41207,1,0),
(8,41208,1,0),
(8,41307,1,0),
(8,41312,1,0),
(8,41414,1,0),
(8,41415,1,0),
(8,41418,1,0),
(8,41420,1,0),
(8,41429,1,0),
(8,41458,1,0),
(8,41500,1,0),
(8,41501,1,0),
(8,41502,1,0),
(8,41503,1,0),
(8,42296,1,0),
(8,42302,1,0),
(8,42305,1,0),
(8,42546,1,0),
(8,42558,1,0),
(8,42588,1,0),
(8,42589,1,0),
(8,42590,1,0),
(8,42591,1,0),
(8,42592,1,0),
(8,42593,1,0),
(8,42613,1,0),
(8,42615,1,0),
(8,42620,1,0),
(8,42662,1,0),
(8,42688,1,0),
(8,42731,1,0),
(8,42736,1,0),
(8,42974,1,0),
(8,43493,1,0),
(8,43549,1,0),
(8,43676,1,0),
(8,43707,1,0),
(8,43758,1,0),
(8,43761,1,0),
(8,43765,1,0),
(8,43772,1,0),
(8,43779,1,0),
(8,43846,1,0),
(8,44155,1,0),
(8,44157,1,0),
(8,44343,1,0),
(8,44344,1,0),
(8,44359,1,0),
(8,44383,1,0),
(8,44391,1,0),
(8,44483,1,0),
(8,44484,1,0),
(8,44488,1,0),
(8,44489,1,0),
(8,44492,1,0),
(8,44494,1,0),
(8,44500,1,0),
(8,44506,1,0),
(8,44508,1,0),
(8,44509,1,0),
(8,44510,1,0),
(8,44513,1,0),
(8,44524,1,0),
(8,44528,1,0),
(8,44529,1,0),
(8,44555,1,0),
(8,44556,1,0),
(8,44575,1,0),
(8,44576,1,0),
(8,44582,1,0),
(8,44584,1,0),
(8,44588,1,0),
(8,44589,1,0),
(8,44590,1,0),
(8,44591,1,0),
(8,44592,1,0),
(8,44593,1,0),
(8,44595,1,0),
(8,44596,1,0),
(8,44598,1,0),
(8,44612,1,0),
(8,44616,1,0),
(8,44621,1,0),
(8,44623,1,0),
(8,44625,1,0),
(8,44629,1,0),
(8,44630,1,0),
(8,44631,1,0),
(8,44633,1,0),
(8,44635,1,0),
(8,44636,1,0),
(8,44645,1,0),
(8,44768,1,0),
(8,44770,1,0),
(8,44794,1,0),
(8,44950,1,0),
(8,44953,1,0),
(8,44958,1,0),
(8,44970,1,0),
(8,45022,1,0),
(8,45061,1,0),
(8,45100,1,0),
(8,45117,1,0),
(8,45363,1,0),
(8,45542,1,0),
(8,45545,1,0),
(8,45546,1,0),
(8,45549,1,0),
(8,45550,1,0),
(8,45551,1,0),
(8,45552,1,0),
(8,45553,1,0),
(8,45554,1,0),
(8,45555,1,0),
(8,45556,1,0),
(8,45557,1,0),
(8,45558,1,0),
(8,45559,1,0),
(8,45560,1,0),
(8,45561,1,0),
(8,45562,1,0),
(8,45563,1,0),
(8,45564,1,0),
(8,45565,1,0),
(8,45566,1,0),
(8,45567,1,0),
(8,45568,1,0),
(8,45569,1,0),
(8,45570,1,0),
(8,45571,1,0),
(8,45645,1,0),
(8,45646,1,0),
(8,45647,1,0),
(8,45648,1,0),
(8,45649,1,0),
(8,45650,1,0),
(8,45659,1,0),
(8,45695,1,0),
(8,45765,1,0),
(8,45813,1,0),
(8,46114,1,0),
(8,46115,1,0),
(8,46122,1,0),
(8,46123,1,0),
(8,46124,1,0),
(8,46125,1,0),
(8,46126,1,0),
(8,46127,1,0),
(8,46128,1,0),
(8,46129,1,0),
(8,46130,1,0),
(8,46131,1,0),
(8,46132,1,0),
(8,46133,1,0),
(8,46134,1,0),
(8,46135,1,0),
(8,46136,1,0),
(8,46137,1,0),
(8,46138,1,0),
(8,46139,1,0),
(8,46140,1,0),
(8,46141,1,0),
(8,46142,1,0),
(8,46144,1,0),
(8,46403,1,0),
(8,46404,1,0),
(8,46405,1,0),
(8,46578,1,0),
(8,46594,1,0),
(8,46597,1,0),
(8,46601,1,0),
(8,46684,1,0),
(8,46688,1,0),
(8,46697,1,0),
(8,46775,1,0),
(8,46776,1,0),
(8,46777,1,0),
(8,46778,1,0),
(8,46779,1,0),
(8,46803,1,0),
(8,47046,1,0),
(8,47048,1,0),
(8,47049,1,0),
(8,47050,1,0),
(8,47051,1,0),
(8,47053,1,0),
(8,47054,1,0),
(8,47055,1,0),
(8,47056,1,0),
(8,47280,1,0),
(8,47672,1,0),
(8,47766,1,0),
(8,47898,1,0),
(8,47899,1,0),
(8,47900,1,0),
(8,47901,1,0),
(8,48121,1,0),
(8,48247,1,0),
(8,48248,1,0),
(8,48789,1,0),
(8,49677,1,0),
(8,50194,1,0),
(8,50598,1,0),
(8,50599,1,0),
(8,50600,1,0),
(8,50601,1,0),
(8,50602,1,0),
(8,50603,1,0),
(8,50604,1,0),
(8,50605,1,0),
(8,50606,1,0),
(8,50607,1,0),
(8,50608,1,0),
(8,50609,1,0),
(8,50610,1,0),
(8,50611,1,0),
(8,50612,1,0),
(8,50614,1,0),
(8,50616,1,0),
(8,50617,1,0),
(8,50618,1,0),
(8,50619,1,0),
(8,50620,1,0),
(8,50644,1,0),
(8,50647,1,0),
(8,50936,1,0),
(8,50938,1,0),
(8,50939,1,0),
(8,50940,1,0),
(8,50941,1,0),
(8,50942,1,0),
(8,50943,1,0),
(8,50944,1,0),
(8,50945,1,0),
(8,50946,1,0),
(8,50947,1,0),
(8,50948,1,0),
(8,50949,1,0),
(8,50950,1,0),
(8,50951,1,0),
(8,50952,1,0),
(8,50953,1,0),
(8,50954,1,0),
(8,50955,1,0),
(8,50956,1,0),
(8,50957,1,0),
(8,50958,1,0),
(8,50959,1,0),
(8,50960,1,0),
(8,50961,1,0),
(8,50962,1,0),
(8,50963,1,0),
(8,50964,1,0),
(8,50965,1,0),
(8,50966,1,0),
(8,50967,1,0),
(8,50970,1,0),
(8,50971,1,0),
(8,51296,1,0),
(8,51300,1,0),
(8,51302,1,0),
(8,51304,1,0),
(8,51306,1,0),
(8,51309,1,0),
(8,51311,1,0),
(8,51313,1,0),
(8,51568,1,0),
(8,51569,1,0),
(8,51570,1,0),
(8,51571,1,0),
(8,51572,1,0),
(8,52175,1,0),
(8,52567,1,0),
(8,52568,1,0),
(8,52569,1,0),
(8,52570,1,0),
(8,52571,1,0),
(8,52572,1,0),
(8,52733,1,0),
(8,52739,1,0),
(8,52840,1,0),
(8,52843,1,0),
(8,53042,1,0),
(8,53056,1,0),
(8,53281,1,0),
(8,53462,1,0),
(8,53771,1,0),
(8,53773,1,0),
(8,53774,1,0),
(8,53775,1,0),
(8,53776,1,0),
(8,53777,1,0),
(8,53779,1,0),
(8,53780,1,0),
(8,53781,1,0),
(8,53782,1,0),
(8,53783,1,0),
(8,53784,1,0),
(8,53812,1,0),
(8,53830,1,0),
(8,53831,1,0),
(8,53832,1,0),
(8,53834,1,0),
(8,53835,1,0),
(8,53836,1,0),
(8,53837,1,0),
(8,53838,1,0),
(8,53839,1,0),
(8,53840,1,0),
(8,53841,1,0),
(8,53842,1,0),
(8,53843,1,0),
(8,53844,1,0),
(8,53845,1,0),
(8,53847,1,0),
(8,53848,1,0),
(8,53852,1,0),
(8,53853,1,0),
(8,53854,1,0),
(8,53855,1,0),
(8,53856,1,0),
(8,53857,1,0),
(8,53859,1,0),
(8,53860,1,0),
(8,53861,1,0),
(8,53862,1,0),
(8,53863,1,0),
(8,53864,1,0),
(8,53865,1,0),
(8,53866,1,0),
(8,53867,1,0),
(8,53868,1,0),
(8,53869,1,0),
(8,53870,1,0),
(8,53871,1,0),
(8,53872,1,0),
(8,53873,1,0),
(8,53874,1,0),
(8,53875,1,0),
(8,53876,1,0),
(8,53877,1,0),
(8,53878,1,0),
(8,53879,1,0),
(8,53880,1,0),
(8,53881,1,0),
(8,53882,1,0),
(8,53883,1,0),
(8,53884,1,0),
(8,53885,1,0),
(8,53886,1,0),
(8,53887,1,0),
(8,53888,1,0),
(8,53889,1,0),
(8,53890,1,0),
(8,53891,1,0),
(8,53892,1,0),
(8,53893,1,0),
(8,53894,1,0),
(8,53895,1,0),
(8,53898,1,0),
(8,53899,1,0),
(8,53900,1,0),
(8,53901,1,0),
(8,53902,1,0),
(8,53903,1,0),
(8,53904,1,0),
(8,53905,1,0),
(8,53916,1,0),
(8,53917,1,0),
(8,53918,1,0),
(8,53919,1,0),
(8,53920,1,0),
(8,53921,1,0),
(8,53922,1,0),
(8,53923,1,0),
(8,53924,1,0),
(8,53925,1,0),
(8,53926,1,0),
(8,53927,1,0),
(8,53928,1,0),
(8,53929,1,0),
(8,53930,1,0),
(8,53931,1,0),
(8,53932,1,0),
(8,53933,1,0),
(8,53934,1,0),
(8,53936,1,0),
(8,53937,1,0),
(8,53938,1,0),
(8,53939,1,0),
(8,53940,1,0),
(8,53941,1,0),
(8,53942,1,0),
(8,53943,1,0),
(8,53945,1,0),
(8,53946,1,0),
(8,53947,1,0),
(8,53948,1,0),
(8,53949,1,0),
(8,53950,1,0),
(8,53951,1,0),
(8,53952,1,0),
(8,53953,1,0),
(8,53954,1,0),
(8,53955,1,0),
(8,53956,1,0),
(8,53957,1,0),
(8,53958,1,0),
(8,53959,1,0),
(8,53960,1,0),
(8,53961,1,0),
(8,53962,1,0),
(8,53963,1,0),
(8,53964,1,0),
(8,53965,1,0),
(8,53966,1,0),
(8,53967,1,0),
(8,53968,1,0),
(8,53969,1,0),
(8,53970,1,0),
(8,53971,1,0),
(8,53972,1,0),
(8,53973,1,0),
(8,53974,1,0),
(8,53975,1,0),
(8,53976,1,0),
(8,53977,1,0),
(8,53978,1,0),
(8,53979,1,0),
(8,53980,1,0),
(8,53981,1,0),
(8,53982,1,0),
(8,53983,1,0),
(8,53984,1,0),
(8,53985,1,0),
(8,53986,1,0),
(8,53987,1,0),
(8,53988,1,0),
(8,53989,1,0),
(8,53990,1,0),
(8,53991,1,0),
(8,53992,1,0),
(8,53993,1,0),
(8,53994,1,0),
(8,53995,1,0),
(8,53996,1,0),
(8,53997,1,0),
(8,53998,1,0),
(8,54000,1,0),
(8,54001,1,0),
(8,54002,1,0),
(8,54003,1,0),
(8,54004,1,0),
(8,54005,1,0),
(8,54006,1,0),
(8,54007,1,0),
(8,54008,1,0),
(8,54009,1,0),
(8,54010,1,0),
(8,54011,1,0),
(8,54012,1,0),
(8,54013,1,0),
(8,54014,1,0),
(8,54017,1,0),
(8,54019,1,0),
(8,54020,1,0),
(8,54023,1,0),
(8,54213,1,0),
(8,54218,1,0),
(8,54220,1,0),
(8,54221,1,0),
(8,54222,1,0),
(8,54353,1,0),
(8,54550,1,0),
(8,54551,1,0),
(8,54552,1,0),
(8,54553,1,0),
(8,54554,1,0),
(8,54555,1,0),
(8,54556,1,0),
(8,54557,1,0),
(8,54736,1,0),
(8,54793,1,0),
(8,54917,1,0),
(8,54918,1,0),
(8,54941,1,0),
(8,54944,1,0),
(8,54945,1,0),
(8,54946,1,0),
(8,54947,1,0),
(8,54948,1,0),
(8,54949,1,0),
(8,54978,1,0),
(8,54979,1,0),
(8,54980,1,0),
(8,54981,1,0),
(8,54998,1,0),
(8,54999,1,0),
(8,55002,1,0),
(8,55013,1,0),
(8,55014,1,0),
(8,55015,1,0),
(8,55016,1,0),
(8,55017,1,0),
(8,55055,1,0),
(8,55056,1,0),
(8,55057,1,0),
(8,55058,1,0),
(8,55174,1,0),
(8,55177,1,0),
(8,55179,1,0),
(8,55181,1,0),
(8,55182,1,0),
(8,55183,1,0),
(8,55184,1,0),
(8,55185,1,0),
(8,55186,1,0),
(8,55187,1,0),
(8,55199,1,0),
(8,55200,1,0),
(8,55201,1,0),
(8,55202,1,0),
(8,55203,1,0),
(8,55204,1,0),
(8,55206,1,0),
(8,55243,1,0),
(8,55252,1,0),
(8,55298,1,0),
(8,55300,1,0),
(8,55301,1,0),
(8,55302,1,0),
(8,55303,1,0),
(8,55304,1,0),
(8,55305,1,0),
(8,55306,1,0),
(8,55307,1,0),
(8,55308,1,0),
(8,55309,1,0),
(8,55310,1,0),
(8,55311,1,0),
(8,55312,1,0),
(8,55369,1,0),
(8,55370,1,0),
(8,55371,1,0),
(8,55372,1,0),
(8,55373,1,0),
(8,55374,1,0),
(8,55375,1,0),
(8,55376,1,0),
(8,55377,1,0),
(8,55384,1,0),
(8,55386,1,0),
(8,55387,1,0),
(8,55388,1,0),
(8,55389,1,0),
(8,55390,1,0),
(8,55392,1,0),
(8,55393,1,0),
(8,55394,1,0),
(8,55395,1,0),
(8,55396,1,0),
(8,55397,1,0),
(8,55398,1,0),
(8,55399,1,0),
(8,55400,1,0),
(8,55401,1,0),
(8,55402,1,0),
(8,55403,1,0),
(8,55404,1,0),
(8,55405,1,0),
(8,55407,1,0),
(8,55534,1,0),
(8,55628,1,0),
(8,55641,1,0),
(8,55642,1,0),
(8,55656,1,0),
(8,55732,1,0),
(8,55769,1,0),
(8,55777,1,0),
(8,55834,1,0),
(8,55835,1,0),
(8,55839,1,0),
(8,55898,1,0),
(8,55899,1,0),
(8,55900,1,0),
(8,55901,1,0),
(8,55902,1,0),
(8,55903,1,0),
(8,55904,1,0),
(8,55906,1,0),
(8,55907,1,0),
(8,55908,1,0),
(8,55910,1,0),
(8,55911,1,0),
(8,55913,1,0),
(8,55914,1,0),
(8,55919,1,0),
(8,55920,1,0),
(8,55921,1,0),
(8,55922,1,0),
(8,55923,1,0),
(8,55924,1,0),
(8,55925,1,0),
(8,55941,1,0),
(8,55943,1,0),
(8,55993,1,0),
(8,55994,1,0),
(8,55995,1,0),
(8,55996,1,0),
(8,55997,1,0),
(8,55998,1,0),
(8,55999,1,0),
(8,56000,1,0),
(8,56001,1,0),
(8,56002,1,0),
(8,56003,1,0),
(8,56004,1,0),
(8,56005,1,0),
(8,56006,1,0),
(8,56007,1,0),
(8,56008,1,0),
(8,56009,1,0),
(8,56010,1,0),
(8,56011,1,0),
(8,56014,1,0),
(8,56015,1,0),
(8,56016,1,0),
(8,56017,1,0),
(8,56018,1,0),
(8,56019,1,0),
(8,56020,1,0),
(8,56021,1,0),
(8,56022,1,0),
(8,56023,1,0),
(8,56024,1,0),
(8,56025,1,0),
(8,56026,1,0),
(8,56027,1,0),
(8,56028,1,0),
(8,56029,1,0),
(8,56030,1,0),
(8,56031,1,0),
(8,56034,1,0),
(8,56039,1,0),
(8,56048,1,0),
(8,56049,1,0),
(8,56052,1,0),
(8,56053,1,0),
(8,56054,1,0),
(8,56055,1,0),
(8,56056,1,0),
(8,56074,1,0),
(8,56076,1,0),
(8,56077,1,0),
(8,56079,1,0),
(8,56081,1,0),
(8,56083,1,0),
(8,56084,1,0),
(8,56085,1,0),
(8,56086,1,0),
(8,56087,1,0),
(8,56088,1,0),
(8,56089,1,0),
(8,56193,1,0),
(8,56194,1,0),
(8,56195,1,0),
(8,56196,1,0),
(8,56197,1,0),
(8,56199,1,0),
(8,56201,1,0),
(8,56202,1,0),
(8,56203,1,0),
(8,56205,1,0),
(8,56206,1,0),
(8,56208,1,0),
(8,56234,1,0),
(8,56273,1,0),
(8,56280,1,0),
(8,56349,1,0),
(8,56357,1,0),
(8,56400,1,0),
(8,56459,1,0),
(8,56460,1,0),
(8,56461,1,0),
(8,56462,1,0),
(8,56463,1,0),
(8,56464,1,0),
(8,56466,1,0),
(8,56467,1,0),
(8,56468,1,0),
(8,56469,1,0),
(8,56470,1,0),
(8,56471,1,0),
(8,56472,1,0),
(8,56473,1,0),
(8,56474,1,0),
(8,56475,1,0),
(8,56476,1,0),
(8,56477,1,0),
(8,56478,1,0),
(8,56479,1,0),
(8,56480,1,0),
(8,56483,1,0),
(8,56496,1,0),
(8,56497,1,0),
(8,56498,1,0),
(8,56499,1,0),
(8,56500,1,0),
(8,56501,1,0),
(8,56514,1,0),
(8,56519,1,0),
(8,56530,1,0),
(8,56531,1,0),
(8,56549,1,0),
(8,56550,1,0),
(8,56551,1,0),
(8,56552,1,0),
(8,56553,1,0),
(8,56554,1,0),
(8,56555,1,0),
(8,56556,1,0),
(8,56943,1,0),
(8,56944,1,0),
(8,56945,1,0),
(8,56946,1,0),
(8,56947,1,0),
(8,56948,1,0),
(8,56949,1,0),
(8,56950,1,0),
(8,56951,1,0),
(8,56952,1,0),
(8,56953,1,0),
(8,56954,1,0),
(8,56955,1,0),
(8,56956,1,0),
(8,56957,1,0),
(8,56958,1,0),
(8,56959,1,0),
(8,56960,1,0),
(8,56961,1,0),
(8,56963,1,0),
(8,56965,1,0),
(8,56968,1,0),
(8,56971,1,0),
(8,56972,1,0),
(8,56973,1,0),
(8,56974,1,0),
(8,56975,1,0),
(8,56976,1,0),
(8,56977,1,0),
(8,56978,1,0),
(8,56979,1,0),
(8,56980,1,0),
(8,56981,1,0),
(8,56982,1,0),
(8,56983,1,0),
(8,56984,1,0),
(8,56985,1,0),
(8,56986,1,0),
(8,56987,1,0),
(8,56988,1,0),
(8,56989,1,0),
(8,56990,1,0),
(8,56991,1,0),
(8,56994,1,0),
(8,56995,1,0),
(8,56996,1,0),
(8,56997,1,0),
(8,56998,1,0),
(8,56999,1,0),
(8,57000,1,0),
(8,57001,1,0),
(8,57002,1,0),
(8,57003,1,0),
(8,57004,1,0),
(8,57005,1,0),
(8,57006,1,0),
(8,57007,1,0),
(8,57008,1,0),
(8,57009,1,0),
(8,57010,1,0),
(8,57011,1,0),
(8,57012,1,0),
(8,57013,1,0),
(8,57014,1,0),
(8,57019,1,0),
(8,57020,1,0),
(8,57021,1,0),
(8,57022,1,0),
(8,57023,1,0),
(8,57024,1,0),
(8,57025,1,0),
(8,57026,1,0),
(8,57027,1,0),
(8,57028,1,0),
(8,57029,1,0),
(8,57030,1,0),
(8,57031,1,0),
(8,57032,1,0),
(8,57033,1,0),
(8,57034,1,0),
(8,57035,1,0),
(8,57036,1,0),
(8,57112,1,0),
(8,57113,1,0),
(8,57114,1,0),
(8,57115,1,0),
(8,57116,1,0),
(8,57117,1,0),
(8,57119,1,0),
(8,57120,1,0),
(8,57121,1,0),
(8,57122,1,0),
(8,57123,1,0),
(8,57124,1,0),
(8,57125,1,0),
(8,57126,1,0),
(8,57127,1,0),
(8,57128,1,0),
(8,57129,1,0),
(8,57130,1,0),
(8,57131,1,0),
(8,57132,1,0),
(8,57133,1,0),
(8,57151,1,0),
(8,57152,1,0),
(8,57153,1,0),
(8,57154,1,0),
(8,57155,1,0),
(8,57156,1,0),
(8,57157,1,0),
(8,57158,1,0),
(8,57159,1,0),
(8,57160,1,0),
(8,57161,1,0),
(8,57162,1,0),
(8,57163,1,0),
(8,57164,1,0),
(8,57165,1,0),
(8,57166,1,0),
(8,57167,1,0),
(8,57168,1,0),
(8,57169,1,0),
(8,57170,1,0),
(8,57172,1,0),
(8,57181,1,0),
(8,57183,1,0),
(8,57184,1,0),
(8,57185,1,0),
(8,57186,1,0),
(8,57187,1,0),
(8,57188,1,0),
(8,57189,1,0),
(8,57190,1,0),
(8,57191,1,0),
(8,57192,1,0),
(8,57193,1,0),
(8,57194,1,0),
(8,57195,1,0),
(8,57196,1,0),
(8,57197,1,0),
(8,57198,1,0),
(8,57199,1,0),
(8,57200,1,0),
(8,57201,1,0),
(8,57202,1,0),
(8,57207,1,0),
(8,57208,1,0),
(8,57209,1,0),
(8,57210,1,0),
(8,57211,1,0),
(8,57212,1,0),
(8,57213,1,0),
(8,57214,1,0),
(8,57215,1,0),
(8,57216,1,0),
(8,57217,1,0),
(8,57218,1,0),
(8,57219,1,0),
(8,57220,1,0),
(8,57221,1,0),
(8,57222,1,0),
(8,57223,1,0),
(8,57224,1,0),
(8,57225,1,0),
(8,57226,1,0),
(8,57227,1,0),
(8,57228,1,0),
(8,57229,1,0),
(8,57230,1,0),
(8,57231,1,0),
(8,57232,1,0),
(8,57233,1,0),
(8,57234,1,0),
(8,57235,1,0),
(8,57236,1,0),
(8,57237,1,0),
(8,57238,1,0),
(8,57239,1,0),
(8,57240,1,0),
(8,57241,1,0),
(8,57242,1,0),
(8,57243,1,0),
(8,57244,1,0),
(8,57245,1,0),
(8,57246,1,0),
(8,57247,1,0),
(8,57248,1,0),
(8,57249,1,0),
(8,57250,1,0),
(8,57251,1,0),
(8,57252,1,0),
(8,57253,1,0),
(8,57257,1,0),
(8,57258,1,0),
(8,57259,1,0),
(8,57260,1,0),
(8,57261,1,0),
(8,57262,1,0),
(8,57263,1,0),
(8,57264,1,0),
(8,57265,1,0),
(8,57266,1,0),
(8,57267,1,0),
(8,57268,1,0),
(8,57269,1,0),
(8,57270,1,0),
(8,57271,1,0),
(8,57272,1,0),
(8,57273,1,0),
(8,57274,1,0),
(8,57275,1,0),
(8,57276,1,0),
(8,57277,1,0),
(8,57421,1,0),
(8,57423,1,0),
(8,57425,1,0),
(8,57427,1,0),
(8,57433,1,0),
(8,57434,1,0),
(8,57435,1,0),
(8,57436,1,0),
(8,57437,1,0),
(8,57438,1,0),
(8,57439,1,0),
(8,57440,1,0),
(8,57441,1,0),
(8,57442,1,0),
(8,57443,1,0),
(8,57690,1,0),
(8,57691,1,0),
(8,57692,1,0),
(8,57694,1,0),
(8,57696,1,0),
(8,57699,1,0),
(8,57701,1,0),
(8,57703,1,0),
(8,57704,1,0),
(8,57706,1,0),
(8,57707,1,0),
(8,57708,1,0),
(8,57709,1,0),
(8,57710,1,0),
(8,57711,1,0),
(8,57712,1,0),
(8,57713,1,0),
(8,57714,1,0),
(8,57715,1,0),
(8,57716,1,0),
(8,57719,1,0),
(8,58065,1,0),
(8,58141,1,0),
(8,58142,1,0),
(8,58143,1,0),
(8,58144,1,0),
(8,58145,1,0),
(8,58146,1,0),
(8,58147,1,0),
(8,58148,1,0),
(8,58149,1,0),
(8,58150,1,0),
(8,58286,1,0),
(8,58287,1,0),
(8,58288,1,0),
(8,58289,1,0),
(8,58296,1,0),
(8,58297,1,0),
(8,58298,1,0),
(8,58299,1,0),
(8,58300,1,0),
(8,58301,1,0),
(8,58302,1,0),
(8,58303,1,0),
(8,58305,1,0),
(8,58306,1,0),
(8,58307,1,0),
(8,58308,1,0),
(8,58310,1,0),
(8,58311,1,0),
(8,58312,1,0),
(8,58313,1,0),
(8,58314,1,0),
(8,58315,1,0),
(8,58316,1,0),
(8,58317,1,0),
(8,58318,1,0),
(8,58319,1,0),
(8,58320,1,0),
(8,58321,1,0),
(8,58322,1,0),
(8,58323,1,0),
(8,58324,1,0),
(8,58325,1,0),
(8,58326,1,0),
(8,58327,1,0),
(8,58328,1,0),
(8,58329,1,0),
(8,58330,1,0),
(8,58331,1,0),
(8,58332,1,0),
(8,58333,1,0),
(8,58336,1,0),
(8,58337,1,0),
(8,58338,1,0),
(8,58339,1,0),
(8,58340,1,0),
(8,58341,1,0),
(8,58342,1,0),
(8,58343,1,0),
(8,58344,1,0),
(8,58345,1,0),
(8,58346,1,0),
(8,58347,1,0),
(8,58472,1,0),
(8,58473,1,0),
(8,58476,1,0),
(8,58478,1,0),
(8,58480,1,0),
(8,58481,1,0),
(8,58482,1,0),
(8,58483,1,0),
(8,58484,1,0),
(8,58485,1,0),
(8,58486,1,0),
(8,58487,1,0),
(8,58488,1,0),
(8,58489,1,0),
(8,58490,1,0),
(8,58491,1,0),
(8,58492,1,0),
(8,58507,1,0),
(8,58512,1,0),
(8,58521,1,0),
(8,58523,1,0),
(8,58525,1,0),
(8,58527,1,0),
(8,58528,1,0),
(8,58565,1,0),
(8,58868,1,0),
(8,58871,1,0),
(8,58954,1,0),
(8,59315,1,0),
(8,59326,1,0),
(8,59338,1,0),
(8,59339,1,0),
(8,59340,1,0),
(8,59387,1,0),
(8,59390,1,0),
(8,59405,1,0),
(8,59406,1,0),
(8,59436,1,0),
(8,59438,1,0),
(8,59440,1,0),
(8,59441,1,0),
(8,59442,1,0),
(8,59475,1,0),
(8,59478,1,0),
(8,59480,1,0),
(8,59484,1,0),
(8,59486,1,0),
(8,59487,1,0),
(8,59488,1,0),
(8,59489,1,0),
(8,59490,1,0),
(8,59491,1,0),
(8,59493,1,0),
(8,59494,1,0),
(8,59495,1,0),
(8,59496,1,0),
(8,59497,1,0),
(8,59498,1,0),
(8,59499,1,0),
(8,59500,1,0),
(8,59501,1,0),
(8,59502,1,0),
(8,59503,1,0),
(8,59504,1,0),
(8,59559,1,0),
(8,59560,1,0),
(8,59561,1,0),
(8,59582,1,0),
(8,59583,1,0),
(8,59584,1,0),
(8,59585,1,0),
(8,59586,1,0),
(8,59587,1,0),
(8,59588,1,0),
(8,59589,1,0),
(8,59619,1,0),
(8,59621,1,0),
(8,59625,1,0),
(8,59636,1,0),
(8,59759,1,0),
(8,60336,1,0),
(8,60337,1,0),
(8,60350,1,0),
(8,60354,1,0),
(8,60355,1,0),
(8,60356,1,0),
(8,60357,1,0),
(8,60365,1,0),
(8,60366,1,0),
(8,60367,1,0),
(8,60396,1,0),
(8,60403,1,0),
(8,60405,1,0),
(8,60583,1,0),
(8,60584,1,0),
(8,60599,1,0),
(8,60600,1,0),
(8,60601,1,0),
(8,60604,1,0),
(8,60605,1,0),
(8,60606,1,0),
(8,60607,1,0),
(8,60608,1,0),
(8,60609,1,0),
(8,60611,1,0),
(8,60613,1,0),
(8,60616,1,0),
(8,60619,1,0),
(8,60620,1,0),
(8,60621,1,0),
(8,60622,1,0),
(8,60623,1,0),
(8,60624,1,0),
(8,60627,1,0),
(8,60629,1,0),
(8,60630,1,0),
(8,60631,1,0),
(8,60637,1,0),
(8,60640,1,0),
(8,60643,1,0),
(8,60645,1,0),
(8,60647,1,0),
(8,60649,1,0),
(8,60651,1,0),
(8,60652,1,0),
(8,60653,1,0),
(8,60655,1,0),
(8,60658,1,0),
(8,60660,1,0),
(8,60663,1,0),
(8,60665,1,0),
(8,60666,1,0),
(8,60668,1,0),
(8,60669,1,0),
(8,60671,1,0),
(8,60691,1,0),
(8,60692,1,0),
(8,60697,1,0),
(8,60702,1,0),
(8,60703,1,0),
(8,60704,1,0),
(8,60705,1,0),
(8,60706,1,0),
(8,60707,1,0),
(8,60711,1,0),
(8,60712,1,0),
(8,60714,1,0),
(8,60715,1,0),
(8,60716,1,0),
(8,60718,1,0),
(8,60720,1,0),
(8,60721,1,0),
(8,60723,1,0),
(8,60725,1,0),
(8,60727,1,0),
(8,60728,1,0),
(8,60729,1,0),
(8,60730,1,0),
(8,60731,1,0),
(8,60732,1,0),
(8,60734,1,0),
(8,60735,1,0),
(8,60737,1,0),
(8,60743,1,0),
(8,60746,1,0),
(8,60747,1,0),
(8,60748,1,0),
(8,60749,1,0),
(8,60750,1,0),
(8,60751,1,0),
(8,60752,1,0),
(8,60754,1,0),
(8,60755,1,0),
(8,60756,1,0),
(8,60757,1,0),
(8,60758,1,0),
(8,60759,1,0),
(8,60760,1,0),
(8,60761,1,0),
(8,60763,1,0),
(8,60767,1,0),
(8,60874,1,0),
(8,60893,1,0),
(8,60969,1,0),
(8,60971,1,0),
(8,60990,1,0),
(8,60993,1,0),
(8,60994,1,0),
(8,60996,1,0),
(8,60997,1,0),
(8,60998,1,0),
(8,60999,1,0),
(8,61000,1,0),
(8,61002,1,0),
(8,61008,1,0),
(8,61009,1,0),
(8,61010,1,0),
(8,61117,1,0),
(8,61118,1,0),
(8,61119,1,0),
(8,61120,1,0),
(8,61177,1,0),
(8,61288,1,0),
(8,61471,1,0),
(8,61483,1,0),
(8,61677,1,0),
(8,62044,1,0),
(8,62045,1,0),
(8,62049,1,0),
(8,62050,1,0),
(8,62051,1,0),
(8,62162,1,0),
(8,62176,1,0),
(8,62177,1,0),
(8,62202,1,0),
(8,62213,1,0),
(8,62242,1,0),
(8,62256,1,0),
(8,62257,1,0),
(8,62350,1,0),
(8,62409,1,0),
(8,62410,1,0),
(8,62448,1,0),
(8,62941,1,0),
(8,62948,1,0),
(8,62959,1,0),
(8,63182,1,0),
(8,63187,1,0),
(8,63188,1,0),
(8,63189,1,0),
(8,63190,1,0),
(8,63191,1,0),
(8,63192,1,0),
(8,63194,1,0),
(8,63195,1,0),
(8,63196,1,0),
(8,63197,1,0),
(8,63198,1,0),
(8,63199,1,0),
(8,63200,1,0),
(8,63201,1,0),
(8,63203,1,0),
(8,63204,1,0),
(8,63205,1,0),
(8,63206,1,0),
(8,63732,1,0),
(8,63742,1,0),
(8,63743,1,0),
(8,63746,1,0),
(8,63750,1,0),
(8,63765,1,0),
(8,63770,1,0),
(8,63924,1,0),
(8,64051,1,0),
(8,64053,1,0),
(8,64054,1,0),
(8,64246,1,0),
(8,64247,1,0),
(8,64248,1,0),
(8,64249,1,0),
(8,64250,1,0),
(8,64251,1,0),
(8,64252,1,0),
(8,64253,1,0),
(8,64254,1,0),
(8,64255,1,0),
(8,64256,1,0),
(8,64257,1,0),
(8,64258,1,0),
(8,64259,1,0),
(8,64260,1,0),
(8,64261,1,0),
(8,64262,1,0),
(8,64266,1,0),
(8,64267,1,0),
(8,64268,1,0),
(8,64270,1,0),
(8,64271,1,0),
(8,64273,1,0),
(8,64274,1,0),
(8,64275,1,0),
(8,64276,1,0),
(8,64277,1,0),
(8,64278,1,0),
(8,64279,1,0),
(8,64280,1,0),
(8,64281,1,0),
(8,64282,1,0),
(8,64283,1,0),
(8,64284,1,0),
(8,64285,1,0),
(8,64286,1,0),
(8,64287,1,0),
(8,64288,1,0),
(8,64289,1,0),
(8,64291,1,0),
(8,64294,1,0),
(8,64295,1,0),
(8,64296,1,0),
(8,64297,1,0),
(8,64298,1,0),
(8,64299,1,0),
(8,64300,1,0),
(8,64302,1,0),
(8,64303,1,0),
(8,64304,1,0),
(8,64305,1,0),
(8,64307,1,0),
(8,64308,1,0),
(8,64309,1,0),
(8,64310,1,0),
(8,64311,1,0),
(8,64312,1,0),
(8,64313,1,0),
(8,64314,1,0),
(8,64315,1,0),
(8,64316,1,0),
(8,64317,1,0),
(8,64318,1,0),
(8,64358,1,0),
(8,64441,1,0),
(8,64579,1,0),
(8,64661,1,0),
(8,64725,1,0),
(8,64726,1,0),
(8,64727,1,0),
(8,64728,1,0),
(8,64729,1,0),
(8,64730,1,0),
(8,65245,1,0),
(8,65454,1,0),
(8,66034,1,0),
(8,66035,1,0),
(8,66036,1,0),
(8,66037,1,0),
(8,66038,1,0),
(8,66338,1,0),
(8,66428,1,0),
(8,66429,1,0),
(8,66430,1,0),
(8,66431,1,0),
(8,66432,1,0),
(8,66433,1,0),
(8,66434,1,0),
(8,66435,1,0),
(8,66436,1,0),
(8,66437,1,0),
(8,66438,1,0),
(8,66439,1,0),
(8,66440,1,0),
(8,66441,1,0),
(8,66442,1,0),
(8,66443,1,0),
(8,66444,1,0),
(8,66445,1,0),
(8,66446,1,0),
(8,66447,1,0),
(8,66448,1,0),
(8,66449,1,0),
(8,66450,1,0),
(8,66451,1,0),
(8,66452,1,0),
(8,66453,1,0),
(8,66497,1,0),
(8,66498,1,0),
(8,66499,1,0),
(8,66500,1,0),
(8,66501,1,0),
(8,66502,1,0),
(8,66503,1,0),
(8,66504,1,0),
(8,66505,1,0),
(8,66506,1,0),
(8,66553,1,0),
(8,66554,1,0),
(8,66555,1,0),
(8,66556,1,0),
(8,66557,1,0),
(8,66558,1,0),
(8,66559,1,0),
(8,66560,1,0),
(8,66561,1,0),
(8,66562,1,0),
(8,66563,1,0),
(8,66564,1,0),
(8,66565,1,0),
(8,66566,1,0),
(8,66567,1,0),
(8,66568,1,0),
(8,66569,1,0),
(8,66570,1,0),
(8,66571,1,0),
(8,66572,1,0),
(8,66573,1,0),
(8,66574,1,0),
(8,66575,1,0),
(8,66576,1,0),
(8,66577,1,0),
(8,66578,1,0),
(8,66579,1,0),
(8,66580,1,0),
(8,66581,1,0),
(8,66582,1,0),
(8,66583,1,0),
(8,66584,1,0),
(8,66585,1,0),
(8,66586,1,0),
(8,66587,1,0),
(8,66658,1,0),
(8,66659,1,0),
(8,66660,1,0),
(8,66662,1,0),
(8,66663,1,0),
(8,66664,1,0),
(8,67025,1,0),
(8,67064,1,0),
(8,67065,1,0),
(8,67066,1,0),
(8,67079,1,0),
(8,67080,1,0),
(8,67081,1,0),
(8,67082,1,0),
(8,67083,1,0),
(8,67084,1,0),
(8,67085,1,0),
(8,67086,1,0),
(8,67087,1,0),
(8,67091,1,0),
(8,67092,1,0),
(8,67093,1,0),
(8,67094,1,0),
(8,67095,1,0),
(8,67096,1,0),
(8,67130,1,0),
(8,67131,1,0),
(8,67132,1,0),
(8,67133,1,0),
(8,67134,1,0),
(8,67135,1,0),
(8,67136,1,0),
(8,67137,1,0),
(8,67138,1,0),
(8,67139,1,0),
(8,67140,1,0),
(8,67141,1,0),
(8,67142,1,0),
(8,67143,1,0),
(8,67144,1,0),
(8,67145,1,0),
(8,67146,1,0),
(8,67147,1,0),
(8,67326,1,0),
(8,67600,1,0),
(8,67790,1,0),
(8,67839,1,0),
(8,67920,1,0),
(8,68067,1,0),
(8,68166,1,0),
(8,68253,1,0),
(8,69385,1,0),
(8,69386,1,0),
(8,69388,1,0),
(8,69412,1,0),
(8,70550,1,0),
(8,70551,1,0),
(8,70552,1,0),
(8,70553,1,0),
(8,70554,1,0),
(8,70555,1,0),
(8,70556,1,0),
(8,70557,1,0),
(8,70558,1,0),
(8,70559,1,0),
(8,70560,1,0),
(8,70561,1,0),
(8,70562,1,0),
(8,70563,1,0),
(8,70565,1,0),
(8,70566,1,0),
(8,70567,1,0),
(8,70568,1,0),
(8,71015,1,0),
(8,71101,1,0),
(8,71102,1,0),
(8,71692,1,0),
(8,72952,1,0),
(8,72953,1,0),
(8,75597,1,0);

/*Table structure for table `character_spell_cooldown` */

DROP TABLE IF EXISTS `character_spell_cooldown`;

CREATE TABLE `character_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_spell_cooldown` */

/*Table structure for table `character_stats` */

DROP TABLE IF EXISTS `character_stats`;

CREATE TABLE `character_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower1` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower2` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower3` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower4` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower5` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower6` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower7` int(10) unsigned NOT NULL DEFAULT '0',
  `strength` int(10) unsigned NOT NULL DEFAULT '0',
  `agility` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina` int(10) unsigned NOT NULL DEFAULT '0',
  `intellect` int(10) unsigned NOT NULL DEFAULT '0',
  `spirit` int(10) unsigned NOT NULL DEFAULT '0',
  `armor` int(10) unsigned NOT NULL DEFAULT '0',
  `resHoly` int(10) unsigned NOT NULL DEFAULT '0',
  `resFire` int(10) unsigned NOT NULL DEFAULT '0',
  `resNature` int(10) unsigned NOT NULL DEFAULT '0',
  `resFrost` int(10) unsigned NOT NULL DEFAULT '0',
  `resShadow` int(10) unsigned NOT NULL DEFAULT '0',
  `resArcane` int(10) unsigned NOT NULL DEFAULT '0',
  `blockPct` float unsigned NOT NULL DEFAULT '0',
  `dodgePct` float unsigned NOT NULL DEFAULT '0',
  `parryPct` float unsigned NOT NULL DEFAULT '0',
  `critPct` float unsigned NOT NULL DEFAULT '0',
  `rangedCritPct` float unsigned NOT NULL DEFAULT '0',
  `spellCritPct` float unsigned NOT NULL DEFAULT '0',
  `attackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `rangedAttackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `spellPower` int(10) unsigned NOT NULL DEFAULT '0',
  `resilience` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_stats` */

/*Table structure for table `character_talent` */

DROP TABLE IF EXISTS `character_talent`;

CREATE TABLE `character_talent` (
  `guid` int(10) unsigned NOT NULL,
  `spell` mediumint(8) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `character_talent` */

insert  into `character_talent`(`guid`,`spell`,`talentGroup`) values 
(2,5570,0),
(2,16818,0),
(2,16820,0),
(2,16822,0),
(2,16835,0),
(2,16840,0),
(2,16847,0),
(2,16862,0),
(2,16864,0),
(2,16899,0),
(2,16913,0),
(2,16924,0),
(2,16931,0),
(2,16938,0),
(2,16941,0),
(2,16944,0),
(2,16949,0),
(2,16968,0),
(2,16975,0),
(2,16999,0),
(2,17007,0),
(2,17051,0),
(2,17061,0),
(2,17066,0),
(2,17073,0),
(2,17078,0),
(2,17108,0),
(2,17113,0),
(2,17116,0),
(2,17120,0),
(2,17124,0),
(2,18562,0),
(2,24858,0),
(2,24866,0),
(2,24894,0),
(2,24946,0),
(2,24972,0),
(2,33591,0),
(2,33596,0),
(2,33602,0),
(2,33607,0),
(2,33831,0),
(2,33856,0),
(2,33867,0),
(2,33873,0),
(2,33880,0),
(2,33883,0),
(2,33890,0),
(2,33917,0),
(2,33956,0),
(2,33957,0),
(2,34153,0),
(2,34300,0),
(2,35364,0),
(2,37117,0),
(2,48393,0),
(2,48396,0),
(2,48410,0),
(2,48412,0),
(2,48438,0),
(2,48485,0),
(2,48491,0),
(2,48495,0),
(2,48500,0),
(2,48505,0),
(2,48511,0),
(2,48514,0),
(2,48525,0),
(2,48537,0),
(2,48545,0),
(2,49377,0),
(2,50334,0),
(2,50516,0),
(2,51183,0),
(2,51269,0),
(2,57814,0),
(2,57851,0),
(2,57865,0),
(2,57877,0),
(2,57881,0),
(2,61336,0),
(2,61346,0),
(2,63411,0),
(2,63503,0),
(2,65139,0),
(5,10060,0),
(5,14751,0),
(5,14767,0),
(5,14769,0),
(5,14771,0),
(5,14772,0),
(5,14774,0),
(5,14777,0),
(5,14781,0),
(5,14785,0),
(5,14788,0),
(5,18555,0),
(5,33172,0),
(5,33190,0),
(5,33202,0),
(5,33206,0),
(5,34910,0),
(5,45244,0),
(5,47508,0),
(5,47515,0),
(5,47517,0),
(5,47537,0),
(5,47540,0),
(5,52800,0),
(5,52803,0),
(5,57472,0),
(5,63506,0),
(5,63574,0);

/*Table structure for table `characters` */

DROP TABLE IF EXISTS `characters`;

CREATE TABLE `characters` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `account` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xp` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `skin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `face` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `facialStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bankSlots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `restState` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `playerFlags` int(10) unsigned NOT NULL DEFAULT '0',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `instance_id` int(10) unsigned NOT NULL DEFAULT '0',
  `instance_mode_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `taximask` text NOT NULL,
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cinematic` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  `leveltime` int(10) unsigned NOT NULL DEFAULT '0',
  `logout_time` int(10) unsigned NOT NULL DEFAULT '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rest_bonus` float NOT NULL DEFAULT '0',
  `resettalents_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` int(10) unsigned NOT NULL DEFAULT '0',
  `trans_x` float NOT NULL DEFAULT '0',
  `trans_y` float NOT NULL DEFAULT '0',
  `trans_z` float NOT NULL DEFAULT '0',
  `trans_o` float NOT NULL DEFAULT '0',
  `transguid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `extra_flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stable_slots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `at_login` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zone` smallint(5) unsigned NOT NULL DEFAULT '0',
  `death_expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `todayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalKills` int(10) unsigned NOT NULL DEFAULT '0',
  `todayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `chosenTitle` int(10) unsigned NOT NULL DEFAULT '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL DEFAULT '0',
  `watchedFaction` int(10) unsigned NOT NULL DEFAULT '0',
  `drunk` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `health` int(10) unsigned NOT NULL DEFAULT '0',
  `power1` int(10) unsigned NOT NULL DEFAULT '0',
  `power2` int(10) unsigned NOT NULL DEFAULT '0',
  `power3` int(10) unsigned NOT NULL DEFAULT '0',
  `power4` int(10) unsigned NOT NULL DEFAULT '0',
  `power5` int(10) unsigned NOT NULL DEFAULT '0',
  `power6` int(10) unsigned NOT NULL DEFAULT '0',
  `power7` int(10) unsigned NOT NULL DEFAULT '0',
  `latency` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `talentGroupsCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `activeTalentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL DEFAULT '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grantableLevels` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleteInfos_Account` int(10) unsigned DEFAULT NULL,
  `deleteInfos_Name` varchar(12) DEFAULT NULL,
  `deleteDate` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `characters` */

insert  into `characters`(`guid`,`account`,`name`,`race`,`class`,`gender`,`level`,`xp`,`money`,`skin`,`face`,`hairStyle`,`hairColor`,`facialStyle`,`bankSlots`,`restState`,`playerFlags`,`position_x`,`position_y`,`position_z`,`map`,`instance_id`,`instance_mode_mask`,`orientation`,`taximask`,`online`,`cinematic`,`totaltime`,`leveltime`,`logout_time`,`is_logout_resting`,`rest_bonus`,`resettalents_cost`,`resettalents_time`,`trans_x`,`trans_y`,`trans_z`,`trans_o`,`transguid`,`extra_flags`,`stable_slots`,`at_login`,`zone`,`death_expire_time`,`taxi_path`,`arenaPoints`,`totalHonorPoints`,`todayHonorPoints`,`yesterdayHonorPoints`,`totalKills`,`todayKills`,`yesterdayKills`,`chosenTitle`,`knownCurrencies`,`watchedFaction`,`drunk`,`health`,`power1`,`power2`,`power3`,`power4`,`power5`,`power6`,`power7`,`latency`,`talentGroupsCount`,`activeTalentGroup`,`exploredZones`,`equipmentCache`,`ammoId`,`knownTitles`,`actionBars`,`grantableLevels`,`deleteInfos_Account`,`deleteInfos_Name`,`deleteDate`) values 
(1,1,'Ruffomaker',1,8,0,255,0,9536927,1,7,15,9,6,0,2,34,-4826.2,-981.548,464.709,0,0,0,0.748119,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,72785,27487,1502327272,1,0,0,0,0,0,0,0,0,256,0,0,1537,1502323912,'',0,0,0,0,0,0,0,0,67108864,4294967295,0,9133,3303,0,0,100,0,0,0,0,1,0,'0 0 0 3766484992 0 0 524288 0 1073743872 0 0 0 0 0 1 0 0 1074401296 0 4194816 0 196616 8 0 134217728 0 0 0 0 25165824 4194304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 33554432 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 2097152 536871050 32 269484032 16 36872 0 0 262656 4194304 2080 0 0 0 2 0 33554432 0 16777216 67108864 0 0 0 0 0 1073774624 0 0 268435456 0 0 0 0 134746144 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 17 0 2586 0 0 0 1395 0 11508 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 192 0 0 0 0 0 0 0 23162 0 23162 0 23162 0 23162 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),
(2,3,'Canario',6,11,0,85,0,1125304973,0,1,7,0,3,0,2,8,16234.2,16312.3,30.8255,1,0,0,0.326246,'2097152 0 0 4 0 0 1048576 0 0 0 0 0 0 0 ',0,1,3146,2953,1502214661,0,0,0,0,0,0,0,0,0,1,0,0,876,1501973598,'',0,0,0,0,0,0,0,0,0,4294967295,0,9377,7101,0,0,100,0,0,0,59,1,0,'0 0 0 0 0 0 0 0 262144 0 0 0 0 0 0 0 0 0 0 0 0 8 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 33554432 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 8388608 2392072 0 0 262656 2151677952 2048 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','12064 0 0 0 0 0 0 0 2586 0 0 0 6124 0 11508 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 29981 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),
(3,4,'Dkdrian',1,2,0,3,331,0,2,9,13,0,4,0,2,32786,16226.8,16261.6,13.3324,1,0,0,1.38897,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 ',0,1,10744,2378,1502319316,0,0.0000305176,0,0,0,0,0,0,0,0,0,256,876,1502319116,'',0,0,0,0,0,0,0,0,0,4294967295,0,1,0,0,0,100,0,0,0,213,1,0,'0 0 0 1610612736 0 0 0 0 0 0 0 0 0 0 0 0 0 16 0 0 0 65544 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 8388608 32776 0 0 262656 4194304 256 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 45 0 0 0 0 0 44 0 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2361 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',3,0,NULL,NULL,NULL),
(4,5,'Rasky',3,1,0,1,255,0,5,9,5,4,5,0,1,34,-4826.3,-974.524,464.709,0,0,0,5.57254,'32 0 0 8 0 0 0 0 0 0 0 0 0 0 ',0,1,47411,47411,1502328987,1,58.7817,0,0,0,0,0,0,0,0,0,0,1537,1502321144,'',0,0,0,0,0,0,0,0,0,4294967295,0,90,0,0,0,100,0,0,0,35,1,0,'0 0 0 1082130432 0 0 1572864 33554432 0 0 0 0 0 0 0 0 0 4096 0 512 0 131080 0 0 0 64 0 0 0 25165824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 268435456 0 8 0 0 0 4194304 0 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12282 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),
(5,2,'Eva',10,5,1,80,252380086,100000000,2,8,7,5,9,0,2,42,2022.01,-4671.77,25.0665,1,0,0,1.97837,'0 0 131072 4 0 0 1048576 0 0 0 0 0 0 0 ',0,1,8744,8658,1502158999,1,0,0,0,0,0,0,0,0,33,0,0,1637,1502157697,'',0,0,0,0,0,0,0,0,0,4294967295,0,9690,1410065407,0,0,100,0,0,0,204,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65544 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16384 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 0 36864 0 0 262144 2151677952 2336 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','39521 0 0 0 17047 0 0 0 14175 0 16696 0 4044 0 28663 0 0 0 0 0 12947 0 0 0 0 0 0 0 29354 0 0 0 40350 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),
(6,6,'Lorder',1,2,0,80,0,546191396,1,1,15,6,0,0,2,0,16228.2,16296.2,30.3876,1,0,0,4.66537,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,3773,2487,1502213890,0,0,0,0,0,0,0,0,0,0,0,1,876,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,13054,5584,0,0,100,0,0,0,0,1,0,'0 0 0 536870912 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65544 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','30987 0 0 0 30998 0 45 0 30991 0 34488 0 30995 0 34560 0 34433 0 30985 0 0 0 0 0 0 0 0 0 0 0 2361 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),
(8,7,'Tynoprox',2,1,0,1,0,0,4,3,3,6,0,0,2,8,16231.5,16298.8,29.2621,1,0,0,4.41873,'4194304 0 0 4 0 0 0 0 0 0 0 0 0 0 ',0,1,860,860,1502214242,0,0.0184278,0,0,0,0,0,0,0,37,0,0,876,1502214111,'',0,0,0,0,0,0,0,0,0,4294967295,0,80,0,0,0,100,0,0,0,221,1,0,'0 0 33554432 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6125 0 0 0 0 0 139 0 140 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12282 197525504 0 0 0 0 0 0 23162 0 23162 0 23162 0 23162 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL);

/*Table structure for table `corpse` */

DROP TABLE IF EXISTS `corpse`;

CREATE TABLE `corpse` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `phaseMask` int(10) unsigned NOT NULL DEFAULT '1',
  `displayId` int(10) unsigned NOT NULL DEFAULT '0',
  `itemCache` text NOT NULL,
  `bytes1` int(10) unsigned NOT NULL DEFAULT '0',
  `bytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `guildId` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dynFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `corpseType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`),
  KEY `idx_type` (`corpseType`),
  KEY `idx_instance` (`instanceId`),
  KEY `idx_time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Death System';

/*Data for the table `corpse` */

/*Table structure for table `creature_respawn` */

DROP TABLE IF EXISTS `creature_respawn`;

CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';

/*Data for the table `creature_respawn` */

insert  into `creature_respawn`(`guid`,`respawnTime`,`mapId`,`instanceId`) values 
(3643,1502322101,0,0),
(12402,1501974740,571,0),
(44457,1502328330,571,0),
(79936,1502317130,0,0),
(79937,1502317137,0,0),
(79938,1502316935,0,0),
(79944,1502317053,0,0),
(79945,1502316898,0,0),
(79946,1502316951,0,0),
(79947,1502317049,0,0),
(79961,1502316922,0,0),
(79972,1502316811,0,0),
(79980,1502153550,0,0),
(79984,1502153545,0,0),
(79985,1502153579,0,0),
(79991,1502316770,0,0),
(80128,1502209141,0,0),
(80140,1502317124,0,0),
(80141,1502317118,0,0),
(80142,1502317112,0,0),
(80143,1502316994,0,0),
(80144,1502317130,0,0),
(80156,1502317070,0,0),
(80157,1502317035,0,0),
(80164,1502317082,0,0),
(80165,1502316842,0,0),
(80176,1502316896,0,0),
(80261,1502316867,0,0),
(80297,1501941061,0,0),
(80308,1502317415,0,0),
(80761,1502293340,0,0),
(96163,1502154253,571,0),
(102063,1501974791,571,0),
(102123,1501975111,571,0),
(102313,1501974299,571,0),
(103579,1501975174,571,0),
(107997,1501947984,571,0),
(108016,1502063037,571,0),
(112317,1501951697,571,0),
(115700,1501947827,571,0),
(118064,1502326055,571,0),
(146139,1502317409,0,0),
(146141,1502317448,0,0),
(213830,1502156719,1,0),
(213876,1502327817,0,0),
(213880,1502328132,0,0);

/*Table structure for table `game_event_condition_save` */

DROP TABLE IF EXISTS `game_event_condition_save`;

CREATE TABLE `game_event_condition_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `condition_id` int(10) unsigned NOT NULL DEFAULT '0',
  `done` float DEFAULT '0',
  PRIMARY KEY (`eventEntry`,`condition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `game_event_condition_save` */

/*Table structure for table `game_event_save` */

DROP TABLE IF EXISTS `game_event_save`;

CREATE TABLE `game_event_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `state` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `next_start` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventEntry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `game_event_save` */

/*Table structure for table `gameobject_respawn` */

DROP TABLE IF EXISTS `gameobject_respawn`;

CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';

/*Data for the table `gameobject_respawn` */

/*Table structure for table `gm_subsurvey` */

DROP TABLE IF EXISTS `gm_subsurvey`;

CREATE TABLE `gm_subsurvey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionId` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `answerComment` text NOT NULL,
  PRIMARY KEY (`surveyId`,`questionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `gm_subsurvey` */

/*Table structure for table `gm_survey` */

DROP TABLE IF EXISTS `gm_survey`;

CREATE TABLE `gm_survey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `mainSurvey` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` longtext NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`surveyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `gm_survey` */

/*Table structure for table `gm_ticket` */

DROP TABLE IF EXISTS `gm_ticket`;

CREATE TABLE `gm_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 open, 1 closed, 2 character deleted',
  `playerGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier of ticket creator',
  `name` varchar(12) NOT NULL COMMENT 'Name of ticket creator',
  `description` text NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `lastModifiedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `closedBy` int(10) NOT NULL DEFAULT '0',
  `assignedTo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'GUID of admin to whom ticket is assigned',
  `comment` text NOT NULL,
  `response` text NOT NULL,
  `completed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `escalated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `needMoreHelp` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resolvedBy` int(10) NOT NULL DEFAULT '0' COMMENT 'GUID of GM who resolved the ticket',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `gm_ticket` */

/*Table structure for table `group_instance` */

DROP TABLE IF EXISTS `group_instance`;

CREATE TABLE `group_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `group_instance` */

/*Table structure for table `group_member` */

DROP TABLE IF EXISTS `group_member`;

CREATE TABLE `group_member` (
  `guid` int(10) unsigned NOT NULL,
  `memberGuid` int(10) unsigned NOT NULL,
  `memberFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subgroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `roles` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`memberGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';

/*Data for the table `group_member` */

/*Table structure for table `groups` */

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `guid` int(10) unsigned NOT NULL,
  `leaderGuid` int(10) unsigned NOT NULL,
  `lootMethod` tinyint(3) unsigned NOT NULL,
  `looterGuid` int(10) unsigned NOT NULL,
  `lootThreshold` tinyint(3) unsigned NOT NULL,
  `icon1` bigint(20) unsigned NOT NULL,
  `icon2` bigint(20) unsigned NOT NULL,
  `icon3` bigint(20) unsigned NOT NULL,
  `icon4` bigint(20) unsigned NOT NULL,
  `icon5` bigint(20) unsigned NOT NULL,
  `icon6` bigint(20) unsigned NOT NULL,
  `icon7` bigint(20) unsigned NOT NULL,
  `icon8` bigint(20) unsigned NOT NULL,
  `groupType` tinyint(3) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `raidDifficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `masterLooterGuid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guid`),
  KEY `leaderGuid` (`leaderGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';

/*Data for the table `groups` */

/*Table structure for table `guild` */

DROP TABLE IF EXISTS `guild`;

CREATE TABLE `guild` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `leaderguid` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `EmblemColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BackgroundColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL DEFAULT '',
  `motd` varchar(128) NOT NULL DEFAULT '',
  `createdate` int(10) unsigned NOT NULL DEFAULT '0',
  `BankMoney` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

/*Data for the table `guild` */

/*Table structure for table `guild_bank_eventlog` */

DROP TABLE IF EXISTS `guild_bank_eventlog`;

CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Event type',
  `PlayerGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemOrMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemStackCount` smallint(5) unsigned NOT NULL DEFAULT '0',
  `DestTabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Destination Tab Id',
  `TimeStamp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `guild_bank_eventlog` */

/*Table structure for table `guild_bank_item` */

DROP TABLE IF EXISTS `guild_bank_item`;

CREATE TABLE `guild_bank_item` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `guild_bank_item` */

/*Table structure for table `guild_bank_right` */

DROP TABLE IF EXISTS `guild_bank_right`;

CREATE TABLE `guild_bank_right` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gbright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `guild_bank_right` */

/*Table structure for table `guild_bank_tab` */

DROP TABLE IF EXISTS `guild_bank_tab`;

CREATE TABLE `guild_bank_tab` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `TabName` varchar(16) NOT NULL DEFAULT '',
  `TabIcon` varchar(100) NOT NULL DEFAULT '',
  `TabText` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `guild_bank_tab` */

/*Table structure for table `guild_eventlog` */

DROP TABLE IF EXISTS `guild_eventlog`;

CREATE TABLE `guild_eventlog` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(3) unsigned NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(10) unsigned NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(10) unsigned NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(3) unsigned NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` int(10) unsigned NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';

/*Data for the table `guild_eventlog` */

insert  into `guild_eventlog`(`guildid`,`LogGuid`,`EventType`,`PlayerGuid1`,`PlayerGuid2`,`NewRank`,`TimeStamp`) values 
(1,0,2,1,0,0,1502139555),
(1,1,2,4,0,0,1502139591),
(2,0,2,1,0,0,1501904259);

/*Table structure for table `guild_member` */

DROP TABLE IF EXISTS `guild_member`;

CREATE TABLE `guild_member` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `guid` int(10) unsigned NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  `pnote` varchar(31) NOT NULL DEFAULT '',
  `offnote` varchar(31) NOT NULL DEFAULT '',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

/*Data for the table `guild_member` */

insert  into `guild_member`(`guildid`,`guid`,`rank`,`pnote`,`offnote`) values 
(1,4,4,'','');

/*Table structure for table `guild_member_withdraw` */

DROP TABLE IF EXISTS `guild_member_withdraw`;

CREATE TABLE `guild_member_withdraw` (
  `guid` int(10) unsigned NOT NULL,
  `tab0` int(10) unsigned NOT NULL DEFAULT '0',
  `tab1` int(10) unsigned NOT NULL DEFAULT '0',
  `tab2` int(10) unsigned NOT NULL DEFAULT '0',
  `tab3` int(10) unsigned NOT NULL DEFAULT '0',
  `tab4` int(10) unsigned NOT NULL DEFAULT '0',
  `tab5` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Member Daily Withdraws';

/*Data for the table `guild_member_withdraw` */

/*Table structure for table `guild_rank` */

DROP TABLE IF EXISTS `guild_rank`;

CREATE TABLE `guild_rank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL,
  `rname` varchar(20) NOT NULL DEFAULT '',
  `rights` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `BankMoneyPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

/*Data for the table `guild_rank` */

/*Table structure for table `instance` */

DROP TABLE IF EXISTS `instance`;

CREATE TABLE `instance` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `completedEncounters` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `instance` */

/*Table structure for table `instance_reset` */

DROP TABLE IF EXISTS `instance_reset`;

CREATE TABLE `instance_reset` (
  `mapid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mapid`,`difficulty`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `instance_reset` */

insert  into `instance_reset`(`mapid`,`difficulty`,`resettime`) values 
(249,0,1502510400),
(249,1,1502510400),
(269,1,1502424000),
(309,0,1502424000),
(409,0,1502510400),
(469,0,1502510400),
(509,0,1502424000),
(531,0,1502510400),
(532,0,1502510400),
(533,0,1502510400),
(533,1,1502510400),
(534,0,1502510400),
(540,1,1502424000),
(542,1,1502424000),
(543,1,1502424000),
(544,0,1502510400),
(545,1,1502424000),
(546,1,1502424000),
(547,1,1502424000),
(548,0,1502510400),
(550,0,1502510400),
(552,1,1502424000),
(553,1,1502424000),
(554,1,1502424000),
(555,1,1502424000),
(556,1,1502424000),
(557,1,1502424000),
(558,1,1502424000),
(560,1,1502424000),
(564,0,1502510400),
(565,0,1502510400),
(568,0,1502424000),
(574,1,1502424000),
(575,1,1502424000),
(576,1,1502424000),
(578,1,1502424000),
(580,0,1502510400),
(585,1,1502424000),
(595,1,1502424000),
(598,1,1502424000),
(599,1,1502424000),
(600,1,1502424000),
(601,1,1502424000),
(602,1,1502424000),
(603,0,1502510400),
(603,1,1502510400),
(604,1,1502424000),
(608,1,1502424000),
(615,0,1502510400),
(615,1,1502510400),
(616,0,1502510400),
(616,1,1502510400),
(619,1,1502424000),
(624,0,1502510400),
(624,1,1502510400),
(631,0,1502510400),
(631,1,1502510400),
(631,2,1502510400),
(631,3,1502510400),
(632,1,1502424000),
(649,0,1502510400),
(649,1,1502510400),
(649,2,1502510400),
(649,3,1502510400),
(650,1,1502424000),
(658,1,1502424000),
(668,1,1502424000),
(724,0,1502510400),
(724,1,1502510400),
(724,2,1502510400),
(724,3,1502510400);

/*Table structure for table `item_instance` */

DROP TABLE IF EXISTS `item_instance`;

CREATE TABLE `item_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemEntry` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `creatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `giftCreatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0',
  `charges` tinytext,
  `flags` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enchantments` text NOT NULL,
  `randomPropertyId` smallint(5) NOT NULL DEFAULT '0',
  `durability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text,
  PRIMARY KEY (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item System';

/*Data for the table `item_instance` */

insert  into `item_instance`(`guid`,`itemEntry`,`owner_guid`,`creatorGuid`,`giftCreatorGuid`,`count`,`duration`,`charges`,`flags`,`enchantments`,`randomPropertyId`,`durability`,`playedTime`,`text`) values 
(2,56,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),
(4,1395,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,13,0,''),
(6,55,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(8,35,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(10,6096,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(12,6948,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(18,6124,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(20,6948,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(21,41426,1,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(27,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(28,2586,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),
(30,12064,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),
(31,11508,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),
(32,2586,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,17,0,''),
(33,12064,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),
(34,11508,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,9,0,''),
(37,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(39,29981,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,665,''),
(40,13246,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,81,0,''),
(41,44817,2,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(42,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(44,45,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(46,43,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(48,44,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,17,0,''),
(50,6948,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(52,2361,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,17,0,''),
(54,38,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(56,39,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),
(58,40,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(60,12282,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),
(62,6948,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(64,54343,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(66,34498,2,0,0,1,0,'-4 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(71,44606,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(72,45057,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(76,20891,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),
(78,53,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(80,52,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(82,20978,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(84,51,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(86,6948,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(87,46882,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(88,18486,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,80,0,''),
(89,22515,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),
(90,39521,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),
(91,40350,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,1922,''),
(92,45607,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),
(93,14175,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 0 0 0 0 0 0 0 0 ',153,65,0,''),
(94,29354,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(95,28663,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),
(96,4044,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),
(97,18608,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),
(98,35514,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),
(99,17047,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),
(100,13404,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),
(101,16696,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),
(102,12947,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(104,45,6,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(106,43,6,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(108,44,6,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(110,6948,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(112,2361,6,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(113,30991,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,0,''),
(114,41426,6,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(115,30987,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),
(116,30985,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),
(117,30995,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,1,''),
(118,30998,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),
(119,34488,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),
(120,34433,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),
(121,34560,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),
(133,6125,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(135,139,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(137,140,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(139,6948,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(141,12282,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 3014 1390611 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),
(142,23162,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(143,23162,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(144,23162,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(145,23162,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(146,23162,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(147,23162,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(148,23162,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(149,23162,6,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(150,51541,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,0,''),
(151,51542,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,1,''),
(152,51543,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),
(153,51544,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),
(154,51545,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,1,''),
(155,17,1,0,0,1,0,'100 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(156,192,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(157,23162,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(158,23162,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(159,23162,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(160,23162,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(161,46106,1,1,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(162,47241,1,0,0,14,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,1,''),
(164,49801,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),
(165,49806,1,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),
(171,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(172,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(173,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(174,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(175,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(176,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(177,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(178,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(179,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(180,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(181,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(182,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(183,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(184,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(185,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(186,44817,1,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(187,7073,3,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),
(188,4865,3,0,0,3,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,'');

/*Table structure for table `item_loot_items` */

DROP TABLE IF EXISTS `item_loot_items`;

CREATE TABLE `item_loot_items` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'loot item entry (item_instance.itemEntry)',
  `item_count` int(10) NOT NULL DEFAULT '0' COMMENT 'stack size',
  `follow_rules` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'follow loot rules',
  `ffa` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'free-for-all',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `counted` tinyint(1) NOT NULL DEFAULT '0',
  `under_threshold` tinyint(1) NOT NULL DEFAULT '0',
  `needs_quest` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'quest drop',
  `rnd_prop` int(10) NOT NULL DEFAULT '0' COMMENT 'random enchantment added when originally rolled',
  `rnd_suffix` int(10) NOT NULL DEFAULT '0' COMMENT 'random suffix added when originally rolled'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `item_loot_items` */

/*Table structure for table `item_loot_money` */

DROP TABLE IF EXISTS `item_loot_money`;

CREATE TABLE `item_loot_money` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'money loot (in copper)',
  PRIMARY KEY (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `item_loot_money` */

/*Table structure for table `item_refund_instance` */

DROP TABLE IF EXISTS `item_refund_instance`;

CREATE TABLE `item_refund_instance` (
  `item_guid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `player_guid` int(10) unsigned NOT NULL COMMENT 'Player GUID',
  `paidMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `paidExtendedCost` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`,`player_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';

/*Data for the table `item_refund_instance` */

/*Table structure for table `item_soulbound_trade_data` */

DROP TABLE IF EXISTS `item_soulbound_trade_data`;

CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `allowedPlayers` text NOT NULL COMMENT 'Space separated GUID list of players who can receive this item in trade',
  PRIMARY KEY (`itemGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';

/*Data for the table `item_soulbound_trade_data` */

/*Table structure for table `lag_reports` */

DROP TABLE IF EXISTS `lag_reports`;

CREATE TABLE `lag_reports` (
  `reportId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `lagType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `latency` int(10) unsigned NOT NULL DEFAULT '0',
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`reportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

/*Data for the table `lag_reports` */

/*Table structure for table `lfg_data` */

DROP TABLE IF EXISTS `lfg_data`;

CREATE TABLE `lfg_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `dungeon` int(10) unsigned NOT NULL DEFAULT '0',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='LFG Data';

/*Data for the table `lfg_data` */

/*Table structure for table `mail` */

DROP TABLE IF EXISTS `mail`;

CREATE TABLE `mail` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stationery` tinyint(3) NOT NULL DEFAULT '41',
  `mailTemplateId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `deliver_time` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `cod` int(10) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Mail System';

/*Data for the table `mail` */

insert  into `mail`(`id`,`messageType`,`stationery`,`mailTemplateId`,`sender`,`receiver`,`subject`,`body`,`has_items`,`expire_time`,`deliver_time`,`money`,`cod`,`checked`) values 
(1,3,41,0,16128,1,'Level 80','Congratulations on your conviction to reach the 80th season of adventure. You are undoubtedly dedicated to the cause of ridding Azeroth of the evils which have plagued us.$B$BAnd while the journey thus far has been no minor feat, the true battle lies ahead.$B$BFight on!$B$BRhonin',1,1504494471,1501902471,0,0,0),
(2,3,41,0,16128,2,'Level 80','Congratulations on your conviction to reach the 80th season of adventure. You are undoubtedly dedicated to the cause of ridding Azeroth of the evils which have plagued us.$B$BAnd while the journey thus far has been no minor feat, the true battle lies ahead.$B$BFight on!$B$BRhonin',0,1504494537,1501902537,0,0,1),
(3,3,41,264,32838,1,'','',1,1504495406,1501903406,0,0,0),
(4,3,41,264,32838,2,'','',0,1504495323,1501903323,0,0,1),
(5,3,41,264,32838,1,'','',1,1504496028,1501904028,0,0,0),
(6,3,41,264,32838,2,'','',0,1504496236,1501904236,0,0,1),
(7,3,41,264,32838,1,'','',1,1504533115,1501941115,0,0,0),
(8,3,41,232,16280,5,'','',1,1504723480,1502131480,0,0,0),
(9,3,41,272,16280,5,'','',0,1504723480,1502131480,0,0,0),
(10,3,41,282,35093,5,'','',0,1504723480,1502131480,0,0,0),
(11,3,41,285,35135,5,'','',0,1504723480,1502131480,0,0,0),
(12,3,41,265,33817,5,'','',0,1504723480,1502131480,0,0,0),
(13,3,41,0,16128,6,'Level 80','Congratulations on your conviction to reach the 80th season of adventure. You are undoubtedly dedicated to the cause of ridding Azeroth of the evils which have plagued us.$B$BAnd while the journey thus far has been no minor feat, the true battle lies ahead.$B$BFight on!$B$BRhonin',1,1504803342,1502211342,0,0,0),
(14,3,41,0,37942,1,'Emblem Quartermasters in Dalaran\'s Silver Enclave','Your achievements in Northrend have not gone unnoticed, friend.$B$BThe Emblems you have earned may be used to purchase equipment from the various Emblem Quartermasters in Dalaran.$B$BYou may find us there, in the Silver Enclave, where each variety of Emblem has its own quartermaster.$B$BWe look forward to your arrival!',0,1504894436,1502302436,0,0,0),
(15,3,41,264,32838,1,'','',1,1504896424,1502304424,0,0,0),
(16,3,41,264,32838,1,'','',1,1504896632,1502304632,0,0,0),
(17,3,41,264,32838,1,'','',1,1504896568,1502304568,0,0,0),
(18,3,41,264,32838,1,'','',1,1504896519,1502304519,0,0,0),
(19,3,41,264,32838,1,'','',1,1504896517,1502304517,0,0,0),
(20,3,41,264,32838,1,'','',1,1504896400,1502304400,0,0,0),
(21,3,41,264,32838,1,'','',1,1504896919,1502304919,0,0,0),
(22,3,41,264,32838,1,'','',1,1504896923,1502304923,0,0,0),
(23,3,41,264,32838,1,'','',1,1504896500,1502304500,0,0,0),
(24,3,41,264,32838,1,'','',1,1504896676,1502304676,0,0,0),
(25,3,41,264,32838,1,'','',1,1504896673,1502304673,0,0,0),
(26,3,41,264,32838,1,'','',1,1504896916,1502304916,0,0,0),
(27,3,41,264,32838,1,'','',1,1504896706,1502304706,0,0,0),
(28,3,41,264,32838,1,'','',1,1504896790,1502304790,0,0,0),
(29,3,41,264,32838,1,'','',1,1504896796,1502304796,0,0,0),
(30,3,41,264,32838,1,'','',1,1504896542,1502304542,0,0,0);

/*Table structure for table `mail_items` */

DROP TABLE IF EXISTS `mail_items`;

CREATE TABLE `mail_items` (
  `mail_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY (`item_guid`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_mail_id` (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `mail_items` */

insert  into `mail_items`(`mail_id`,`item_guid`,`receiver`) values 
(1,21,1),
(3,27,1),
(5,37,1),
(7,42,1),
(8,87,5),
(13,114,6),
(15,171,1),
(16,172,1),
(17,173,1),
(18,174,1),
(19,175,1),
(20,176,1),
(21,177,1),
(22,178,1),
(23,179,1),
(24,180,1),
(25,181,1),
(26,182,1),
(27,183,1),
(28,184,1),
(29,185,1),
(30,186,1);

/*Table structure for table `pet_aura` */

DROP TABLE IF EXISTS `pet_aura`;

CREATE TABLE `pet_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` mediumint(8) NOT NULL,
  `amount1` mediumint(8) NOT NULL,
  `amount2` mediumint(8) NOT NULL,
  `base_amount0` mediumint(8) NOT NULL,
  `base_amount1` mediumint(8) NOT NULL,
  `base_amount2` mediumint(8) NOT NULL,
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

/*Data for the table `pet_aura` */

/*Table structure for table `pet_spell` */

DROP TABLE IF EXISTS `pet_spell`;

CREATE TABLE `pet_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

/*Data for the table `pet_spell` */

/*Table structure for table `pet_spell_cooldown` */

DROP TABLE IF EXISTS `pet_spell_cooldown`;

CREATE TABLE `pet_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `pet_spell_cooldown` */

/*Table structure for table `petition` */

DROP TABLE IF EXISTS `petition`;

CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

/*Data for the table `petition` */

/*Table structure for table `petition_sign` */

DROP TABLE IF EXISTS `petition_sign`;

CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned NOT NULL DEFAULT '0',
  `playerguid` int(10) unsigned NOT NULL DEFAULT '0',
  `player_account` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

/*Data for the table `petition_sign` */

/*Table structure for table `pool_quest_save` */

DROP TABLE IF EXISTS `pool_quest_save`;

CREATE TABLE `pool_quest_save` (
  `pool_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pool_id`,`quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `pool_quest_save` */

insert  into `pool_quest_save`(`pool_id`,`quest_id`) values 
(348,24635),
(349,14101),
(350,13904),
(351,13914),
(352,11380),
(353,11665),
(354,13424),
(356,11368),
(357,11387),
(359,12736),
(360,12762),
(361,12741),
(362,12703),
(363,14074),
(364,14076),
(365,14140),
(366,14145),
(367,14108),
(370,12501),
(5662,13675),
(5663,13764),
(5664,13769),
(5665,13775),
(5666,13779),
(5667,13785),
(5668,13669),
(5669,13616),
(5670,13742),
(5671,13747),
(5672,13758),
(5673,13754),
(5674,13102),
(5675,13115),
(5676,13830),
(5677,12960),
(5678,24583),
(5685,24870),
(5685,24871),
(5686,24879),
(5707,13198),
(5708,13156),
(5709,13201),
(5710,13194);

/*Table structure for table `pvpstats_battlegrounds` */

DROP TABLE IF EXISTS `pvpstats_battlegrounds`;

CREATE TABLE `pvpstats_battlegrounds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `winner_faction` tinyint(4) NOT NULL,
  `bracket_id` tinyint(3) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pvpstats_battlegrounds` */

/*Table structure for table `pvpstats_players` */

DROP TABLE IF EXISTS `pvpstats_players`;

CREATE TABLE `pvpstats_players` (
  `battleground_id` bigint(20) unsigned NOT NULL,
  `character_guid` int(10) unsigned NOT NULL,
  `winner` bit(1) NOT NULL,
  `score_killing_blows` mediumint(8) unsigned NOT NULL,
  `score_deaths` mediumint(8) unsigned NOT NULL,
  `score_honorable_kills` mediumint(8) unsigned NOT NULL,
  `score_bonus_honor` mediumint(8) unsigned NOT NULL,
  `score_damage_done` mediumint(8) unsigned NOT NULL,
  `score_healing_done` mediumint(8) unsigned NOT NULL,
  `attr_1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_3` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_4` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_5` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`battleground_id`,`character_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pvpstats_players` */

/*Table structure for table `quest_tracker` */

DROP TABLE IF EXISTS `quest_tracker`;

CREATE TABLE `quest_tracker` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `character_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_accept_time` datetime NOT NULL,
  `quest_complete_time` datetime DEFAULT NULL,
  `quest_abandon_time` datetime DEFAULT NULL,
  `completed_by_gm` tinyint(1) NOT NULL DEFAULT '0',
  `core_hash` varchar(120) NOT NULL DEFAULT '0',
  `core_revision` varchar(120) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `quest_tracker` */

/*Table structure for table `reserved_name` */

DROP TABLE IF EXISTS `reserved_name`;

CREATE TABLE `reserved_name` (
  `name` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player Reserved Names';

/*Data for the table `reserved_name` */

/*Table structure for table `updates` */

DROP TABLE IF EXISTS `updates`;

CREATE TABLE `updates` (
  `name` varchar(200) NOT NULL COMMENT 'filename with extension of the update.',
  `hash` char(40) DEFAULT '' COMMENT 'sha1 hash of the sql file.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if an update is released or archived.',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'timestamp when the query was applied.',
  `speed` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'time the query takes to apply in ms.',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of all applied updates in this database.';

/*Data for the table `updates` */

insert  into `updates`(`name`,`hash`,`state`,`timestamp`,`speed`) values 
('2015_03_20_00_characters.sql','B761760804EA73BD297F296C5C1919687DF7191C','ARCHIVED','2015-03-21 21:44:15',0),
('2015_03_20_01_characters.sql','894F08B70449A5481FFAF394EE5571D7FC4D8A3A','ARCHIVED','2015-03-21 21:44:15',0),
('2015_03_20_02_characters.sql','97D7BE0CAADC79F3F11B9FD296B8C6CD40FE593B','ARCHIVED','2015-03-21 21:44:51',0),
('2015_06_26_00_characters_335.sql','C2CC6E50AFA1ACCBEBF77CC519AAEB09F3BBAEBC','ARCHIVED','2015-07-13 23:49:22',0),
('2015_09_28_00_characters_335.sql','F8682A431D50E54BDC4AC0E7DBED21AE8AAB6AD4','ARCHIVED','2015-09-28 21:00:00',0),
('2015_08_26_00_characters_335.sql','C7D6A3A00FECA3EBFF1E71744CA40D3076582374','ARCHIVED','2015-08-26 21:00:00',0),
('2015_10_06_00_characters.sql','16842FDD7E8547F2260D3312F53EFF8761EFAB35','ARCHIVED','2015-10-06 16:06:38',0),
('2015_10_07_00_characters.sql','E15AB463CEBE321001D7BFDEA4B662FF618728FD','ARCHIVED','2015-10-07 23:32:00',0),
('2015_10_12_00_characters.sql','D6F9927BDED72AD0A81D6EC2C6500CBC34A39FA2','ARCHIVED','2015-10-12 15:35:47',0),
('2015_10_28_00_characters.sql','622A9CA8FCE690429EBE23BA071A37C7A007BF8B','ARCHIVED','2015-10-19 14:32:22',0),
('2015_10_29_00_characters_335.sql','4555A7F35C107E54C13D74D20F141039ED42943E','ARCHIVED','2015-10-29 17:05:43',0),
('2015_11_03_00_characters.sql','CC045717B8FDD9733351E52A5302560CD08AAD57','ARCHIVED','2015-10-12 15:23:33',0),
('2015_11_07_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 00:42:36',94),
('2016_02_10_00_characters.sql','F1B4DA202819CABC7319A4470A2D224A34609E97','ARCHIVED','2016-02-10 00:00:00',0),
('2016_03_13_2016_01_05_00_characters.sql','0EAD24977F40DE2476B4567DA2B477867CC0DA1A','ARCHIVED','2016-03-13 20:03:56',0),
('2016_04_11_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 03:18:17',0),
('2016_09_13_00_characters.sql','27A04615B11B2CFC3A26778F52F74C071E4F9C54','ARCHIVED','2016-07-06 18:55:18',0),
('2016_10_16_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-10-16 14:02:49',35),
('2016_10_30_00_characters.sql','7E2D5B226907B5A9AF320797F46E86DC27B7EC90','ARCHIVED','2016-10-30 00:00:00',0),
('2017_04_03_00_characters.sql','CB072C56692C9FBF170C4036F15773DD86D368B5','ARCHIVED','2017-04-03 00:00:00',0),
('2017_04_12_00_characters.sql','4FE3C6866A6DCD4926D451F6009464D290C2EF1F','ARCHIVED','2017-04-12 00:00:00',0),
('2017_04_12_01_characters.sql','5A8A1215E3A2356722F52CD7A64BBE03D21FBEA3','ARCHIVED','2017-04-12 00:00:00',0);

/*Table structure for table `updates_include` */

DROP TABLE IF EXISTS `updates_include`;

CREATE TABLE `updates_include` (
  `path` varchar(200) NOT NULL COMMENT 'directory to include. $ means relative to the source directory.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if the directory contains released or archived updates.',
  PRIMARY KEY (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of directories where we want to include sql updates.';

/*Data for the table `updates_include` */

insert  into `updates_include`(`path`,`state`) values 
('$/sql/updates/characters','RELEASED'),
('$/sql/custom/characters','RELEASED'),
('$/sql/old/3.3.5a/characters','ARCHIVED');

/*Table structure for table `warden_action` */

DROP TABLE IF EXISTS `warden_action`;

CREATE TABLE `warden_action` (
  `wardenId` smallint(5) unsigned NOT NULL,
  `action` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`wardenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `warden_action` */

/*Table structure for table `worldstates` */

DROP TABLE IF EXISTS `worldstates`;

CREATE TABLE `worldstates` (
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` tinytext,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Variable Saves';

/*Data for the table `worldstates` */

insert  into `worldstates`(`entry`,`value`,`comment`) values 
(1,0,NULL),
(2,0,NULL),
(3,1502328280,NULL),
(4,0,NULL),
(5,0,NULL),
(6,0,NULL),
(7,0,NULL),
(8,0,NULL),
(9,0,NULL),
(10,0,NULL),
(11,0,NULL),
(12,0,NULL),
(13,0,NULL),
(14,0,NULL),
(15,0,NULL),
(16,0,NULL),
(17,0,NULL),
(18,0,NULL),
(19,0,NULL),
(20,0,NULL),
(21,0,NULL),
(22,0,NULL),
(23,0,NULL),
(24,0,NULL),
(25,1502328280,NULL),
(26,0,NULL),
(27,1502328280,NULL),
(28,0,NULL),
(29,0,NULL),
(30,0,NULL),
(31,0,NULL),
(32,0,NULL),
(33,0,NULL),
(34,0,NULL),
(35,0,NULL),
(36,0,NULL),
(37,0,NULL),
(38,0,NULL),
(39,0,NULL),
(40,0,NULL),
(41,0,NULL),
(42,0,NULL),
(43,0,NULL),
(44,1502328280,NULL),
(45,0,NULL),
(46,0,NULL),
(47,0,NULL),
(48,0,NULL),
(49,0,NULL),
(50,0,NULL),
(51,0,NULL),
(52,0,NULL),
(53,0,NULL),
(54,0,NULL),
(55,0,NULL),
(56,0,NULL),
(57,0,NULL),
(58,0,NULL),
(59,0,NULL),
(60,1502328280,NULL),
(61,0,NULL),
(62,0,NULL),
(63,0,NULL),
(64,0,NULL),
(65,0,NULL),
(66,0,NULL),
(67,0,NULL),
(68,0,NULL),
(69,0,NULL),
(70,0,NULL),
(71,0,NULL),
(72,0,NULL),
(73,0,NULL),
(3781,9000000,NULL),
(3801,0,NULL),
(3802,1,NULL),
(20001,0,'NextArenaPointDistributionTime'),
(20002,1502506786,'NextWeeklyQuestResetTime'),
(20003,1502431200,'NextBGRandomDailyResetTime'),
(20004,0,'cleaning_flags'),
(20006,1502431200,NULL),
(20007,1504224000,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
